<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2018
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
	header("Location:admin/login.php");
} else {
	include '../config/system.conn.php';
	include '../config/system.byte.php';
	include '../Api/routeros_api.class.php';
	$API = new routeros_api();
	$fp = @fsockopen($mikrotik_ip, $mikrotik_port, $errCode, $errStr, 1);
	if ($fp) {
		if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {

			$data 			= $API->comm('/ip/hotspot/active/getall');
			$jumlahdata		= count($data);
			$batas 			= 50;
			$halaman 		= isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
			$previous 		= $halaman - 1;
			$next 			= $halaman + 1;
			$halaman_awal 	= ($halaman > 1) ? ($halaman * $batas) - $batas : 0;
			$total_halaman 	= ceil($jumlahdata / $batas);
			$jumlah_number 	= 3;
			$start_number 	= ($halaman > $jumlah_number) ? $halaman - $jumlah_number : 1;
			$end_number 	= ($halaman < ($total_halaman - $jumlah_number)) ? $halaman + $jumlah_number : $total_halaman;
			if ($jumlahdata > $batas) {
				$TotalReg 		= $batas * $halaman;
				$indexawal 		= $batas * ($halaman - 1);
				if ($TotalReg > $jumlahdata) {
					$TotalReg	= $jumlahdata;
				}
			} else {
				$TotalReg	=	$jumlahdata;
				$indexawal 	=	0;
			}
?>


			<div class="sl-pagebody">
				<div class="card bd-primary mg-t-3">
					<div class="card-header bg-primary tx-white"><i class="fa fa-user"></i> Hotspot Active | Total User Active : <?= $jumlahdata; ?> </div>
					<div class="card-body pd-sm-15">

						<div class="table-wrapper">
							<table id="userlist" class="table display nowrap " width="100%">
								<thead>
									<tr>
										<th>ID</th>
										<th>User</th>
										<th>Address</th>
										<th>Mac Address</th>
										<th>Uptime</th>
										<th>Server</th>

									</tr>
								</thead>
								<tbody>
									<?php for ($i = $indexawal; $i < $TotalReg; $i++) { ?>
										<tr>
											<td><?php echo $data[$i]['.id']; ?></td>
											<td><?php echo $data[$i]['user']; ?></td>
											<td><?php echo $data[$i]['address']; ?></td>
											<td><?php echo $data[$i]['mac-address']; ?></td>
											<td><?php echo $data[$i]['uptime']; ?></td>
											<td><?php echo $data[$i]['server']; ?></td>

										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
					<nav>
						<ul class="pagination justify-content-center">
							<?php
							if ($datapencarian) {
								$pencarian = "&pencarian=" . $datapencarian;
							} else {
								$pencarian = "";
							}
							if ($halaman > 1) {
								echo "<li class='page-item'>
            <a class='page-link' href='?Mikbotam=useractive&halaman=$previous$pencarian'>Prev</a>
        </li>";
							} ?>
							<?php
							for ($x = $start_number; $x <= $end_number; $x++) {
							?>
								<li class="page-item <?php if ($x == $halaman) {
															echo "active";
														} ?>"><a class="page-link" href="?Mikbotam=useractive&halaman=<?php echo $x . $pencarian; ?>"><?php echo $x; ?></a></li>
							<?php
							}
							?>
							<?php if ($halaman < $total_halaman) {
								echo "<li class='page-item'>
            <a class='page-link' href='?Mikbotam=useractive&halaman=$next$pencarian';>Next</a>
        </li>";
							} ?>
						</ul>
					</nav>
				</div>
			</div>

<?php
		} else {
			include "disconnected.php";
		}

		fclose($fp);
	} else {
		include "disconnected.php";
	}
}

?>