<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:./admin/login.php");
} else {
    include './config/system.conn.php';
    include './config/system.byte.php';
    include './Api/routeros_api.class.php';
    $API = new routeros_api();
    $fp = @fsockopen($mikrotik_ip, $mikrotik_port, $errCode, $errStr, 1);
    if ($fp) {
        if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {

            if (isset($_POST['action']) || isset($_POST['schidminus']) || isset($_POST['schidplus'])) {
                //string hari ini
                $hariini = strtotime('now');

                //data post
                $idsecret       = $_POST['uid'];
                $tipeeksekusi   = $_POST['tipeeksekusi'];
                $profiletujuan  = $_POST['profiletujuan'];
                $profileasal    = $_POST['profileasal'];
                $komenasal      = $_POST['komenasal'];
                $secretname     = $_POST['secretname'];

                //ambil harga dari komen profile
                $komenprofile   = $API->comm("/ppp/profile/print", ["?name" => $profileasal])[0]['comment'];
                $pecahprofile   = explode(" | ", $komenprofile);
                $harga          = explode("price : ", $pecahprofile[4])[1];

                //ambil data schedule dan ubah menjadi string
                $schexp     = $API->comm("/system/scheduler/print", ['?name' => $secretname . "-ppp-mitha"])[0];
                $schetgl    = $schexp['start-date'];
                $schwaktu   = substr($schexp['start-time'], 0, -3);
                $schid      = $schexp['.id'];
                $tgl        = date_create_from_format("M/d/Y", $schetgl);
                $tgl2       = date_format($tgl, "m/d/Y");
                $waktunya   = "$tgl2 $schwaktu";
                $nextrun    = strtotime($waktunya);

                if (isset($_POST['action'])) {

                    if ($_POST['action'] == "aktifkan") {
                        $komenbaru = str_replace(" status : expired", " status : daftar", $komenasal);
                        if ($tipeeksekusi == "disable") {
                            //enable kan secret dan ganti comment
                            $API->write("/ppp/secret/enable", false);
                            $API->write("=.id=" . $idsecret);
                            $API->read();
                        } else if ($tipeeksekusi == "pindah-profile") {
                            $setprofile = $API->comm("/ppp/secret/set", [
                                ".id" => $idsecret,
                                "profile" => $profileasal,
                            ]);
                        }
                        $setkomen = $API->comm("/ppp/secret/set", [
                            ".id" => $idsecret,
                            "comment" => $komenbaru,
                        ]);

                        //jika waktu skr lebih besar dari waktu next run maka ubah next run schedule
                        // if ($hariini > $nextrun) {
                        //     $bulandepan     = strtotime("next Month", $nextrun);
                        //     $tglblndpn      = date("M/d/Y", $bulandepan);
                        //     $jamblndpn      = date("H:i:s", $bulandepan);

                        //     //ubah schedule
                        //     $gantische      = $API->comm("/system/scheduler/set", [
                        //         ".id"          => $schid,
                        //         "start-date"    => $tglblndpn,
                        //         "start-time"    => $jamblndpn
                        //     ]);

                        //     //input data omset ke database
                        //     $inputdatabase = inputpppoe($harga, $secretname);
                        // }
                    } else if ($_POST['action'] == 'eksekusi') {
                        if (strpos($komenasal, " status : aktif") !== false) {
                            $komenbaru = str_replace(" status : aktif", " status : expired", $komenasal);
                        } else if (strpos($komenasal, " status : daftar") !== false) {
                            $komenbaru = str_replace(" status : daftar", " status : expired", $komenasal);
                        }
                        //kick dari active connection
                        $idactive = $API->comm("/ppp/active/print", ["?name" => $secretname,])[0]['.id'];
                        $kicksecret = $API->comm("/ppp/active/remove", ['.id' => $idactive]);

                        if ($tipeeksekusi == "disable") {
                            //disable kan secret dan ganti comment
                            $API->write("/ppp/secret/disable", false);
                            $API->write("=.id=" . $idsecret);
                            $API->read();
                        } else if ($tipeeksekusi == "pindah-profile") {
                            $setprofile = $API->comm("/ppp/secret/set", [
                                ".id" => $idsecret,
                                "profile" => $profiletujuan,
                            ]);
                        }
                        $setkomen = $API->comm("/ppp/secret/set", [
                            ".id" => $idsecret,
                            "comment" => $komenbaru,
                        ]);

                        //hapus schedule
                        $hapusschedule = $API->comm("/system/scheduler/remove", ['.id' => $schid]);
                    }
                } else if (isset($_POST['schidminus'])) {

                    $kurangsatubln      = strtotime("last Month", $nextrun);

                    if ($hariini < $kurangsatubln) {
                        $blntarget      = strtotime("last Month", $nextrun);
                        $tgltarget      = date("M/d/Y", $blntarget);
                        $jamtarget      = date("H:i:s", $blntarget);

                        //ubah schedule
                        $gantische      = $API->comm("/system/scheduler/set", [
                            ".id"          => $schid,
                            "start-date"    => $tgltarget,
                            "start-time"    => $jamtarget
                        ]);

                        //input data omset ke database
                        $inputdatabase = inputpppoe("-" . $harga, $secretname);
                    }
                } else if (isset($_POST['schidplus'])) {

                    $bulandepan     = strtotime("next Month", $nextrun);
                    $tglblndpn      = date("M/d/Y", $bulandepan);
                    $jamblndpn      = date("H:i:s", $bulandepan);

                    //ubah schedule
                    $gantische      = $API->comm("/system/scheduler/set", [
                        ".id"          => $schid,
                        "start-date"    => $tglblndpn,
                        "start-time"    => $jamblndpn
                    ]);

                    //input data omset ke database
                    $inputdatabase = inputpppoe($harga, $secretname);
                }
            }
            header("Location:./pages/?Mikbotam=pppuser");
            //print_r($kicksecret);
        } else {
            include "disconnected.php";
        }
        fclose($fp);
    } else {
        include "disconnected.php";
    }
}
