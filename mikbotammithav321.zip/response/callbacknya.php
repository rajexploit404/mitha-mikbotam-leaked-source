<?php
date_default_timezone_set('Asia/Jakarta');
include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Saldo/rpt/functions.php';

//===ambil datanya
$getidmikbotam  = getid();
$ambildata      = ambilpg($getidmikbotam);
$datamentah     = json_decode($ambildata, true);
$apikey         = $datamentah['apikey'];
$privatekey     = $datamentah['privatekey'];
$merchantcode   = $datamentah['merchantcode'];
$simulasi       = $datamentah['simulasi'];
if ($simulasi == "ya") {
    $simulasi   = "api-sandbox";
}
if ($simulasi == "tidak") {
    $simulasi = "api";
}

// ambil data JSON
$json = file_get_contents("php://input");

// ambil callback signature
$callbackSignature = isset($_SERVER['HTTP_X_CALLBACK_SIGNATURE']) ? $_SERVER['HTTP_X_CALLBACK_SIGNATURE'] : '';

// generate signature untuk dicocokkan dengan X-Callback-Signature
$signature = hash_hmac('sha256', $json, $privateKey);

if ($callbackSignature !== $signature) {
    header("Location:../admin/login.php");; // signature tidak valid, hentikan proses
}

$data = json_decode($json);
$event = $_SERVER['HTTP_X_CALLBACK_EVENT'];

if ($event == 'payment_status') {
    //ambil detail dari server pembayaran

    $payload = [
        'reference'    => $data->reference,
    ];

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_FRESH_CONNECT     => true,
        CURLOPT_URL               => "https://tripay.co.id/" . $simulasi . "/transaction/detail?" . http_build_query($payload),
        CURLOPT_RETURNTRANSFER    => true,
        CURLOPT_HEADER            => false,
        CURLOPT_HTTPHEADER        => array(
            "Authorization: Bearer " . $apiKey
        ),
        CURLOPT_FAILONERROR       => false,
    ));

    $response   = curl_exec($curl);
    $err        = curl_error($curl);
    curl_close($curl);
    $decode     = json_decode($response, true);
    $statuscurl = $decode['success'];

    $omset      = $data->amount_received;
    $status     = $data->status;
    $mref       = $data->merchant_ref;
    $ref        = $data->reference;
    $waktubayar = $data->paid_at;
    $jenispaket = $decode['data']['order_items'][0]['name'];

    $pecahmref  = explode("|", $mref);
    $nominal    = $pecahmref[0];
    $idtele     = $pecahmref[1];
    $namatele   = $pecahmref[2];
    $idlog      = $pecahmref[3];
    $ambillog   = ambilpglog($idlog);

    if ($data->status == 'PAID') {
        if ($ambillog['Type_'] == "unpaid") {
            //ambil saldo lama
            $lihatsaldolama     = lihatsaldo($idtele);
            //tambah saldo reseller
            topuppg($idtele, $nominal);
            //update log menjadi paid
            updatepglog($idlog, 'paid');
            //kirim pesan telegram ke reseller
            $lihatsaldobaru     = lihatsaldo($idtele);

            $pesanreseller      = "<code>";
            $pesanreseller      .= "  Informasi TOP UP saldo\n";
            $pesanreseller      .= "===========================\n";
            $pesanreseller      .= "Status      : berhasil  \n";
            $pesanreseller      .= "Nominal     : " . rupiah($nominal) . "\n";
            $pesanreseller      .= "Saldo awal  : " . rupiah($lihatsaldolama) . "\n";
            $pesanreseller      .= "Saldo akhir : " . rupiah($lihatsaldobaru) . "\n";
            $pesanreseller      .= "===========================\n";
            $pesanreseller      .= "</code>";

            kirimpesantelegram($idtele, $pesanreseller, $token);

            // kirim pesan telegram ke owner/admin

            $pesanowner      = "<code>";
            $pesanowner      .= "  Informasi TOP UP saldo\n";
            $pesanowner      .= "===========================\n";
            $pesanowner      .= "Reseller    : " . $namatele . "\n";
            $pesanowner      .= "Status      : berhasil  \n";
            $pesanowner      .= "Nominal     : " . rupiah($nominal) . "\n";
            $pesanowner      .= "Saldo awal  : " . rupiah($lihatsaldolama) . "\n";
            $pesanowner      .= "Saldo akhir : " . rupiah($lihatsaldobaru) . "\n";
            $pesanowner      .= "===========================\n";
            $pesanowner      .= "</code>";

            kirimpesantelegram($id_own, $pesanowner, $token);

            echo json_encode(['success' => true, 'status awal' => 'unpaid']);
            exit;
        } else {
            echo json_encode(['success' => true, 'status awal' => 'paid']);
            exit;
        }
    } else if ($data->status == 'EXPIRED') {
        //ketika pembayaran sudah kadaluarsa maka hapus log biar ga menuh2in dbase
        hapuspglog($idlog);

        //kirim pesan ke telegram
        $informasinya = "Maaf waktu pembayaran anda telah berakhir,\nsilahkan order ulang untuk deposit (/otodepo nominal).";
        $website = "https://api.telegram.org/bot" . $token;
        $params  = [
            'chat_id' => $idtele,
            'text' => $informasinya,
            'parse_mode' => 'html',
        ];
        $ch = curl_init($website . '/sendMessage');
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);

        echo json_encode(['success' => true, 'status awal' => 'expired']);
        exit;
    } else if ($data->status == 'FAILED') {
        //ketika pembayaran gagal biarkan saja hingga kadaluarsa
        $informasinya = "PEMBAYARAN GAGAL";
        $website = "https://api.telegram.org/bot" . $token;
        $params  = [
            'chat_id' => $idtele,
            'text' => $informasinya,
            'parse_mode' => 'html',
        ];
        $ch = curl_init($website . '/sendMessage');
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);

        echo json_encode(['success' => true, 'status awal' => 'failed']);
        exit;
    }
}
die('...maintenance...');
