<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2019
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//
session_start();
error_reporting(0);
if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {

    include '../config/system.conn.php';
    $datapencarian = filter_var($_GET['pencarian'], FILTER_SANITIZE_STRING);
    $batas = 10;
    $halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
    $previous = $halaman - 1;
    $next = $halaman + 1;
    $halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;
    $datavoucher = gethistorylimit($id, $halaman_awal, $batas, $datapencarian);
    $jumlahdata = hitunghistory($id, $datapencarian);
    $total_halaman = ceil($jumlahdata / $batas);
    $jumlah_number = 3;
    $start_number = ($halaman > $jumlah_number) ? $halaman - $jumlah_number : 1;
    $end_number = ($halaman < ($total_halaman - $jumlah_number)) ? $halaman + $jumlah_number : $total_halaman;
}
?>

<div class="sl-pagebody">
    <form action="" method="GET">
        <div class="row row-sm d-flex justify-content-center">
            <div class="col-sm-4">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Search ..." name="pencarian" value="<?php echo $_GET['pencarian']; ?>" required>
                    <input type="hidden" name="Mikbotam" value="Record">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit" style='padding:20%'>Search</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class="card bd-primary mg-t-3">
        <div class="card-header bg-primary tx-white"><i class="icol-ui-tab-content"></i> History Transaksi | total history : <?php echo $jumlahdata; ?></div>
        <div class="card-body pd-sm-15">
            <div class="table-wrapper">
                <table id="userhistory2" class="table display  nowrap " width="100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID User</th>
                            <th>Nama Reseller</th>
                            <th>Harga Voucher</th>
                            <th>Saldo Awal</th>
                            <th>Saldo Akhir</th>
                            <th>Top up</th>
                            <th>Username<br>Password Voucher</th>
                            <th>Voucher Info</th>
                            <th>Keterangan</th>
                            <th>Waktu <br>Tanggal</th>
                            <th>Hapus</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $TotalReg = count($datavoucher);
                        for ($i = 0; $i < $TotalReg; $i++) {
                            $datas            = $datavoucher[$i];
                            $no               = $halaman_awal + $i + 1;
                            $id_user          = $datas['id_user'];
                            $nama_seller      = $datas['nama_seller'];
                            $saldo_awal       = $datas['saldo_awal'];
                            $beli_voucher     = $datas['beli_voucher'];
                            $saldo_akhir      = $datas['saldo_akhir'];
                            $top_up           = $datas['top_up'];
                            $top_up_fromid    = $datas['top_up_fromid'];
                            $username_voucher = $datas['username_voucher'];
                            $password_voucher = $datas['password_voucher'];
                            $exp_voucher      = $datas['exp_voucher'];
                            $keterangan       = $datas['keterangan'];
                            $Waktu            = $datas['Waktu'];
                            $Tanggal          = $datas['Tanggal'];
                            $kuncinya         = $datas['No'];
                            $info_vc          = $datas['penjualan'];
                            $namapppoe        = ($keterangan == "pppoe" || $keterangan == "otodepo") ? "(" . $datas['Type_'] . ")" : null;
                            $top_up           = (empty($top_up)) ? '' : rupiah($top_up);

                            if (!empty($info_vc)) {
                                $pecahdata = explode("|", $info_vc);
                                $info_vc_fin = "Start : " . $pecahdata[0] . " | " . $pecahdata[1] . "<br>Expired : " . $pecahdata[2] . " | " . $pecahdata[3];
                            } else {
                                $info_vc_fin = "belum terdata";
                            }

                            echo "<tr>";
                            echo "<td style='text-align:center'>" . $no . "</td>";
                            echo "<td>" . $id_user . "</td>";
                            echo "<td>" . $nama_seller . "</td>";
                            echo "<td>" . $beli_voucher . "</td>";
                            echo "<td>" . $saldo_awal . "</a></td>";
                            echo "<td>" . $saldo_akhir . "</td>";
                            echo "<td>" . $top_up . "</td>";
                            echo "<td>" . $username_voucher . "<br>" . $password_voucher . "</td>";
                            echo "<td>" . $info_vc_fin . "</td>";

                            echo "<td>" . $keterangan . " " . $namapppoe . "</td>";
                            echo "<td>" . $Waktu . "<br>" . $Tanggal . "</td>";
                            echo "<td>";
                        ?>
                            <?php if ($keterangan == "Success" || $keterangan == "generate") {
                                echo "<a href='../Prosses/exportuser.php?id=$kuncinya;&iduser=" . $datas['id_user'] . "&profile=hapusbaris&userhs=$username_voucher' class='btn btn-danger' onClick=\"return confirm('HAPUS BARIS INI? data di mikrotik untuk user ini akan hilang juga')\">  <i class='fa fa fa-trash-o'></i></a>";
                            }


                            ?>

                        <?php
                            echo "</td>";
                            echo "</tr>";
                        }
                        ?>

                    </tbody>
                </table>
            </div><!-- table-wrapper -->
        </div><!-- card-body -->
    </div><!-- card -->

</div><!-- table-wrapper -->
<nav>
    <ul class="pagination justify-content-center">
        <?php
        if ($datapencarian) {
            $pencarian = "&pencarian=" . $datapencarian;
        } else {
            $pencarian = "";
        }
        if ($halaman > 1) {
            echo "<li class='page-item'>
            <a class='page-link' href='?Mikbotam=Record&halaman=$previous$pencarian'>Prev</a>
        </li>";
        } ?>
        <?php
        for ($x = $start_number; $x <= $end_number; $x++) {
        ?>
            <li class="page-item <?php if ($x == $halaman) {
                                        echo "active";
                                    } ?>"><a class="page-link" href="?Mikbotam=Record&halaman=<?php echo $x . $pencarian; ?>"><?php echo $x; ?></a></li>
        <?php
        }
        ?>
        <?php if ($halaman < $total_halaman) {
            echo "<li class='page-item'>
            <a class='page-link' href='?Mikbotam=Record&halaman=$next$pencarian';>Next</a>
        </li>";
        } ?>
    </ul>
</nav>