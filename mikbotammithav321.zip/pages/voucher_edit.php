<?php
//=====================================================START====================//

/*
 *  RUMAH PETIR v2.7
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);


include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Api/routeros_api.class.php';
$API = new routeros_api();

if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {

    $seeprofile = $API->comm('/ip/hotspot/user/profile/print');
    $serverhot = $API->comm('/ip/hotspot/print');
}

$id       = $_GET['idtelegram'];
$nmrvcr   = $_GET['id'];
$ARRAYvoc = getvoc($id);
$datajson = json_decode($ARRAYvoc, true);
$dvn      = $datajson[$nmrvcr];







?>


<div class="card bd bd-primary  ">
    <div class="card-body pd-sm-15">

        <form action="" method="post">
            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Nama Voucher : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="evc_nama" value="<?= $dvn['Voucher']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Deskripsi : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="evc_desc" value="<?= $dvn['Text_List']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Harga Voucher (Rp) : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="evc_harga" value="<?= $dvn['price']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Mark Up Voucher (Rp) : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="evc_markup" value="<?= $dvn['markup']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Server : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control" name="evc_server" data-placeholder="Select Server  ">

                        <option value="all">all</option>
                        <?php foreach ($serverhot as $index => $jambu) : ?>
                            <option value="<?= $jambu['name']; ?>" <?php if ($jambu['name'] == $dvn['server']) {
                                                                        echo 'selected';
                                                                    } ?>><?= $jambu['name']; ?></option>
                        <?php endforeach; ?>

                    </select>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Profile : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control" name="evc_profile" data-placeholder="Select Server  ">


                        <?php foreach ($seeprofile as $index => $kambing) : ?>
                            <option value="<?= $kambing['name']; ?>" <?php if ($kambing['name'] == $dvn['profile']) {
                                                                            echo 'selected';
                                                                        } ?>><?= $kambing['name']; ?></option>
                        <?php endforeach; ?>

                    </select>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Limit Uptime : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="evc_lmuptime" value="<?= $dvn['Limit']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Limit Quota Download (Mb) : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="evc_lmqdl" value="<?= $dvn['limit_download']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Limit Quota Upload (Mb) : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="evc_lmqup" value="<?= $dvn['limit_upload']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Limit Quota Total (Mb) : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="evc_lmqtotal" value="<?= $dvn['limit_total']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Type Characters : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control" name="evc_typechar" data-placeholder="Select Server  ">

                        <?php $tc = $dvn['typechar'] ?>

                        <option value="1" <?php if ($tc == "1") {
                                                echo 'selected';
                                            } ?>>1234</option>
                        <option value="2" <?php if ($tc == "2") {
                                                echo 'selected';
                                            } ?>>ABCDE</option>
                        <option value="3" <?php if ($tc == "3") {
                                                echo 'selected';
                                            } ?>>abcd</option>
                        <option value="4" <?php if ($tc == "4") {
                                                echo 'selected';
                                            } ?>>ABCDabcd</option>
                        <option value="5" <?php if ($tc == "5") {
                                                echo 'selected';
                                            } ?>>AbcdABCD1234</option>
                        <option value="6" <?php if ($tc == "6") {
                                                echo 'selected';
                                            } ?>>abcd1234</option>
                        <option value="7" <?php if ($tc == "7") {
                                                echo 'selected';
                                            } ?>>ABCD1234</option>
                        <option value="checkCode" <?php if ($tc == "checkCode") {
                                                        echo 'selected';
                                                    } ?>>ABCDabcd1234</option>
                    </select>


                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Type Login : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control" name="evc_typelogin" data-placeholder="Select Server  ">

                        <?php $tl = $dvn['type'] ?>

                        <option value="up" <?php if ($tl == "up") {
                                                echo 'selected';
                                            } ?>>Username & Password</option>
                        <option value="userpass" <?php if ($tl == "userpass") {
                                                        echo 'selected';
                                                    } ?>>Username = Password</option>

                    </select>


                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Prefix : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" name="evc_prefix" class="form-control" title="untuk memberi ciri tertentu di awal voucher, kosongi jika tidak perlu" value="<?= $dvn['prefix']; ?>" maxlength="3">
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Length Character : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="number" class="form-control" name="evc_lenchar" min="3" max="10" value="<?= $dvn['length']; ?>" data-toggle="tooltip" data-placement="top" required>

                </div>
            </div>
            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Group Voucher : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="checkbox" id="grupvc1" name="evc_grupvc[]" value="1" <?php if (preg_match('/1/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc1"> 1 </label>
                    <input type="checkbox" id="grupvc2" name="evc_grupvc[]" value="2" <?php if (preg_match('/2/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc2"> 2 </label>
                    <input type="checkbox" id="grupvc3" name="evc_grupvc[]" value="3" <?php if (preg_match('/3/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc3"> 3 </label>
                    <input type="checkbox" id="grupvc4" name="evc_grupvc[]" value="4" <?php if (preg_match('/4/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc4"> 4 </label>
                    <input type="checkbox" id="grupvc5" name="evc_grupvc[]" value="5" <?php if (preg_match('/5/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc5"> 5 </label>
                    <input type="checkbox" id="grupvc6" name="evc_grupvc[]" value="6" <?php if (preg_match('/6/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc6"> 6 </label>
                    <input type="checkbox" id="grupvc7" name="evc_grupvc[]" value="7" <?php if (preg_match('/7/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc7"> 7 </label>
                    <input type="checkbox" id="grupvc8" name="evc_grupvc[]" value="8" <?php if (preg_match('/8/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc8"> 8 </label>
                    <input type="checkbox" id="grupvc9" name="evc_grupvc[]" value="9" <?php if (preg_match('/9/', $dvn['grupvc'])) {
                                                                                            echo "checked";
                                                                                        } ?>> <label for="grupvc9"> 9 </label>
                    <input type="checkbox" id="grupvcdefault" name="evc_grupvc[]" value="default" <?php if (preg_match('/default/', $dvn['grupvc']) || empty($dvn['grupvc'])) {
                                                                                                        echo "checked";
                                                                                                    } ?>> <label for="grupvcdefault"> default </label>

                </div>
            </div>
            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Voucher Color : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="jscolor" name="evc_color" value="<?= $dvn['Color']; ?>" required>

                </div>
            </div>



            <div class="row row-xs mg-t-10">
                <div class="col-sm-15 mg-l-auto">
                    <div class="form-layout-footer">
                        <input type="hidden" name="evc_id" value="<?= $dvn['id']; ?>">
                        <input type="hidden" name="evc_arraynum" value="<?= $nmrvcr; ?>">


                        <button type="submit" class="btn bg-primary tx-white" name="savevoucheredit">Save</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger" name="deletevoucher">Delete</button>
                    </div>

                </div>

            </div>

        </form>
    </div>
</div>

<script>
    $(document).ready(function() {
        jscolor.installByClassName("jscolor");
    });
</script>