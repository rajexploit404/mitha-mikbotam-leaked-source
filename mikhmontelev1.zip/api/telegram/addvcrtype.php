<?php
error_reporting(0);
if (!isset($_SESSION["mikhmon"])) {
    header("Location:../admin.php?id=login");
} else {
    $dataunit       = $API->comm("/system/script/print", ["?comment" => "mikhmon-mitha"])[0];
    $datajson       = json_decode($dataunit['source'], true);
    $datavc         = $datajson['jenis voucher'];
    $dataqty        = $datajson['quantity'];
    $srvlist        = $API->comm("/ip/hotspot/print");
    $getprofile     = $API->comm("/ip/hotspot/user/profile/print");

    if (isset($_POST['submit'])) {
        $vcrtypename    = $_POST['vcrtypename'];
        $server         = $_POST['server'];
        $user           = $_POST['user'];
        $userl          = $_POST['userl'];
        $prefix         = $_POST['prefix'];
        $char           = $_POST['char'];
        $profile        = $_POST['profile'];
        $timelimit      = $_POST['timelimit'];
        $datalimit      = $_POST['datalimit'];
        $adcomment      = $_POST['adcomment'];
        $mbgb           = $_POST['mbgb'];
        $desc           = $_POST['desc'];

        $datajson['jenis voucher'][$vcrtypename] = [
            "server"    => $server,
            "profile"   => $profile,
            "usermode"  => $user,
            "length"    => $userl,
            "prefix"    => $prefix,
            "char"      => $char,
            "timelimit" => $timelimit,
            'datalimit' => $datalimit,
            'mbgb'      => $mbgb,
            'comment'   => $adcomment,
            'desc'      => $desc,
        ];

        $simpan = json_encode($datajson);

        $API->comm("/system/script/set", [
            '.id'       => $dataunit['.id'],
            'source'    => $simpan,
        ]);
        header('Location: ./?telegram=menu&session=' . $session);
    }
}
?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">ADD VOUCHER TYPE</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-10">
                        <div class="card">
                            <div class="card-header">
                                <h3><?= $info; ?></h3>
                            </div>
                            <div class="card-body">
                                <form autocomplete="off" method="post" action="">
                                    <table class="table">
                                        <tr>
                                            <td class="align-middle">Voucher Type Name</td>
                                            <td><input class="form-control " type="text" size="6" maxlength="15" autocomplete="off" name="vcrtypename" value="" required></td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle">Server</td>
                                            <td>
                                                <select class="form-control " name="server" required="1">
                                                    <option>all</option>
                                                    <?php $TotalReg = count($srvlist);
                                                    for ($i = 0; $i < $TotalReg; $i++) {
                                                        echo "<option>" . $srvlist[$i]['name'] . "</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle"><?= $_user_mode ?></td>
                                            <td>
                                                <select class="form-control " onchange="defUserl();" id="user" name="user" required="1">
                                                    <option value="up"><?= $_user_pass ?></option>
                                                    <option value="vc"><?= $_user_user ?></option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle"><?= $_user_length ?></td>
                                            <td>
                                                <select class="form-control " id="userl" name="userl" required="1">
                                                    <option>4</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>6</option>
                                                    <option>7</option>
                                                    <option>8</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle"><?= $_prefix ?></td>
                                            <td><input class="form-control " type="text" size="6" maxlength="6" autocomplete="off" name="prefix" value=""></td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle"><?= $_character ?></td>
                                            <td>
                                                <select class="form-control " name="char" required="1">
                                                    <option id="lower" style="display:block;" value="lower"><?= $_random ?> abcd</option>
                                                    <option id="upper" style="display:block;" value="upper"><?= $_random ?> ABCD</option>
                                                    <option id="upplow" style="display:block;" value="upplow"><?= $_random ?> aBcD</option>
                                                    <option id="lower1" style="display:none;" value="lower"><?= $_random ?> abcd2345</option>
                                                    <option id="upper1" style="display:none;" value="upper"><?= $_random ?> ABCD2345</option>
                                                    <option id="upplow1" style="display:none;" value="upplow"><?= $_random ?> aBcD2345</option>
                                                    <option id="mix" style="display:block;" value="mix"><?= $_random ?> 5ab2c34d</option>
                                                    <option id="mix1" style="display:block;" value="mix1"><?= $_random ?> 5AB2C34D</option>
                                                    <option id="mix2" style="display:block;" value="mix2"><?= $_random ?> 5aB2c34D</option>
                                                    <option id="num" style="display:none;" value="num"><?= $_random ?> 1234</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle"><?= $_profile ?></td>
                                            <td>
                                                <select class="form-control " onchange="GetVP();" id="uprof" name="profile" required="1">
                                                    <?php if ($genprof != "") {
                                                        echo "<option>" . $genprof . "</option>";
                                                    } else {
                                                    }
                                                    $TotalReg = count($getprofile);
                                                    for ($i = 0; $i < $TotalReg; $i++) {
                                                        echo "<option>" . $getprofile[$i]['name'] . "</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle"><?= $_time_limit ?></td>
                                            <td><input class="form-control " type="text" size="4" autocomplete="off" name="timelimit" value=""></td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle"><?= $_data_limit ?></td>
                                            <td>
                                                <div class="input-group">
                                                    <div class="input-group-10 col-box-9">
                                                        <input class="group-item group-item-l" type="number" min="0" max="9999" name="datalimit" value="<?= $udatalimit; ?>">
                                                    </div>
                                                    <div class="input-group-2 col-box-3">
                                                        <select style="padding:4.2px;" class="group-item group-item-r" name="mbgb" required="1">
                                                            <option value=1048576>MB</option>
                                                            <option value=1073741824>GB</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle"><?= $_comment ?></td>
                                            <td><input class="form-control " type="text" title="No special characters" id="comment" autocomplete="off" name="adcomment" value=""></td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle">Description for telegram bot</td>
                                            <td><input class="form-control " type="text" size="6" maxlength="20" autocomplete="off" name="desc" value=""></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <div>
                                                    <button type="submit" name="submit" class="btn bg-primary" title="Add Voucher Type"> <i class="fa fa-save"></i> Add</button>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    document.getElementById("comment").onkeypress = function(e) {
        var chr = String.fromCharCode(e.which);
        if (" _!@#$%^&*()+=;|?,.~".indexOf(chr) >= 0)
            return false;
    };
</script>