<?php
$namarouter     = explode("|profilename|", $command)[1];
$idunit         = explode("|profilename|", $command)[0];
include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));
$dataunit       = $API->comm("/ip/hotspot/user/profile/getall");
$jmlunit        = count($dataunit);
$array_luar     = [];
$array_dalam    = [];


$i = (ceil($idunit / $jmlperhal) - 1) * 20;

$detailunit     = $dataunit[$idunit];
$onloginprof    = $detailunit['on-login'];
$getexpmode     = explode(",", $onloginprof);
$expmode = $getexpmode[1];
if ($expmode == "rem") {
    $expiredmode = "Remove";
} elseif ($expmode == "ntf") {
    $expiredmode = "Notice";
} elseif ($expmode == "remc") {
    $expiredmode = "Remove & Record";
} elseif ($expmode == "ntfc") {
    $expiredmode = "Notice & Record";
} else {
    $expiredmode = "";
}

$getvalid = explode(",", $onloginprof)[3];

$getprice = explode(",", $onloginprof);
$price = trim($getprice[2]);
if ($price == "" || $price == "0") {
    $harga = "";
} else {
    if ($currency == in_array($currency, $cekindo['indo'])) {
        $harga = number_format((float)$price, 0, ",", ".");
    } else {
        $harga = number_format((float)$price, 2);
    }
}

$price2 = trim($getprice[4]);
if ($price2 == "" || $price2 == "0") {
    $hargajual = "";
} else {
    if ($currency == in_array($currency, $cekindo['indo'])) {
        $hargajual = number_format((float)$price2, 0, ",", ".");
    } else {
        $hargajual = number_format((float)$price2, 2);
    }
}

$getgracep = explode(",", $onloginprof)[6];

$text   .= "<code>\n";
$text   .= "nama profile : " . $detailunit['name'] . "\n";
$text   .= "shared users : " . $detailunit['shared-users'] . "\n";
$text   .= "rate limit   : " . $detailunit['rate-limit'] . "\n";
$text   .= "expired mode : " . $expiredmode . "\n";
$text   .= "validity     : " . $getvalid . "\n";
$text   .= "price        : $currency " . $harga . "\n";
$text   .= "sellingprice : $currency " . $hargajual . "\n";
$text   .= "lock user    : " . $getgracep . "\n";
$text   .= "</code>";

$array_luar = [
    [
        ['text' => "<< BACK", "callback_data" => (floor($idunit / $jmlperhal) * $jmlperhal) . '|profilepage|' . $namarouter],
        ['text' => "CLOSE", "callback_data" => 'cancel'],
    ]
];

$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];

return Bot::editMessageText($options);
