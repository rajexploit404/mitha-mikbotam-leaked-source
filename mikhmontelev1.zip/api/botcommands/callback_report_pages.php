<?php
$namarouter     = explode("|reportpages|", $command)[1];
$idunit         = explode("|reportpages|", $command)[0];
include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));
$dataunit       = $API->comm("/ip/hotspot/user/profile/getall");
$jmlunit        = count($dataunit);
$array_luar     = [];
$array_dalam    = [];

/*
- hari ini
- minggu ini
- bulan ini
- hari kemarin
- minggu kemarin
- bulan lalu
- semua data
*/

$text   .= "💵 pilih Laporan Penjualan yang diinginkan :";

$send   = [
    [
        ['text' => "⏱ hari ini", 'callback_data' => 'today|reportdetail|' . $namarouter],
        ['text' => "📆 hari kemarin", 'callback_data' => 'lastday|reportdetail|' . $namarouter],
    ],
    [
        ['text' => "🕞 minggu ini", 'callback_data' => 'thisweek|reportdetail|' . $namarouter],
        ['text' => "🌀 minggu kemarin", 'callback_data' => 'lastweek|reportdetail|' . $namarouter],
    ],
    [
        ['text' => "📊 bulan ini", 'callback_data' => 'thismonth|reportdetail|' . $namarouter],
        ['text' => "📈 bulan kemarin", 'callback_data' => 'lastmonth|reportdetail|' . $namarouter],
    ],
    [
        ['text' => '📦 Semua data', 'callback_data' => 'alldays|reportdetail|' . $namarouter],
    ],
    [
        ['text' => '❌❌ CLOSE ❌❌', 'callback_data' => 'cancel'],
    ],
];



$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $send]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];


return Bot::editMessageText($options);
