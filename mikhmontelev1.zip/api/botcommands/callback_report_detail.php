<?php
$namarouter     = explode("|reportdetail|", $command)[1];
$idunit         = explode("|reportdetail|", $command)[0];
include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));
$dataunit       = $API->comm("/ip/hotspot/user/profile/getall");
$jmlunit        = count($dataunit);
$array_luar     = [];
$array_dalam    = [];

#ambil zona waktu
$gettimezone = $API->comm("/system/clock/print");
$timezone = $gettimezone[0]['time-zone-name'];
date_default_timezone_set($timezone);

if ($idunit == "today") {
    $dataunit   = $API->comm("/system/script/print", [
        "?source" => strtolower(date("M/d/Y")),
    ]);

    $headertext = "Laporan Penjualan Hari ini (" . date("M/d/Y") . ") :";
} elseif ($idunit == "lastday") {
    $dataunit   = $API->comm("/system/script/print", [
        "?source" => strtolower(date("M/d/Y", strtotime('last day'))),
    ]);
    $headertext = "Laporan Penjualan Hari Kemarin (" . date("M/d/Y", strtotime('last day')) . ") :";
} elseif ($idunit == "thisweek") {
    $hari[0] = strtotime('this week');
    for ($i = 1; $i < 7; $i++) {
        $hari[$i] = strtotime("this week + $i day");
    }

    $dataunit = [];

    foreach ($hari as $i => $hr) {
        $dataperhari   = $API->comm("/system/script/print", [
            "?source" => strtolower(date('M/d/Y', $hr)),
        ]);
        if ($dataperhari) {
            $dataunit = array_merge($dataunit, $dataperhari);
        }
    }

    $headertext = "Laporan Penjualan Minggu ini (" . date("M/d/Y", strtotime('this week')) . " - " . date("M/d/Y", strtotime('this week + 6 day')) . ") :";
} elseif ($idunit == "lastweek") {
    $hari[0] = strtotime('last week');
    for ($i = 1; $i < 7; $i++) {
        $hari[$i] = strtotime("last week + $i day");
    }

    $dataunit = [];

    foreach ($hari as $i => $hr) {
        $dataperhari   = $API->comm("/system/script/print", [
            "?source" => strtolower(date('M/d/Y', $hr)),
        ]);
        if ($dataperhari) {
            $dataunit = array_merge($dataunit, $dataperhari);
        }
    }
    $headertext = "Laporan Penjualan Minggu Kemarin (" . date("M/d/Y", strtotime('last week')) . " - " . date("M/d/Y", strtotime('last week + 6 day')) . ") :";
} elseif ($idunit == "thismonth") {
    $dataunit   = $API->comm("/system/script/print", [
        "?owner" => strtolower(date("MY", strtotime('this month'))),
    ]);
    $headertext = "Laporan Penjualan Bulan ini (" . date("M/Y") . ") :";
} elseif ($idunit == "lastmonth") {
    $dataunit   = $API->comm("/system/script/print", [
        "?owner" => strtolower(date("MY", strtotime('first day of last month'))),
    ]);
    $headertext = "Laporan Penjualan Bulan Kemarin (" . date("M/Y", strtotime('first day of last month')) . ") :";
} elseif ($idunit == "alldays") {
    $dataunit   = $API->comm("/system/script/print", [
        "?comment" => "mikhmon",
    ]);
    $headertext = "Laporan Penjualan Seluruhnya :";
}

$jmldata    = count($dataunit);

$arrayprofile   = [];
$arrayomset     = [];
$totalomset     = 0;

foreach ($dataunit as $i => $du) {
    // oct/19/2022-|-08:08:17-|-fdut-|-10000-|-192.168.88.253-|-BC:EE:7B:B4:EE:69-|-12h-|-mikhmon1-|-up-591-10.18.22-
    $pecahdata   = explode("-|-", $du['name']);
    if (array_key_exists($pecahdata[7], $arrayprofile)) {
        $arrayprofile[$pecahdata[7]]++;
        $arrayomset[$pecahdata[7]] += $pecahdata['3'];
    } else {
        $arrayprofile[$pecahdata[7]] = 1;
        $arrayomset[$pecahdata[7]] = $pecahdata['3'];
    }

    $totalomset += $pecahdata['3'];
}

if ($totalomset == 0) {
    $totalomset = "-";
} else {
    if ($currency == in_array($currency, $cekindo['indo'])) {
        $totalomset = $currency . " " . number_format((float)$totalomset, 0, ",", ".");
    } else {
        $totalomset = $currency . " " . number_format((float)$totalomset);
    }
}

$text .= $headertext . "\n";
$text .= "jumlah vc terjual : $jmldata vcr\n";
$text .= "jumlah omset : $totalomset\n";
$text .= "========\n";
foreach ($arrayprofile as $i => $ap) {
    $text .= "vc terjual profile $i : " . $ap . " vcr\n";
}
$text .= "========\n";
foreach ($arrayomset as $i => $ao) {
    if ($ao == 0) {
        $ao = "-";
    } else {
        if ($currency == in_array($currency, $cekindo['indo'])) {
            $ao = $currency . " " . number_format((float)$ao, 0, ",", ".");
        } else {
            $ao = $currency . " " . number_format((float)$ao);
        }
    }
    $text .= "omset profile $i : " . $ao . "\n";
}
$text .= "========\n";


$array_luar = [
    [
        ['text' => "<< BACK", "callback_data" => '0|reportpages|' . $namarouter],
        ['text' => "CLOSE", "callback_data" => 'cancel'],
    ]
];

$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];

return Bot::editMessageText($options);

/*
variable yang diambil
- tanggal hari ini
- tanggal kemarin
- range minggu ini (hari ini sd 6 hari lalu)
- range minggu lalu ((hari ini - 7) - 6 hari lalu)
- bulan ini
- bulan lalu (ambil nama bulan lalu)

data yang ditampilkan
- total pendapatan
- jumlah voucher yang terjual
- jumlah voucher masing-masing profile

data nya ambil dari script dan list profile (maenan array)

data yang diambil :
- script yang mengandung kata mikhmon
- daftar nama profile hotspot

alur :
- filter data callback (inputan tanggal/bulan dll)
- ambil script yang mengandung kata mikhmon
- ambil semua profile hotspot
- lalu filter berdasarkan scheduler seperti profile page (icon hijau dan kuning), ambil yang icon hijau saja (ga jadi)
- bikin array untuk profile yang hijau (ga jadi)
- bikin array profile lalu setiap script di ambil nama profilenya :
    - jika profilenya belum ada di array maka bikin dengan value 1, jika sudah ada maka value array profile tsb + 1
- hitung jumlah script yang mengandung kata mikhmon
- 



#data tanggal bulan dan tahun hari ini
$tgl        = strtolower(date("M/d/Y"));
$tgl        = "oct/19/2022";

$mingguini = strtotime('this week');
$mingguini = date('M/d/Y', $mingguini);
$minggudpn = strtotime('next week - 1 day');
$minggudpn = date('M/d/Y', $minggudpn);

$hari[0] = strtotime('this week');
for ($i = 1; $i < 7; $i++) {
    $hari[$i] = strtotime("this week + $i day");
}

$totaldataunit = [];

foreach ($hari as $i => $hr) {
    $dataunit   = $API->comm("/system/script/print", [
        "?source" => strtolower(date('M/d/Y', $hr)),
    ]);
    if ($dataunit) {
        $totaldataunit = array_merge($totaldataunit, $dataunit);
    }
}

// foreach ($hari as $i => $h) {
//     $text .= "hari " . ($i + 1) . " : " . date('M/d/Y', $h) . "\n";
// }

$jmldata    = count($totaldataunit);

$arrayprofile   = [];
$arrayomset     = [];
$totalomset     = 0;

foreach ($totaldataunit as $i => $du) {
    // oct/19/2022-|-08:08:17-|-fdut-|-10000-|-192.168.88.253-|-BC:EE:7B:B4:EE:69-|-12h-|-mikhmon1-|-up-591-10.18.22-
    $pecahdata   = explode("-|-", $du['name']);
    if (array_key_exists($pecahdata[7], $arrayprofile)) {
        $arrayprofile[$pecahdata[7]]++;
        $arrayomset[$pecahdata[7]] += $pecahdata['3'];
    } else {
        $arrayprofile[$pecahdata[7]] = 1;
        $arrayomset[$pecahdata[7]] = $pecahdata['3'];
    }

    $totalomset += $pecahdata['3'];
}

$arrayscript    = [];

if ($totalomset == 0) {
    $totalomset = "-";
} else {
    if ($currency == in_array($currency, $cekindo['indo'])) {
        $totalomset = $currency . " " . number_format((float)$totalomset, 0, ",", ".");
    } else {
        $totalomset = $currency . " " . number_format((float)$totalomset);
    }
}




$text .= "jumlah vc terjual $tgl : $jmldata vcr\n";
$text .= "jumlah omset $tgl : $totalomset\n";
$text .= "minggu ini : $mingguini - $minggudpn\n";
$text .= "========\n";
$text .= "========\n";


foreach ($arrayprofile as $i => $ap) {
    $text .= "vc terjual profile $i : " . $ap . "\n";
}
foreach ($arrayomset as $i => $ao) {
    if ($ao == 0) {
        $ao = "-";
    } else {
        if ($currency == in_array($currency, $cekindo['indo'])) {
            $ao = $currency . " " . number_format((float)$ao, 0, ",", ".");
        } else {
            $ao = $currency . " " . number_format((float)$ao);
        }
    }
    $text .= "omset profile $i : " . $ao . "\n";
}

$array_luar = [
    [
        ['text' => "<< BACK", "callback_data" => '0|reportpages|' . $namarouter],
        ['text' => "CLOSE", "callback_data" => 'cancel'],
    ]
];

$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];

return Bot::editMessageText($options);
