<?php
$namarouter     = explode("|hotspotactivespages|", $command)[1];
$idunit         = explode("|hotspotactivespages|", $command)[0];
include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));
$dataunit       = $API->comm("/ip/hotspot/active/getall");
$jmlunit        = count($dataunit);
$array_luar     = [];
$array_dalam    = [];


if ($idunit == 0) {
    $halskr = 1;
} else {
    $halskr = ($idunit / $jmlperhal) + 1;
}

$jmlhal     = ceil($jmlunit / $jmlperhal);
$text       .= "jumlah user active saat ini : " . $jmlunit;
$text       .= "\n";
$text       .= "halaman $halskr dari " . $jmlhal;

if (($idunit + $jmlperhal) > $jmlunit) {
    $max_i  = $jmlunit;
} else {
    $max_i  = $idunit + $jmlperhal;
}

for ($i = $idunit; $i < $max_i; $i++) {
    $detailunit         = $dataunit[$i];
    $unitname           = $detailunit['user'];

    $inputdata   = ['text' => '' . $unitname . '', 'callback_data' => $i . '|hotspotactivename|' . $namarouter];
    array_push($array_dalam, $inputdata);
}

$splitarray    = array_chunk($array_dalam, $pecaharray);
foreach ($splitarray as $index => $satuan) {
    $satubaris     = array_filter([$satuan[0], $satuan[1], $satuan[2], $satuan[3]]);
    array_push($array_luar, $satubaris);
}

if ($jmlunit > $jmlperhal) {
    if ($halskr == 1 && $jmlunit > $jmlperhal) {
        $menunext   = [
            ['text' => 'NEXT >>', 'callback_data' => ($idunit + $jmlperhal) . '|hotspotactivespages|' . $namarouter]
        ];
    } elseif (($halskr * $jmlperhal) > $jmlunit) {
        $menunext   = [
            ['text' => '<< PREV', 'callback_data' => ($idunit - $jmlperhal) . '|hotspotactivespages|' . $namarouter]
        ];
    } else {
        $menunext   = [
            ['text' => '<< PREV', 'callback_data' => ($idunit - $jmlperhal) . '|hotspotactivespages|' . $namarouter],
            ['text' => 'NEXT >>', 'callback_data' => ($idunit + $jmlperhal) . '|hotspotactivespages|' . $namarouter]
        ];
    }



    array_push($array_luar, $menunext);
}
$closebutton    = [
    ['text' => '❌❌ CLOSE ❌❌', 'callback_data' => 'cancel'],
];

array_push($array_luar, $closebutton);

$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];


return Bot::editMessageText($options);
