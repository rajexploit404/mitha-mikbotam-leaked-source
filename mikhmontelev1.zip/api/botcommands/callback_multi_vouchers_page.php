<?php
$namarouter     = explode("|multivoucherspage|", $command)[1];
$idunit         = explode("|multivoucherspage|", $command)[0];
include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));
$dataunit       = $API->comm("/system/script/print", ["?comment" => "mikhmon-mitha"])[0];
$datajson       = json_decode($dataunit['source'], true);
$datavc         = $datajson['jenis voucher'];
$jmlunit        = count($datavc);
$array_luar     = [];
$array_dalam    = [];
$keys           = array_keys($datavc);


if ($idunit == 0) {
    $halskr = 1;
} else {
    $halskr = ($idunit / $jmlperhal) + 1;
}

if ($jmlunit == 0) {
    $text = "tidak ada jenis voucher di mikrotik ini, silahkan setting dahulu di mikhmon";
    $options    = [
        'chat_id'      => $chatidtele,
        'message_id'   => (int) $message['message']['message_id'],
        'text'         => $text,
        'parse_mode'   => 'html',
    ];


    return Bot::editMessageText($options);
}

$jmlhal     = ceil($jmlunit / $jmlperhal);
$text       .= "Silahkan Pilih Jenis Voucher : ";
$text       .= "\n";
$text       .= "---------";
$text       .= "\n";
foreach ($datavc as $i => $vc) {
    $text .= "<b>$i</b> : " . $vc['desc'];
    $text .= "\n";
}
$text       .= "\n";
$text       .= "---------";
$text       .= "\n";
$text       .= "halaman $halskr dari " . $jmlhal;

if (($idunit + $jmlperhal) > $jmlunit) {
    $max_i  = $jmlunit;
} else {
    $max_i  = $idunit + $jmlperhal;
}

for ($i = $idunit; $i < $max_i; $i++) {
    $unitname       = $keys[$i];
    $inputdata      = ['text' => $unitname . '', 'callback_data' => $unitname . '|multivouchersprocess1|' . $namarouter];
    array_push($array_dalam, $inputdata);
}

$splitarray    = array_chunk($array_dalam, $pecaharray);
foreach ($splitarray as $index => $satuan) {
    $satubaris     = array_filter([$satuan[0], $satuan[1], $satuan[2], $satuan[3]]);
    array_push($array_luar, $satubaris);
}

if ($jmlunit > $jmlperhal) {
    if ($halskr == 1 && $jmlunit > $jmlperhal) {
        $menunext   = [
            ['text' => 'NEXT >>', 'callback_data' => ($idunit + $jmlperhal) . '|multivoucherspage|' . $namarouter]
        ];
    } elseif (($halskr * $jmlperhal) > $jmlunit) {
        $menunext   = [
            ['text' => '<< PREV', 'callback_data' => ($idunit - $jmlperhal) . '|multivoucherspage|' . $namarouter]
        ];
    } else {
        $menunext   = [
            ['text' => '<< PREV', 'callback_data' => ($idunit - $jmlperhal) . '|multivoucherspage|' . $namarouter],
            ['text' => 'NEXT >>', 'callback_data' => ($idunit + $jmlperhal) . '|multivoucherspage|' . $namarouter]
        ];
    }



    array_push($array_luar, $menunext);
}
$closebutton    = [
    ['text' => '❌❌ CLOSE ❌❌', 'callback_data' => 'cancel'],
];

array_push($array_luar, $closebutton);

$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];


return Bot::editMessageText($options);
