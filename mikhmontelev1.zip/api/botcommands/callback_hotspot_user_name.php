<?php
$namarouter     = explode("|hotspotusername|", $command)[1];
$idunit         = explode("|hotspotusername|", $command)[0];
include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));
$dataunit       = $API->comm("/ip/hotspot/user/getall");
$jmlunit        = count($dataunit);
$array_luar     = [];
$array_dalam    = [];


$i = (ceil($idunit / $jmlperhal) - 1) * 20;

$detailunit     = $dataunit[$idunit];
$uid            = $detailunit['.id'];
$userver        = $detailunit['server'];
$uname          = $detailunit['name'];
$upass          = $detailunit['password'];
$umac           = $detailunit['mac-address'];
$uprofile       = $detailunit['profile'];
$uuptime        = formatDTM($detailunit['uptime']);
$ueduser        = $detailunit['disabled'];
$utimelimit     = $detailunit['limit-uptime'];
$udatalimit     = $detailunit['limit-bytes-total'];
$ubytesout      = $detailunit['bytes-out'];
$ubytesin       = $detailunit['bytes-in'];
$ucomment       = $detailunit['comment'];

$getprofilebyuser = $API->comm("/ip/hotspot/user/profile/print", array(
    "?name" => "$uprofile"
));
$profiledetalis = $getprofilebyuser[0];
$ponlogin = $profiledetalis['on-login'];
$getvalid = explode(",", $ponlogin)[3];
$getprice = explode(",", $ponlogin)[2];
$getsprice = explode(",", $ponlogin)[4];

if ($getprice == 0) {
    $getprice = "-";
} else {
    if ($currency == in_array($currency, $cekindo['indo'])) {
        $getprice = $currency . " " . number_format((float)$getprice, 0, ",", ".");
    } else {
        $getprice = $currency . " " . number_format((float)$getprice);
    }
}

if ($getsprice == 0) {
    $getsprice = '-';
} else {
    if ($currency == in_array($currency, $cekindo['indo'])) {
        $getsprice = $currency . " " . number_format((float)$getsprice, 0, ",", ".");
    } else {
        $getsprice = $currency . " " . number_format((float)$getsprice);
    }
}

if ($userver == "") {
    $userver = "all";
}

if (substr(formatBytes2($udatalimit, 2), -2) == "MB") {
    $udatalimit = $udatalimit / 1048576;
    $MG = "MB";
} elseif (substr(formatBytes2($udatalimit, 2), -2) == "GB") {
    $udatalimit = $udatalimit / 1073741824;
    $MG = "GB";
} elseif ($udatalimit == "") {
    $udatalimit = "";
    $MG = "MB";
}

if ($uname == $upass) {
    $usermode = "vc";
} else {
    $usermode = "up";
}

if ($ueduser == 'true') {
    $status = 'No';
} else {
    $status = 'Yes';
}

if ($uuptime == 0) {
    $uuptime = null;
}

if ($ubytesin == 0) {
    $ubytesin = null;
} else {
    $ubytesin = formatBytes($ubytesin, 2);
}
if ($ubytesout == 0) {
    $ubytesout = null;
} else {
    $ubytesout = formatBytes($ubytesout, 2);
}

if ($utimelimit == "1s") {
    $utimelimit = null;
}

$text   .= "detail voucher : <b>" . $uname . "</b>\n";
$text   .= "--------------\n";
$text   .= "<code>\n";
$text   .= "Enabled      : " . $status . "\n";
$text   .= "Server       : " . $userver . "\n";
$text   .= "Name         : " . $uname . "\n";
$text   .= "Password     : " . $upass . "\n";
$text   .= "Profile      : " . $uprofile . "\n";
$text   .= "Mac Address  : " . $umac . "\n";
$text   .= "Uptime       : " . $uuptime . "\n";
$text   .= "Bytes In/Out : " . $ubytesin . "/" . $ubytesout . "\n";
$text   .= "Time Limit   : " . $utimelimit . "\n";
$text   .= "Data Limit   : " . $udatalimit . " $MG\n";
$text   .= "Comment      : " . $ucomment . "\n";
$text   .= "--------------\n";
$text   .= "Price          : " . $getprice . "\n";
$text   .= "Selling Price  : " . $getsprice . "\n";
$text   .= "--------------\n";
$text   .= "Validity     : " . $getvalid . "\n";
$text   .= "--------------\n";

$text   .= "</code>";

$array_luar = [
    [
        ['text' => "<< BACK", "callback_data" => (floor($idunit / $jmlperhal) * $jmlperhal) . '|hotspotuserspages|' . $namarouter],
        ['text' => "CLOSE", "callback_data" => 'cancel'],
    ]
];

$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];

return Bot::editMessageText($options);
