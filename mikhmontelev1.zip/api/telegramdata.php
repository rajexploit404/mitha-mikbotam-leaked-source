<?php
// hide all error
error_reporting(0);
if (!isset($_SESSION["mikhmon"])) {
    header("Location:../admin.php?id=login");
} else {
    if (isset($_POST['save'])) {
        $token      = $_POST['token'];
        $botuser    = $_POST['botusername'];
        $idtele     = $_POST['idtelegram'];

        $datanya = <<<DATA
        <?php
        \$token         = "$token";
        \$usernamebot   = "$botuser";
        \$owner         = "$idtele";
        ?>
        DATA;

        $handle = fopen('./api/config.php', 'w');
        fwrite($handle, $datanya);
        $info = "data updated";
    }
    include('./api/config.php');

    function webhook($command, $tokennya)
    {
        $ch     = curl_init();
        $url    = 'https://api.telegram.org/bot' . $tokennya . '/' . $command;

        // set url 
        curl_setopt($ch, CURLOPT_URL, $url);

        // return the transfer as a string 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // $output contains the output string 
        $output = curl_exec($ch);

        // tutup curl 
        curl_close($ch);

        return json_decode($output, true);
    }

    if (isset($_POST['setwebhook'])) {

        $setwebhook = webhook('setWebhook?url=https://' . $_SERVER['HTTP_HOST'] . '/bottele.php', $token);
    } else if (isset($_POST['unsetwebhook'])) {
        $setwebhook = webhook('deleteWebhook', $token);
    }

    $webhookinfo = webhook('getWebhookInfo', $token);
    if ($webhookinfo['result']['url'] == '') {
        $set = false;
    } else {
        $set = true;
    }
}
?>


<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fa fa-telegram"></i> BOT TELEGRAM SETTINGS</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-7">
                        <form autocomplete="off" method="post" action="">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fa fa-id-card-o"></i> TELEGRAM DETAILS (<?= $info; ?>)</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-sm">
                                        <tr>
                                            <td class="align-middle">BOT TOKEN</td>
                                            <td>
                                                <input class="form-control" id="token" type="text" size="10" name="token" title="Bot Token" value="<?= $token ?>" required />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle">BOT USERNAME</td>
                                            <td>
                                                <input class="form-control" id="botusername" type="text" size="10" name="botusername" title="Bot Username" value="<?= $usernamebot ?>" required />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="align-middle">ID TELEGRAM OWNER</td>
                                            <td>
                                                <input class="form-control" id="idtelegram" type="text" size="10" name="idtelegram" title="ID Telegram Owner" value="<?= $owner ?>" required />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td class="text-right">
                                                <div class="input-group-4">
                                                    <input class="group-item group-item-l" type="submit" style="cursor: pointer;" name="save" />
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-5">
                        <form autocomplete="off" method="post" action="">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fa fa-plug"></i> TELEGRAM WEBHOOK</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-sm">
                                        <tr>
                                            <td class="align-middle">STATUS</td>
                                            <td>
                                                <div class="text text-<?php echo ($set) ? 'success' : 'danger'; ?>">
                                                    <?php echo ($set) ? 'CONNECTED' : 'DISCONNECTED'; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td class="text-right">
                                                <div class="input-group-4">
                                                    <?php if ($set) { ?>
                                                        <input class="group-item group-item-l" type="submit" style="cursor: pointer;" name="unsetwebhook" value="UNSET WEBHOOK" />
                                                    <?php } else { ?>
                                                        <input class="group-item group-item-l" type="submit" style="cursor: pointer;" name="setwebhook" value="SET WEBHOOK" />
                                                    <?php } ?>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>