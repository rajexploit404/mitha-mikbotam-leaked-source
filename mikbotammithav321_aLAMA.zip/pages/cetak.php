<?php
include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Saldo/rpt/functions.php';
include '../Api/routeros_api.class.php';
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);
session_start();

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {

    $semuavoucher   = json_decode($_POST['semuavoucher'], true);
    $validity       = $_POST['validity'];
    $harga          = $_POST['harga'];
    $tipevoucher    = $_POST['tipevoucher'];
    $pilihqrcode    = $_POST['pilihqrcode'];
    $reseller       = $_POST['reseller'];
    $hotspotname    = $Name_router;

    //jika qrcode yes maka tampilkan qrcode
    if ($pilihqrcode == 'qrcodeyes') {
        $qr = "yes";
    }

    //===ambil data gambar
    $arraytext = ngambiltext($_SESSION['Mikbotamid']);
    $gambar = json_decode($arraytext, true);
    $logo = '../img/logo.png';
    $logostatus = $gambar['vc_logo'];

?>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Voucher-<?= $dnsname . "-" . $gn_jvc . "-" . rupiah($gn_hrg); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="pragma" content="no-cache" />
        <link rel="icon" href="../img/favicon.png" />
        <script src="../js/qrious.min.js"></script>
        <style>
            body {
                color: #000000;
                background-color: #FFFFFF;
                font-size: 14px;
                font-family: 'Helvetica', arial, sans-serif;
                margin: 0px;
                -webkit-print-color-adjust: exact;
            }

            table.voucher {
                display: inline-block;
                border: 2px solid black;
                margin: 2px;
            }

            @page {
                size: auto;
                margin-left: 7mm;
                margin-right: 3mm;
                margin-top: 9mm;
                margin-bottom: 3mm;
            }

            @media print {
                table {
                    page-break-after: auto
                }

                tr {
                    page-break-inside: avoid;
                    page-break-after: auto
                }

                td {
                    page-break-inside: avoid;
                    page-break-after: auto
                }

                thead {
                    display: table-header-group
                }

                tfoot {
                    display: table-footer-group
                }
            }

            #num {
                float: right;
                display: inline-block;
            }

            .qrc {
                width: 30px;
                height: 30px;
                margin-top: 1px;
            }
        </style>
    </head>

    <body onload="window.print()">

        <?php
        if (count($semuavoucher) > 0) {
            for ($i = 0; $i < count($semuavoucher); $i++) {;
                $uid = str_replace("=", "", base64_encode($i));;
                $username   = $semuavoucher[$i]['name'];
                $password   = $semuavoucher[$i]['password'];
                $profile    = $semuavoucher[$i]['profile'];
                $timelimit  = $semuavoucher[$i]['limit-uptime'];
                $datalimit  = $semuavoucher[$i]['limit-bytes-total'];
                $gn_lup     = $timelimit;
                $comment = ' | voc : ' . $gn_jvc . ' (' . rupiah($gn_hrg);
                if ($datalimit == 0) {
                    $datalimit = "";
                }
                $price = "(" . $harga . ")";
                $urilogin = "http://$dnsname/login?username=$username&password=$password";
                $qrcode = "
<canvas class='qrcode' id='" . $uid . "'></canvas>
<script>
(function() {
var " . $uid . " = new QRious({
  element: document.getElementById('" . $uid . "'),
  value: '" . $urilogin . "',
  size:'256'
});

})();
</script>
";
                //jika username = password maka otomatis 1 kode
                if ($username == $password) {
                    $usermode = 'vc';
                } else {
                    $usermode = "up";
                }

                $num = $i + 1;

                //pilih template
                if ($tipevoucher == 'default') {
                    include('./templates/default.php');
                } else if ($tipevoucher == 'tinydefault') {
                    include('./templates/default-small.php');
                } else if ($tipevoucher == 'custom') {
                    include('./templates/template.php');
                } else if ($tipevoucher == 'tinycustom') {
                    include('./templates/template-small.php');
                }
            }
        }  ?>

    </body>

    </html>
<?php
}
