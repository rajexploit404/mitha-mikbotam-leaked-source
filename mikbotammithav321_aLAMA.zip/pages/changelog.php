<div class="sl-pagebody tx-center">
   <h1>CHANGELOG</h1>

   <p>
      <b>PERINTAH TAMBAHAN BOT TELEGRAM YANG TERSEDIA</b> <br>
      - <b>/pppoe</b> : untuk mengontrol user secret pppoe <br>
      - <b>/otodepo</b> : untuk deposit otomatis via payment gateway <br>
      - <b>/laptgl spasi tglbulantahun</b>, contoh : /laptgl 30012020<br>
      - <b>/lapbul</b> : untuk melihat laporan bulan ini<br>
      - <b>/lap spasi tglblnthnawal spasi tglblnthnakhir</b>, contoh : /lap 01012020 12022020 <br>
      - <b>/reseller</b> : untuk menampilkan data reseller<br>
      - <b>/cekvcr spasi kode voucher</b> : untuk melihat masa aktif voucher yang dibuat menggunakan mitha <br>
      - <b>/pesan spasi isi pesan</b> : untuk mengirim pesan ke seluruh reseller<br>
      - <b>/rekap</b> : untuk memunculkan hasil transaksi hari ini <br>
      - <b>/rekap spasi tglblnthn spasi tglblnthn</b>, contoh : /rekap 12042020 07112020<br>
      - <b>/rekapall</b> : untuk melihat rekapan masing-masing reseller<br>
      - <b>/delreport</b> : untuk menghapus laporan bulan lalu atau laporan setelah 3 bulan yang lalu, membuat kinerja server dan bot menjadi ringan<br>
      - <b>/help</b> : untuk melihat perintah yang lain<br>

      <br>
      <b>Januari 2022 (M.I.T.H.Assistant) v3.2.1</b><br>
      - bug fix logo, hanya png <br>
      - bug fix cetak voucher <br>
      - bug fix laporan per reseller <br>

      <br>
      <b>Desember 2021 (M.I.T.H.Assistant) v3.2</b><br>
      - notifikasi ke bot telegram jika ada yang login ke web <br>
      - /menu ada tahap konfirmasi (menghindari salah pencet voucher) <br>
      - /topup ganti tampilan, tidak perlu menghafal ID telegram <br>
      - group voucher untuk default user baru, jika tidak ada voucher yang masuk default maka user baru tidak akan melihat daftar voucher <br>
      - sistem uplink dan downlink (fee 10% dari margin) <br>
      - menu PPPoE dengan opsi pindah profile atau disable user secret <br>
      - /pppoe dan /otodepo command <br>
      - menu cetak ulang voucher fisik <br>
      - cetak voucher thermal dari telegram <br>
      - menu payment gateway tripay <br>
      - menu search untuk mencari user <br>
      - /daftar akan ada approval dari admin <br>
      - group telegram info seputar MIKBOTAM MITHA di <a href="https://t.me/+m0QW8XzDpCIwYzk9">Group INFO MIKBOTAM MITHA</a> <br>


      <br>
      <b>Desember 2020 (M.I.T.H.Assistant) v3.1</b> <br>
      - Template Generate Voucher bisa menggunakan template mikhmon (settings>settings template)<br>
      - Menu /hotspot dimunculkan kembali<br>
      - fitur transfer antar reseller : /transfer spasi nomor ID tujuan spasi nominal<br>
      - data omset bulan lalu dan bulan sekarang di dashboard <br>
      - fitur Grup Reseller dan Voucher (voucher dengan grup tertentu hanya bisa diakses oleh reseller dengan grup yang sama) <br>
      - topup instant via /deposit dimunculkan kembali <br>
      - fitur rekap omset reseller : /rekap (bisa dipakai semua reseller) dan /rekapall (hanya akses admin)<br>
      - fitur delete rekapan : /delreport , untuk menghapus laporan bulan lalu dan atau setelah 3 bulan yg lalu, berfungsi untuk meringankan kinerja server dan bot <br>
      - fitur FUP di Profile Hotspot<br>

      <br>
      <b>Juni 2020 (M.I.T.H.Assistant) v3.0</b> <br>
      - rebranding jadi M.I.T.H.Assistant<br>
      - perbaikan bug bot<br>
      - voucher dengan nama yang diinginkan<br>
      - notif voucher ke reseller <br>
      - webhook pindah ke settings <br>
      - perbaikan tampilan voucher <br>
      - penghapusan section edit core.php karena sudah tidak relevan <br>
      - diskon dalam persen untuk masing masing reseller <br>
      - generate voucher secara massal, output berbentuk pdf, dan dikirim ke telegram admin<br>
      - fitur sinkronisasi tombol delete dengan mikrotik <br>
      - delete voucher secara massal berdasarkan username / tipe voucher (termasuk yang ada di mikrotik)<br>
      - perubahan tampilan dashboard <br>
      - info voc di dashboard menampilkan kapan user tsb online pertama kali dan kapan akan berakhir<br>



      <br>
      <b>April 2020 (rumahpetir) v2.7.1</b> <br>
      - tambah command bot : /pesan untuk mengirim pesan massal ke reseller <br>
      - remake telegram voucher info <br>
      - menu logo voucher<br>
      - cek laporan range tanggal tertentu, termasuk detail reseller <br>
      - tombol hapus voucher dan history reseller<br>
      - prefix di voucher, untuk memberi ciri pada jenis voucher <br><br>

      <b>3 April 2020 (rumahpetir) v2.6</b> <br>
      - unlimited voucher profile list <br>
      - menu setting text response bot <br>
      - max top up 9.999.999 <br><br>

      <b>25 Februari 2020 (rumahpetir) v2.5</b> <br>
      - tambah menu di USER PROFILE HOTSPOT <br>
      - tambah fitur pilihan auto delete voucher jika sudah berakhir <br>
      - tambah fitur pilihan notif via telegram ketika pertama kali voucher digunakan <br>
      (fitur ditambahkan di file add_profile.php) <br>
      - edit limit uptime di voucher dari null menjadi default 0 <br>
      - hapus GoCostumer <br>
      - hapus Voucher Non Saldo <br>
      - hapus SMS Gateway <br>
      - menambah menu change log <br><br>

      <b>05 Februari 2020 (rumahpetir) v2.3<br></b>
      - hapus /qrcode <br><br>

      <b>28 Januari 2020 (rumahpetir) v2.3<br></b>
      - move some codes to new files<br><br>

      <b>27 Januari 2020 (rumahpetir) v2.2.2<br></b>
      - update daily report via telegram<br>
      - update monthly report via telegram<br>
      - add /cekuser, /reseller, and new command to /help<br><br>

      <b>24 Januari 2020 (rumahpetir) v2.2.1 <br></b>
      - update check voucher<br><br>

      <b>02 Januari 2020 (rumahpetir) v2.2<br></b>
      - Add reseller list to bot<br><br>

      <b>19 November 2019 (rumahpetir) v2.1<br></b>
      - Add delete button on history user<br><br>

      <b>2 November 2019 (rumahpetir) v2.0<br></b>
      - Add Check Voucher Expired page<br>
      - Add command /cekvcr<br><br>
   </p>

</div>