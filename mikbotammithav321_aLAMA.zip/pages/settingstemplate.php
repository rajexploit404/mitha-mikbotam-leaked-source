<?php
$bottype = $_GET['bottype'];

if (isset($_POST['save'])) {
    if ($bottype == "custom") {
        $file = './templates/template.php';
    } elseif ($bottype == "tinycustom") {
        $file = './templates/template-small.php';
    } elseif ($bottype == "thermalcustom") {
        $file = './templates/template-thermal.php';
    }

    $openthis = fopen($file, 'w') or die('Cannot open file:  ' . $file);

    $data = ($_POST['editor']);

    fwrite($openthis, $data);
}

if ($bottype == "custom") {
    $telplatet = "template";
    $popup = "javascript:window.open('vpreview.php?usermode=up&qr=no&','_blank','width=310,height=310')";
    $popupQR = "javascript:window.open('vpreview.php?usermode=up&qr=yes&','_blank','width=310,height=310')";
} elseif ($bottype == "tinycustom") {
    $telplatet = "template-small";
    $popup = "javascript:window.open('vpreview.php?usermode=up&small=yes&qr=no&','_blank','width=310,height=310')";
    $popupQR = "javascript:window.open('vpreview.php?usermode=up&small=yes&qr=yes&','_blank','width=310,height=310')";
} elseif ($bottype == 'thermalcustom') {
    $telplatet = "template-thermal";
    $popup = "javascript:window.open('vpreview.php?usermode=up&user=thermal&qr=no&','_blank','width=310,height=310')";
    $popupQR = "javascript:window.open('vpreview.php?usermode=up&user=thermal&qr=yes&','_blank','width=310,height=310')";
}

?>

<!-- Load Lib ace editor -->
<script src="../lib/ace/ace/ace.js"></script>
<script src="../lib/ace/ace/theme-twilight.js"></script>
<script src="../lib/ace/ace/mode-php.js"></script>
<script src="../lib/ace/jquery-ace.min.js"></script>


<div class="sl-pagebody pd-sm-5">
    <div class="row row-sm">
        <div class="col-sm-8">
            <div class="card bd-primary mg-t-3">
                <div class="card-header bg-primary tx-white"><i class="icol-ui-tab-content"></i> Edit Template Voucher</div>
                <div class="card-body pd-sm-5 ">
                    <form autocomplete="off" method="post" action="">

                        <div class="pd-10">

                            <button type="submit" title="Save <?= $bottype ?>.php" class="btn bg-primary tx-white" name="save"><i class="fa fa-save"></i> Save</button>

                            <select class="form-control select2id" onchange="window.location.href=this.value " style="width: 194px;" data-placeholder="Select Type">
                                <option><?= ucfirst($bottype); ?></option>
                                <option value="./index.php?Mikbotam=settingstemplate&bottype=custom">Custom</option>
                                <option value="./index.php?Mikbotam=settingstemplate&bottype=tinycustom">Tiny Custom</option>
                                <option value="./index.php?Mikbotam=settingstemplate&bottype=thermalcustom">Thermal Custom</option>
                            </select>

                            <a class="btn bg-green" href="<?= $popup ?>" title="View voucher with Logo"><i class="fa fa-image"></i> </a>
                            <a class="btn bg-green" href="<?= $popupQR ?>" title="View voucher with  QR"><i class="fa fa-qrcode"></i> </a>

                        </div>

                        <textarea id="mikbotamedit" class="from-control db" rows="30" style="width: 100%" name="editor">

                        <?php
                        if ($bottype == "custom") {
                            echo file_get_contents('./templates/template.php');
                        } elseif ($bottype == "tinycustom") {
                            echo file_get_contents('./templates/template-small.php');
                        } elseif ($bottype == 'thermalcustom') {
                            echo file_get_contents('./templates/template-thermal.php');
                        }
                        ?>

					
					
	        </textarea>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-4 mg-t-2">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white"><i class="fa   fa-info-circle"></i> INFO</div>
                <div class="card-body pd-sm-15">
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <p>

                                        <code>Kredit TEMPLATE</code> : agan LAKSAMADI GUKO pengembang MIKHMON
                                        <br><br>
                                        Agan bisa gunakan template bawaan mikhmon atau yang dimodding untuk mikhmon
                                        <br><br>
                                        Variable yang tersedia :<br>
                                        - reseller : $reseller<br>
                                        - variable lain mirip mikhmon
                                    </p>



                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    var _0x627b = ["tomorrow", "php", "ace", "#mikbotamedit"];
    $(_0x627b[3])[_0x627b[2]]({
        theme: _0x627b[0],
        lang: _0x627b[1]
    })
</script>