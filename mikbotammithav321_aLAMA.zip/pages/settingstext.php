<?php
//=====================================================START====================//

/*
 *  RUMAH PETIR v2.7
 *
 */

//=====================================================START SCRIPT====================//
error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {
    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Saldo/rpt/functions.php';


    $id = $_SESSION['Mikbotamid'];

    //===simpen datanya

    if (isset($_POST['savetext'])) {
        $textbaru = [

            "daftar"        => $_POST['daftar_txt'],
            "menu_header"   => $_POST['menu_header'],
            "informasi"     => $_POST['informasi'],
            "saldo_footer"  => $_POST['saldo_footer'],
            "vc_footer"     => $_POST['voucher_footer'],
            "vc_logo"       => $_POST['voucher_logo'],
            "info_depo"     => $_POST['info_depo'],
            "vc_url"        => 'https://' . $_SERVER['HTTP_HOST'] . '/img/logo.png'

        ];

        //===validasi image
        if (!empty($_FILES['file']['name'])) {

            $nameimg    = $_FILES['file']['name'];
            $targetdir  = "img/";
            $targetFile = $targetDir . basename($_FILES['file']['name']);
            $maxsize = 1024 * 200; // maksimal 200 KB (1KB = 1024 Byte)
            $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            $extensions_arr = array("png");
            if (in_array($fileType, $extensions_arr) && $_FILES['file']['size'] <= $maxsize) {
                move_uploaded_file($_FILES['file']['tmp_name'], '../img/logo.png');
                $enc_text = json_encode($textbaru);
                $simpantext = masukintext($enc_text, $id);
                $info = "<div class='alert alert-primary' role='alert'>
                        Data dan image berhasil disimpan. silahkan refresh jika data belum berubah.
                        </div>";
            } else {

                $info = "<div class='alert alert-danger' role='alert'>
                        Gagal menyimpan : ukuran gambar melebihi 200kb atau file yang diupload bukan jpg/png.
                        </div>";
            }
        } else {
            $enc_text = json_encode($textbaru);
            $simpantext = masukintext($enc_text, $id);
            $info = "<div class='alert alert-primary' role='alert'>
                    Data berhasil disimpan. silahkan refresh jika data belum berubah.
                    </div>";
        }
    }

    //===ambil datanya
    $arraytext = ngambiltext($id);
    $textnya = json_decode($arraytext, true);


?>
    <div class="sl-pagebody">
        <h1 class="tx-center">Global Settings</h1>
        <?php echo $info; ?>
        <div class="row row-sm mg-t-1">
            <div class="col-xl-8 mg-t-10">
                <div class="card bd-primary">
                    <div class="card-header bg-primary tx-white">
                        <i class="fa  fa-paper-plane"></i> Text Settings
                    </div>
                    <div class="card-body pd-sm-15">
                        <form method="POST" action="" enctype="multipart/form-data">

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="1"> /daftar </label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['daftar'] ?>" id="1" name="daftar_txt" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="2">/menu - header</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['menu_header'] ?>" id="2" name="menu_header" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="3">INFORMASI</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['informasi'] ?>" id="3" name="informasi" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="4">saldo - footer </label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['saldo_footer'] ?>" id="4" name="saldo_footer" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="5">voucher - footer</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['vc_footer'] ?>" id="5" name="voucher_footer" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="6">info Deposit</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['info_depo'] ?>" id="6" name="info_depo" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="7">Logo Voucher : </label>
                                <div class="col-lg">
                                    <input type="radio" name="voucher_logo" value="1" <?php if ($textnya['vc_logo'] == '1') {
                                                                                            echo "checked";
                                                                                        }  ?>> Default <br></label>
                                    <input type="radio" name="voucher_logo" value="2" <?php if ($textnya['vc_logo'] == '2') {
                                                                                            echo "checked";
                                                                                        }  ?>> None <br></label>
                                    <input type="radio" name="voucher_logo" value="3" <?php if ($textnya['vc_logo'] == '3') {
                                                                                            echo "checked";
                                                                                        }  ?>> Logo sendiri <br></label>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="8">Upload Logo (max 200kb)</label>
                                <div class="col-lg">
                                    <input type="file" id="file" name="file" accept="image/*" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" onchange="previewImage()"> </input>
                                    <img src="" alt="" class="img-preview img-fluid mb-3 col-sm-5">
                                </div>
                            </div>


                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead "></label>
                                <div class="col-lg">
                                    <button type="submit" class="btn bg-primary tx-white" name="savetext">Save changes</button>
                                    <button type="reset" class="btn btn-danger">Reset</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

            </div>


            <div class="col-xl-4 mg-t-10">
                <div class="card bd-primary">
                    <div class="card-header bg-primary tx-white"> Petunjuk</div>
                    <div class="card-body pd-sm-15">
                        <table>
                            <tbody>
                                <tr>
                                    <td>
                                        <p>
                                            <code>/daftar</code><br>
                                            ini akan muncul ketika client/reseller mengetik perintah /daftar untuk pertama kalinya (sebelum terdaftar)<br><br>
                                            <code>/menu - header</code><br>
                                            ini akan muncul di bagian paling atas ketika client/reseller mengetik perintah /menu<br><br>
                                            <code>INFORMASI</code><br>
                                            ini akan muncul ketika client/reseller mengklik tombol informasi dalam bot<br><br>
                                            <code>saldo - footer</code><br>
                                            ini akan muncul pada bagian bawah ketika client/reseller mengecek saldo<br><br>
                                            <code>voucher - footer</code><br>
                                            ini akan muncul pada bagian bawah voucher yang di generate<br><br>
                                            <code>info Deposit</code><br>
                                            ini akan muncul pada saat reseller ketik /deposit, contoh : info no rekening<br><br>
                                            <code>PINDAH BARIS</code><br>
                                            gunakan perintah "ENTER" untuk pindah baris, harus huruf besar dan tanpa tanda petik<br><br>
                                            <code>LOGO</code><br>
                                            file yang diperbolehkan : png, max ukuran 200kb max resolusi 150 x 50<br><br>
                                        </p>



                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <script>
            function previewImage() {
                const image = document.querySelector("#file");
                const imgPreview = document.querySelector('.img-preview');
                imgPreview.style.display = 'block';

                const oFReader = new FileReader();
                oFReader.readAsDataURL(image.files[0]);

                oFReader.onload = function(ofREvent) {
                    imgPreview.src = ofREvent.target.result;
                }
            }
        </script>

    <?php $textnya = [];
} ?>