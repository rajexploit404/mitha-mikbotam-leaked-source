<?php
include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Saldo/rpt/functions.php';
include '../Api/routeros_api.class.php';
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);
session_start();

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {
    $API = new routeros_api();
    $fp = @fsockopen($mikrotik_ip, $mikrotik_port, $errCode, $errStr, 1);
    if ($fp) {
        if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            //ambil data jumlah terahir generate voucher

            $ambilvcterahir = explode('|+|', ambilvcgen($_SESSION['Mikbotamid']));
            $jmlvcterahir = $ambilvcterahir[0];
            $commentvcterahir = $ambilvcterahir[1];
            $harga = explode(')', explode('(', $commentvcterahir)[1])[0];

            //ambil data nama reseller

            $arrayres = lihatdata();

            //ambil data voucher

            $arrayvoc = getvoc($_SESSION['Mikbotamid']);
            $textnya = json_decode($arrayvoc, true);

            //seleksi voucher berdasarkan pilihan GET

            $opsipilihan = $_GET['pilihvoucher'];

            if ($opsipilihan == 'terbaru') {
                //ambil semua voucher di mikrotik yang commentnya mengandung di database voucher_generate

                $semuavoucher   = $API->comm('/ip/hotspot/user/print', ["?comment" => $commentvcterahir]);
                $indexvoucher   = count($semuavoucher) - $jmlvcterahir;
                array_splice($semuavoucher, 0, $indexvoucher);
            } else if ($opsipilihan == 'custom') {

                //format | ID : tekinamaku | voc : 7hr-5mbps (Rp 14.000) | tgl : 14-11-2021 | MIKBOTAM-AUTO GENERATE |
                $pecahvoucher       = explode("+", $_GET['jenisvoucher']);
                $jenisvoucher       = $pecahvoucher[0];
                $hargavoucher       = $pecahvoucher[1];
                $resellervoucher    = $_GET['reseller'];
                $tanggalvoucher     = $_GET['tanggalvoucher'];
                $komenvoucher       = "| ID : $resellervoucher | voc : $jenisvoucher (" . rupiah($hargavoucher) . ") | tgl : $tanggalvoucher | MIKBOTAM-AUTO GENERATE |";
                $semuavoucher       = $API->comm('/ip/hotspot/user/print', ["?comment" => $komenvoucher]);
                $harga              = rupiah($hargavoucher);
            }

            //ambil nama profile dari voucher yang dimikrotik

            $gn_pro     = $semuavoucher[0]['profile'];

            //===ambil data gambar
            $arraytext = ngambiltext($_SESSION['Mikbotamid']);
            $gambar = json_decode($arraytext, true);
            $logo = '../img/logo.png';
            $logostatus = $gambar['vc_logo'];

            //jika qrcode yes maka tampilkan qrcode
            if ($_GET['pilihqrcode'] == 'qrcodeyes') {
                $qr = "yes";
            }

            //===ambil masa aktif di profile - validity
            $baris = $API->comm('/ip/hotspot/user/profile/print', ["?name" => $gn_pro]);
            $dataonlogin = $baris[0]['on-login'];


            if (preg_match("/rmcde/i", $dataonlogin)) {

                $ambildata = explode("ut (\"", $dataonlogin);

                if (preg_match("/idtelegram/", $dataonlogin)) {

                    $ambildata2 = explode("\");:local idtelegram (\"", $ambildata[1]);

                    $durasi3 = $ambildata2[0];
                } else if (preg_match("/namaadmin/", $dataonlogin)) {

                    $ambildata2 = explode("\");:local namaadmin (\"", $ambildata[1]);

                    $durasi3 = $ambildata2[0];
                } else {
                    $durasi3 = "";
                }
                //===ambil hari
                $hari1  = explode("d ", $durasi3);
                $hari2  = $hari1[0];
                if (empty($hari2) || $hari2 == "000" || $hari2 == "00" || $hari2 == "0") {
                    $hari2 = "";
                } else {
                    $hari2 = $hari2 . 'd ';
                }

                //===ambil jam
                $pecahwaktu = explode(":", $hari1[1]);
                $jam        = $pecahwaktu[0];
                $menit      = $pecahwaktu[1];
                $detik      = $pecahwaktu[2];

                if (empty($jam) || $jam == "00" || $jam == "0") {
                    $jam = "";
                } else {
                    $jam = $jam . 'h ';
                }
                if (empty($menit) || $menit == "00" || $menit == "0") {
                    $menit = "";
                } else {
                    $menit = $menit . 'm ';
                }
                if (empty($detik) || $detik == "00" || $detik == "0") {
                    $detik = "";
                } else {
                    $detik = $detik . 's ';
                }

                $validity = $hari2 .  $jam .  $menit . $detik;
            } else {

                $validity = "-";
            }
            $hotspotname = $Name_router;

?>

            <head>
                <script src="../js/qrious.min.js"></script>
                <style>
                    body {
                        color: #000000;
                        background-color: #FFFFFF;
                        font-size: 14px;
                        font-family: 'Helvetica', arial, sans-serif;
                        margin: 0px;
                        -webkit-print-color-adjust: exact;
                    }

                    table.voucher {
                        display: inline-block;
                        border: 2px solid black;
                        margin: 2px;
                    }

                    @page {
                        size: auto;
                        margin-left: 7mm;
                        margin-right: 3mm;
                        margin-top: 9mm;
                        margin-bottom: 3mm;
                    }

                    @media print {
                        table {
                            page-break-after: auto
                        }

                        tr {
                            page-break-inside: avoid;
                            page-break-after: auto
                        }

                        td {
                            page-break-inside: avoid;
                            page-break-after: auto
                        }

                        thead {
                            display: table-header-group
                        }

                        tfoot {
                            display: table-footer-group
                        }
                    }

                    #num {
                        float: right;
                        display: inline-block;
                    }

                    .qrc {
                        width: 30px;
                        height: 30px;
                        margin-top: 1px;
                    }
                </style>
            </head>
            <div class="container">
                <div class="row alert alert-primary">
                    <div class="col-sm-12">
                        <div class="card text-black bg-info" style="height: 100%;">
                            <div class="card-header">
                                Pilih Voucher yang akan dicetak
                            </div>
                            <form action="">
                                <div class="card-body text-white">
                                    <select class="custom-select mb-3" style="width: 100%;" name="pilihvoucher">
                                        <option value="none">Pilih Voucher....</option>
                                        <option value="terbaru" <?php if ($_GET['pilihvoucher'] == 'terbaru') {
                                                                    echo "selected";
                                                                } ?>>Terbaru</option>
                                        <option value="custom" <?php if ($_GET['pilihvoucher'] == 'custom') {
                                                                    echo "selected";
                                                                } ?>>custom</option>
                                    </select>
                                    <div class="d-flex pd-y-10 pd-md-y-0 justify-content-center mb-3" id="customid">
                                        <div class="input-group col-sm-4">
                                            <span class="input-group-addon"><i class="fa fa-calendar tx-16 lh-0 op-6"></i></span>
                                            <input type="text" class="form-control fc-datepicker" placeholder="pilih tanggal" name="tanggalvoucher" <?php if ($_GET['tanggalvoucher']) {
                                                                                                                                                        echo "value='" . $_GET['tanggalvoucher'] . "'";
                                                                                                                                                    } ?>>
                                        </div>
                                        <div class="input-group col-sm-4">
                                            <select class="custom-select mb-3" id="1" name="reseller" style="width: 100%;height: 100%">
                                                <option value="none">Pilih Reseller</option>
                                                <?php foreach ($arrayres as $index => $baris) : ?>
                                                    <option value='<?php echo $baris['nama_seller']; ?>' <?php if ($_GET['reseller'] == $baris['nama_seller']) {
                                                                                                                echo "selected";
                                                                                                            } ?>><?php echo $baris['nama_seller']; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="input-group col-sm-4">
                                            <select class="custom-select mb-3" id="2" name="jenisvoucher" style="width: 100%;height: 100%">
                                                <option value="none">Jenis Voucher</option>
                                                <?php foreach ($textnya as $index => $baris) : ?>
                                                    <option value='<?php echo $baris['Voucher'] . "+" . $baris['price']; ?>' <?php if ($_GET['jenisvoucher'] == $baris['Voucher'] . "+" . $baris['price']) {
                                                                                                                                    echo "selected";
                                                                                                                                } ?>><?php echo $baris['Voucher']; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="d-flex pd-y-10 pd-md-y-0 justify-content-center mb-3" id="customid2">
                                        <div class="input-group col-sm-6">
                                            <select class="custom-select mb-3" style="width: 100%;height: 100%" name="tipevoucher" id="tipevoucher">
                                                <option value="none" <?php if ($_GET['tipevoucher'] == 'none' || empty($_GET['tipevoucher'])) {
                                                                            echo "selected";
                                                                        } ?>>pilih tipe cetak ...</option>
                                                <option value="default" <?php if ($_GET['tipevoucher'] == 'default') {
                                                                            echo "selected";
                                                                        } ?>>default</option>
                                                <option value="tinydefault" <?php if ($_GET['tipevoucher'] == 'tinydefault') {
                                                                                echo "selected";
                                                                            } ?>>tiny default</option>
                                                <option value="custom" <?php if ($_GET['tipevoucher'] == 'custom') {
                                                                            echo "selected";
                                                                        } ?>>custom</option>
                                                <option value="tinycustom" <?php if ($_GET['tipevoucher'] == 'tinycustom') {
                                                                                echo "selected";
                                                                            } ?>>tiny custom</option>
                                            </select>
                                        </div>
                                        <div class="input-group col-sm-6">
                                            <select class="custom-select mb-3" style="width: 100%;height: 100%" name="pilihqrcode" id="pilihqrcode">
                                                <option value="none" <?php if ($_GET['pilihqrcode'] == 'none' || empty($_GET['pilihqrcode'])) {
                                                                            echo "selected";
                                                                        } ?>>pilih opsi QRCODE...</option>
                                                <option value="qrcodeyes" <?php if ($_GET['pilihqrcode'] == 'qrcodeyes') {
                                                                                echo "selected";
                                                                            } ?>>pakai QR code</option>
                                                <option value="qrcodeno" <?php if ($_GET['pilihqrcode'] == 'qrcodeno') {
                                                                                echo "selected";
                                                                            } ?>>tidak pakai QR code</option>
                                            </select>
                                        </div>
                                    </div>
                                    <input type="hidden" name="Mikbotam" value="cetakvoucher">
                                    <button type="submit" class="btn btn-primary btn-lg btn-block mb-3">PROSES...</button>
                            </form>
                            <?php if (!empty($opsipilihan)) { ?>
                                <form action="cetak.php" method="POST" target="_blank">
                                    <input type="hidden" name="semuavoucher" value='<?php echo json_encode($semuavoucher); ?>'>
                                    <input type="hidden" name="validity" value="<?= $validity; ?>">
                                    <input type="hidden" name="harga" value="<?= $harga; ?>">
                                    <input type="hidden" name="tipevoucher" value="<?= $_GET['tipevoucher']; ?>">
                                    <input type="hidden" name="pilihqrcode" value="<?= $_GET['pilihqrcode']; ?>">
                                    <input type="hidden" name="reseller" value="<?= $_GET['reseller']; ?>">
                                    <button type="submit" class="btn btn-success btn-lg btn-block mb-3"><i class="fa fa-print" aria-hidden="true"></i> CETAK</button>

                                </form>
                            <?php } ?>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row alert justify-content-md-center">
                <?php if (!empty($opsipilihan)) { ?>
                    <div class="d-flex pd-y-10 pd-md-y-0 justify-content-center mb-3" style="width: 100%;">
                        Jumlah Voucher : <?php echo count($semuavoucher); ?>
                    </div>
                    <br>
                <?php } ?>
                <?php if (count($semuavoucher) > 0) {
                    for ($i = 0; $i < count($semuavoucher); $i++) {;
                        $uid = str_replace("=", "", base64_encode($i));;
                        $username   = $semuavoucher[$i]['name'];
                        $password   = $semuavoucher[$i]['password'];
                        $profile    = $semuavoucher[$i]['profile'];
                        $timelimit  = $semuavoucher[$i]['limit-uptime'];
                        $datalimit  = $semuavoucher[$i]['limit-bytes-total'];
                        $gn_lup     = $timelimit;
                        $comment = ' | voc : ' . $gn_jvc . ' (' . rupiah($gn_hrg);
                        if ($datalimit == 0) {
                            $datalimit = "";
                        }
                        $price = "(" . $harga . ")";
                        $urilogin = "http://$dnsname/login?username=$username&password=$password";
                        $qrcode = "
            <canvas class='qrcode' id='" . $uid . "'></canvas>
            <script>
              (function() {
                var " . $uid . " = new QRious({
                  element: document.getElementById('" . $uid . "'),
                  value: '" . $urilogin . "',
                  size:'256'
                });
        
              })();
            </script>
            ";
                        //jika username = password maka otomatis 1 kode
                        if ($username == $password) {
                            $usermode = 'vc';
                        } else {
                            $usermode = "up";
                        }

                        $num = $i + 1;

                        //pilih template
                        if ($_GET['tipevoucher'] == 'default') {
                            include('./templates/default.php');
                        } else if ($_GET['tipevoucher'] == 'tinydefault') {
                            include('./templates/default-small.php');
                        } else if ($_GET['tipevoucher'] == 'custom') {
                            include('./templates/template.php');
                        } else if ($_GET['tipevoucher'] == 'tinycustom') {
                            include('./templates/template-small.php');
                        }
                    }
                }  ?>

            </div>

            <script>
                $(function() {
                    'use strict';
                    // Datepicker
                    $('.fc-datepicker').datepicker({
                        dateFormat: "dd-mm-yy",
                        showOtherMonths: true,
                        selectOtherMonths: true
                    });
                });
            </script>
<?php

        }
    }
}
