<?php

include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Saldo/rpt/functions.php';
include '../Api/routeros_api.class.php';
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);
session_start();

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {

    $API = new routeros_api();
    $fp = @fsockopen($mikrotik_ip, $mikrotik_port, $errCode, $errStr, 1);
    if ($fp) {
        if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            //ambil domain
            $domainnya      = $_SERVER['HTTP_HOST'];

            //ambil user hotspot dimikrotik
            // $userhotspot    = $API->comm('/ip/hotspot/user/getall');
            // $namauser       = json_encode($usernya);


            //jumlah voucher yang dicetak
            $gn_jml         = $_POST['jml_vc'];

            //ambil data id dan username reseller, jika tidak ada : gunakan data owner
            if ($_POST['reseller'] == "none") {
                $gn_id      = $id_own;
                $gn_res     = $owner;
            } else {
                $datareseller = explode('|', $_POST['reseller']);
                $gn_res     = $datareseller[0];
                $gn_id      = $datareseller[1];
            }

            $gn_dis         = $_POST['diskon']; //diskon
            $gn_jvc         = json_decode($_POST['voucherlist'], true)['Voucher']; //jenis voucher
            $gn_prv         = $_POST['prefix_gn']; //prefix vc
            $gn_hrg         = $_POST['harga']; //harga vc yang tertulis
            $gn_mku         = $_POST['markup']; //markup harga
            $gn_lup         = $_POST['limit_uptime']; //limit uptime
            $gn_lqu         = toBytes($_POST['limit_quota']); //limit kuota
            $gn_srv         = $_POST['server']; //nama server hotspot
            $gn_pro         = $_POST['profile']; //nama profile hotspot
            $gn_tyc         = $_POST['typechar']; //jenis karakter vc
            $gn_tyl         = $_POST['typelogin']; //tipe login user pass / vc
            $gn_len         = $_POST['len_char']; //panjang karakter
            $waktuskr       = time(); //waktu cetak
            $id             = $_POST['id']; //id owner
            $hotspotname    = $Name_router; //nama router
            $getsprice      = $gn_hrg; //disesuaikan agar bisa masuk template


            //===ambil data gambar
            $arraytext = ngambiltext($id);
            $gambar = json_decode($arraytext, true);
            $logo = '../img/logo.png';
            $logostatus = $gambar['vc_logo'];

            //===cek jenis printnya

            if ($gn_prn == "tiny") {
                $small = "yes";
            }

            //sesuaikan usermode agar bisa diprint, up = user dan pass, vc = voucher(user = pass)
            if ($gn_tyl == "up") {
                $usermode   = "up";
            } elseif ($gn_tyl == "userpass") {
                $usermode   = "vc";
            }

            //bersihkan $_POST
            $_POST = array();

            //jika jumlah voucher lebih dari 0
            if ($gn_jml > 0) {

                //=====jika diskon diatas 0, maka data potongan yg digunakan adalah data diskon
                if ($gn_dis > 0) {
                    $gn_mku = ($gn_hrg * $gn_dis) / 100;
                }
                $hargadiskon = $gn_hrg - $gn_mku;

                //proses generate vouchernya
                $vcgn = "{";
                $psgn = "{";
                $vcdb = "";
                $psdb = "";
                for ($jmlvc = 0; $jmlvc < $gn_jml; $jmlvc++) {

                    $produksi = make_string($gn_len, $gn_tyc);
                    $pass = make_string($gn_len, $gn_tyc);
                    $produksi = $gn_prv . $produksi;

                    if (preg_match("\"" . $produksi . "\"", $vcgn)) {
                        $jmlvc = $jmlvc - 1;
                    } else {
                        $vcgn .= "\"" . $produksi . "\";";
                        $psgn .= "\"" . $pass . "\";";
                        $vcdb .= $produksi . "|";
                        $psdb .= $pass . "|";
                    }
                }

                //===== hasil setelah digenerate seluruhnya
                $vcgn = substr($vcgn, 0, -1);
                $vcgn .= "}";
                $psgn = substr($psgn, 0, -1);
                $psgn .= "}";
                $vcdb = substr($vcdb, 0, -1);
                $psdb = substr($psdb, 0, -1);

                //===== user = pass || user != pass
                if ($gn_tyl == "userpass") {

                    $psgn = $vcgn;
                    $psdb = $vcdb;
                }

                //bikin script untuk di mikrotik
                $colokscript = $API->comm("/system/script/add", [
                    "name" => $waktuskr,
                    "source" => ':local ausr ' . $vcgn . ';:local apss ' . $psgn . '; for i from=0 to=([:len $ausr]-1) do={:local username ($ausr->$i);:local password ($apss->$i);/ip hotspot user add name="$username" password="$password" profile="' . $gn_pro . '" server="' . $gn_srv . '" limit-uptime="' . $gn_lup . '" limit-bytes-total="' . $gn_lqu . '" comment="| ID : ' . $gn_res . ' | voc : ' . $gn_jvc . ' (' . rupiah($gn_hrg) . ') | tgl : ' . date('d-m-Y') . ' | MIKBOTAM-AUTO GENERATE |";:delay 0.2s;};/system script remove [find name="' . $waktuskr . '"];',
                    "comment" => "GENERATOR MIKBOTAM",
                ]);
                //running script di mikrotik
                $API->write("/system/script/getall", false);
                $API->write('=.proplist=.id', false);
                $API->write("?name=$waktuskr");
                $runapi = $API->read();

                $API->write("/system/script/run", false);
                $API->write('=.id=' . $runapi[0]['.id']);
                $readapi = $API->read();
                $API->disconnect();

                if ($readapi) {
                    echo "gagal generate";
                } else {
                    //=========simpan di database server

                    $vcdb = explode("|", $vcdb);
                    $psdb = explode("|", $psdb);

                    for ($jmlvc = 0; $jmlvc < $gn_jml; $jmlvc++) {
                        $simpankedb = generatevc($gn_id, $gn_res, $hargadiskon, $gn_mku, $vcdb[$jmlvc], $psdb[$jmlvc], $gn_pro, 'generate');
                    }

                    //=====simpan jumlah voucher terahir agar bisa dicetak nanti

                    updatevcgen($_SESSION['Mikbotamid'], $jmlvc . "|+|" . '| ID : ' . $gn_res . ' | voc : ' . $gn_jvc . ' (' . rupiah($gn_hrg) . ') | tgl : ' . date('d-m-Y') . ' | MIKBOTAM-AUTO GENERATE |');

                    $website = "https://api.telegram.org/bot" . $token;
                    $params  = [
                        'chat_id' => $id_own,
                        'text' => "voucher berhasil dicetak : $jmlvc lembar | ID : $gn_res | voc : $gn_jvc (" . rupiah($gn_hrg) . ") | tgl : " . date('d-m-Y') . " | MIKBOTAM-AUTO GENERATE |",
                        'parse_mode' => 'html',
                    ];
                    $ch = curl_init($website . '/sendMessage');
                    curl_setopt($ch, CURLOPT_HEADER, false);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    $result = curl_exec($ch);
                    curl_close($ch);
                    header("Location:./?Mikbotam=cetakvoucher&pilihvoucher=terbaru&tipevoucher=custom&pilihqrcode=qrcodeyes");
                }


                //potong disini buat html
            } else {
                echo "tidak ada voucher yang dicetak";
            }
        } else {
            include "disconnected.php";
        }

        fclose($fp);
    } else {
        include "disconnected.php";
    }
}
