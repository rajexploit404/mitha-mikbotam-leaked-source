<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2018
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//
session_start();
error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {
    include '../config/system.conn.php';

    $data = lihatdata();

    $pathdir = "../uploads";

    // change your directory name
    if ($_POST['formatt'] == "sendfoto") {
        if ((($_FILES["file"]["type"] == "image/png") || ($_FILES["file"]["type"] == "image/jpg") || ($_FILES["file"]["type"] == "image/jpeg") || ($_FILES["file"]["type"] == "image/gif"))) {
            if ($_FILES["file"]["size"] < 4000000) {
                if ($_FILES["file"]["error"] > 0) {
                    echo "Error: " . $_FILES["file"]["error"] . "<br />";
                } else {
                    $path = "../uploads/" . $_FILES["file"]['name'];
                    copy($_FILES["file"]['tmp_name'], $path);

                    $scheme = $_SERVER['REQUEST_SCHEME'];
                    if (strpos(strtolower($scheme), 'http') !== false) {
                        $cekhttps = "https://";
                    } else {
                        $cekhttps = $scheme . "://";
                    }
                    $sepath  = str_replace('..', '', $pathdir);
                    $urlreal = $cekhttps . $_SERVER['HTTP_HOST'] . $sepath . "/" . $_FILES["file"]["name"];

                    $send = sendPhoto($_POST['iduser'], $urlreal, $_POST['textdata'], $token);
                }
            } else {
                echo "Upload files less than 4000kb";
            }
        } else {
            echo "Invalid file format";
        }
    }
}

?>

<script>
    var _0x1a27 = ["val", "#idnya", "#textnya", "length", "Input Your id", "<img style='width:30%;' class='responsive-image center'; src='../img/loading.svg'/><br><center>Please choose one of the user IDs.</center>", "alert", "Input Your message", "<img style='width:30%;' class='responsive-image center'; src='../img/loading.svg'/><br><center>Please enter your message <br>max 4200 characters.</center>", "cursor", "wait", "css", "body", "\x3C\x64\x69\x76\x20\x61\x6C\x69\x67\x6E\x3D\x22\x63\x65\x6E\x74\x65\x72\x22\x3E\x3C\x69\x6D\x67\x20\x73\x72\x63\x3D\x22\x2E\x2E\x2F\x69\x6D\x67\x2F\x6C\x6F\x61\x64\x69\x6E\x67\x2E\x73\x76\x67\x22\x20\x2F\x3E\x3C\x2F\x64\x69\x76\x3E", "html", "#view-respont", "../Prosses/Broadcast_x.php", "text=", "&id=", "default", "ajax", "Mikbotam MITHA MOD", "success", "dismissed", "log", "notify"];

    function makebroadcast() {
        var _0xf30bx2 = $(_0x1a27[1])[_0x1a27[0]]();
        var _0xf30bx3 = $(_0x1a27[2])[_0x1a27[0]]();
        if (_0xf30bx2[_0x1a27[3]] == 0) {
            alertify[_0x1a27[6]](_0x1a27[4], _0x1a27[5])
        } else {
            if (_0xf30bx3[_0x1a27[3]] == 0) {
                alertify[_0x1a27[6]](_0x1a27[7], _0x1a27[8])
            } else {
                $(_0x1a27[12])[_0x1a27[11]](_0x1a27[9], _0x1a27[10]);
                $(_0x1a27[15])[_0x1a27[14]](_0x1a27[13]);
                $[_0x1a27[20]]({
                    url: _0x1a27[16],
                    data: _0x1a27[17] + _0xf30bx3 + _0x1a27[18] + _0xf30bx2,
                    cache: false,
                    success: function(_0xf30bx4) {
                        $(_0x1a27[15])[_0x1a27[14]](_0xf30bx4);
                        $(_0x1a27[12])[_0x1a27[11]](_0x1a27[9], _0x1a27[19])
                    }
                });
                alertify[_0x1a27[25]](_0x1a27[21], _0x1a27[22], 5, function() {
                    console[_0x1a27[24]](_0x1a27[23])
                })
            }
        }
    }
</script>
<div class="card-body pd-sm-10">
    <div class="row row-sm mg-t--1">
        <div class="col-xl-6 mg-t-10">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white">
                    <i class="fa  fa-paper-plane"></i> Send Message
                </div>
                <div class="card-body pd-sm-15">
                    <form method="post" action="">
                        <div class="row">
                            <label class="col-sm-4 form-control-label lead">ID user</label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <select class="form-control select2id" id="idnya" name="idnya" data-placeholder="Select ID">
                                    <option value="Alluser">All User</option>
                                    <?php

                                    foreach ($data as $baris) : ?>
                                        <option value="<?= $baris['id_user']; ?>"><?php echo $baris['id_user'] . '    (' . $baris['nama_seller'] . ')'; ?></option>
                                    <?php endforeach; ?>

                                </select>
                            </div>
                        </div>
                        <!-- row -->
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead ">Text <span class="tx-danger tx-12">*max 4200</span></label>
                            <div class="col-lg">
                                <textarea id="textnya" rows="3" class="form-control" placeholder="Message" style="margin-top: 0px; margin-bottom: 0px; height: 200px;"></textarea> <span id="hitung">4200</span> Karakter Tersisa.
                            </div>
                        </div>
                        <div class="row row-xs mg-t-8">
                            <div class="col-sm-15 mg-l-auto">
                                <div class="form-layout-footer">
                                    <button class="btn btn-success lh-0 tx-xthin mg-r-0 mg-t-8" onclick="makebroadcast();return false;"><i class="fa fa-send mg-r-2"></i> Send Message</button>
                                    <button class="btn btn-success lh-0 tx-xthin mg-r-2 mg-t-8"><i class="fa fa-trash mg-r-2"></i> Delete</button>
                                </div>
                                <!-- form-layout-footer -->
                            </div>
                            <!-- col-8 -->
                        </div>
                        <!-- card-body -->
                    </form>
                    <!-- card-body -->
                </div>
                <!-- card -->
            </div>
            <div class="mg-t-10">
                <div class="card bd-primary">
                    <div class="card-header bg-primary tx-white">
                        <i class="fa  fa-desktop"></i></i> Show Response
                    </div>
                    <div class="card-body pd-sm-15">
                        <div id="view-respont"></div>
                        <!-- card-body -->
                    </div>
                    <!-- card -->
                </div>
            </div>
        </div>
        <div class="col-xl-6 mg-t-10">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white">
                    <i class="fa fa-pencil"></i> Format Style
                </div>
                <div class="card-body pd-sm-15">
                    <table>
                        <tbody>
                            <tr>
                                <td colspan="2">
                                    <p style="padding:0px 3px;">
                                        Format Spesial Character.<br> Enter line <code>%0A</code> Space line <code>%20</code> <br>Contoh : <code>Pindah baris %0A , Spasi %20 atau bisa (langsung spasi)</code>.
                                    </p>
                                    <p style="padding:0px 2px;">
                                        Format <code>Code</code>.<br> Diawali dengan <code>&lt;code&gt;</code> diakhiri dengan <code>&lt;/code&gt;</code> <br>Contoh : <code>&lt;code&gt; Selamat Pagi &lt;/code&gt;</code>.
                                    </p>
                                    <p style="padding:0px 3px;">
                                        Format <b>Bold</b>.<br> Diawali dengan <code>&lt;b&gt;</code> diakhiri dengan <code>&lt;/b&gt;</code> <br>Contoh : <code>&lt;b&gt; Selamat Pagi &lt;/b&gt;</code>.
                                    </p>
                                    <p style="padding:0px 3px;">
                                        Format <i>italic</i>.<br> Diawali dengan <code>&lt;i&gt;</code> diakhiri dengan <code>&lt;/i&gt;</code> <br>Contoh : <code>&lt;i&gt; Selamat Pagi &lt;/i&gt;</code>.
                                    </p>
                                    <p style="padding:0px 3px;">
                                        Format Url with text.<br> Diawali dengan <code>&lt;a href=</code> diakhiri dengan <code>&lt;/a&gt;</code> <br>Contoh : <code>&lt;a href="http://www.example.com/">inline URL &lt;/a&gt;</code>
                                    </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <!-- card-body -->
                    <!-- card -->
                </div>
            </div>

        </div>
        <!-- body -->
    </div>
</div>
<!-- body -->