<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2018
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);


include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Api/routeros_api.class.php';
$API = new routeros_api();

if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port));

$id          = $_GET['id'];
$getuserdata = $API->comm("/ppp/secret/print", [
    "?.id" => $id,
]);
$profiles      = $API->comm('/ppp/profile/print');
//komensecret : | status : daftar | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(tenggat) | idsecret : *4 | profile : profilemitha | PPPoE-MITHA-MIKBOTAM | 
$komensecret    = $getuserdata[0]['comment'];
$pecahkomenedit = explode(" | ", $komensecret);
$tglexpedit     = explode("tgl-expired : ", $pecahkomenedit[1])[1];
$jamexpedit     = explode("jam-expired : ", $pecahkomenedit[2])[1];
$jamedit        = explode(":", $jamexpedit)[0];
$mntedit        = explode(":", $jamexpedit)[1];
$idsecret       = explode("idsecret : ", $pecahkomenedit[4])[1];
$metodeedit     = explode("eksekusi : ", $pecahkomenedit[3])[1];
$prtujedit      = explode("(", $metodeedit);
$metodefixedit  = $prtujedit[0];
$proeditfix     = explode(")", $prtujedit[1])[0];




?>
<script type="text/javascript">
    var profile = '<?php foreach ($profiles as $index => $baris) : echo '<option value="' . $baris['name'] . '">' . $baris['name'] . '</option>';
                    endforeach; ?>';

    function pilihprofileedit(name) {

        if (name == 'pindah-profile') document.getElementById('pindahprofileedit').innerHTML = '<div class="row mg-t-8"><label class="col-sm-4 form-control-label align-self-center">Profile expired : </label><div class="col-sm-8 mg-t-10 mg-sm-t-0"> <select class="form-control select2id" style="width: 100%;" name="profileexpired" required><option value="">- choose -</option><?php echo '<option value="' . $proeditfix . '" selected>' . $proeditfix . '</option>'; ?>' + profile + '</select></div></div>';
        else document.getElementById('pindahprofileedit').innerHTML = '';
    }
</script>

<div class="card bd bd-primary">
    <div class="card-body pd-sm-15">

        <form action="" method="post">
            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Name : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" name="username" class="form-control" value="<?= $getuserdata[0]['name']; ?>" required>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Password : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" name="password" class="form-control" value="<?= $getuserdata[0]['password']; ?>">
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Service : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control select2id" style="width: 100%;" name="service" required>
                        <option value="any" <?php if ($getuserdata[0]['service'] == "any") {
                                                echo 'selected';
                                            } ?>>any</option>
                        <option value="pppoe" <?php if ($getuserdata[0]['service'] == "pppoe") {
                                                    echo 'selected';
                                                } ?>>pppoe</option>
                        <option value="pptp" <?php if ($getuserdata[0]['service'] == "pptp") {
                                                    echo 'selected';
                                                } ?>>pptp</option>
                        <option value="sstp" <?php if ($getuserdata[0]['service'] == "sstp") {
                                                    echo 'selected';
                                                } ?>>sstp</option>
                        <option value="l2tp" <?php if ($getuserdata[0]['service'] == "l2tp") {
                                                    echo 'selected';
                                                } ?>>l2tp</option>
                        <option value="ovpn" <?php if ($getuserdata[0]['service'] == "ovpn") {
                                                    echo 'selected';
                                                } ?>>ovpn</option>
                    </select>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Profile : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control select2id" name="profile" required>
                        <option value=''>- choose -</option>
                        <?php foreach ($profiles as $baris) { ?>
                            <option value="<?= $baris['.id'] . "|+|" . $baris['name']; ?>" <?php if ($getuserdata[0]['profile'] == $baris['name']) {
                                                                                                echo 'selected';
                                                                                            } ?>><?= $baris['name']; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Remote Address : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" name="remoteaddress" class="form-control" value="<?= $getuserdata[0]['remote-address']; ?>">
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Local Address : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" name="localaddress" class="form-control" value="<?= $getuserdata[0]['local-address']; ?>">
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Tanggal Jatuh Tempo :</label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control select2id" style="width: 30%;" name="tglexp" id="tglexp">
                        <option value="profile">ikut data profile</option>
                        <?php echo "<option value='$tglexpedit' selected>$tglexpedit</option>"; ?>
                        <?php for ($i = 01; $i < 29; $i++) {
                            $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                            echo "<option value='$ii'>$ii</option>";
                        } ?>
                    </select>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Waktu Jatuh Tempo (JAM : MENIT) :</label>
                <div class="form-inline col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control select2id" style="width: 30%;" name="jamexp" id="jamexp">
                        <option value="profile">ikut data profile</option>
                        <?php echo "<option value='$jamedit' selected>$jamedit</option>"; ?>
                        <?php for ($i = 01; $i < 24; $i++) {
                            $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                            echo "<option value='$ii'>$ii</option>";
                        } ?>
                    </select> &nbsp;:&nbsp;
                    <select class="form-control select2id" style="width: 30%;" name="mntexp" id="mntexp">
                        <option value="profile">ikut data profile</option>
                        <?php echo "<option value='$mntedit' selected>$mntedit</option>"; ?>
                        <?php for ($i = 00; $i < 60; $i++) {
                            $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                            echo "<option value='$ii'>$ii</option>";
                        } ?>
                    </select>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label align-self-center">Eksekusi :</label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control select2id" style="width: 100%;" name="eksekusi" id="eksekusi" onchange="pilihprofileedit(this.options[this.selectedIndex].value)">
                        <option value="profile">ikut data profile</option>
                        <option value="disable" <?php if ($metodefixedit == "disable") {
                                                    echo "selected";
                                                } ?>>disable</option>
                        <option value="pindah-profile" <?php if ($metodefixedit == "pindah-profile") {
                                                            echo "selected";
                                                        } ?>>pindah profile</option>
                    </select>
                </div>
            </div>

            <?php if ($metodefixedit == 'pindah-profile') { ?>
                <div id="pindahprofileedit">
                    <div class="row mg-t-8">
                        <label class="col-sm-4 form-control-label align-self-center">Profile expired : </label>
                        <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                            <select class="form-control select2id" style="width: 100%;" name="profileexpired" required>
                                <option value="">- choose -</option>
                                <?php echo '<option value="' . $proeditfix . '" selected>' . $proeditfix . '</option>';
                                foreach ($profiles as $index => $baris) : echo '<option value="' . $baris['name'] . '">' . $baris['name'] . '</option>';
                                endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
            <?php } else { ?>
                <div id="pindahprofileedit"></div>
            <?php } ?>

            <div class="row row-xs mg-t-10">
                <div class="col-sm-15 mg-l-auto">
                    <div class="form-layout-footer">
                        <input type="hidden" name="uid" value="<?= $getuserdata[0]['.id']; ?>">
                        <button type="submit" class="btn btn-primary" name="edit_user">Save User</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                    </div>

                </div>

            </div>

        </form>
    </div>
</div>