<?php

$mkbot->cmd("/otodepo", function ($nominal) {
    include '..config/system.conn.php';
    $message    = Bot::message();
    $name       = $message['from']['first_name'];
    $name2      = $message['from']['last_name'];
    $idtelegram = $message['from']['id'];
    $chatid     = $message['chat']['id'];
    $usertele   = $message['from']['username'];

    bot::sendChatAction('typing');
    //ambil data API key, Private Key, Merchant Code, dan daftar metode pembayaran (pakai QRISD dari dana fee lebih murah)
    if (!empty($nominal)) {
        if (is_numeric($nominal) && $nominal >= 10000) {
            $getidmikbotam  = getid();
            $ambildata      = ambilpg($getidmikbotam);
            $datamentah     = json_decode($ambildata, true);
            $pecahmetode    = $datamentah['metode'];
            if (count($pecahmetode) > 0) {
                $splitarray     = array_chunk($pecahmetode, 2);
                $send           = [];
                foreach ($splitarray as $i => $mb) {
                    $pecahkiri  = explode('-', $mb[0]);
                    $pecahkanan = explode('-', $mb[1]);
                    $datakiri   = ['text' => $pecahkiri[0], 'callback_data' => "otodepo : " . $nominal . "|" . $pecahkiri[1] . "|" . $idtelegram . "|" . $usertele];
                    $datakanan  = ['text' => $pecahkanan[0], 'callback_data' => "otodepo : " . $nominal . "|" . $pecahkanan[1] . "|" . $idtelegram . "|" . $usertele];
                    $barisdata  = array_filter([$datakiri, $datakanan]);
                    array_push($send, $barisdata);
                }
                $menu_batal     = [['text' => 'BATAL', 'callback_data' => 'cancel']];
                array_push($send, $menu_batal);

                $text           = 'anda akan deposit senilai ' . rupiah($nominal) . "\n";
                $text           .= "silahkan pilih metode pembayaran anda\n";

                $options = [
                    'reply_markup' => json_encode(['inline_keyboard' => $send]),
                    'parse_mode' => 'html'
                ];
            } else {
                $text   = "maaf system tidak ada metode pembayaran";
                $options = [
                    'parse_mode' => 'html'
                ];
            }
        } else {
            $text   = "maaf format salah, yang benar /otodepo 10000\nhanya angka tanpa huruf / tanda baca lain\nnominal minimal Rp. 10.000,-";
            $options = [
                'parse_mode' => 'html'
            ];
        }
    } else {
        $text   = "maaf format salah, yang benar /otodepo 100000";
        $options = [
            'parse_mode' => 'html'
        ];
    }


    return Bot::sendMessage($text, $options);
});
