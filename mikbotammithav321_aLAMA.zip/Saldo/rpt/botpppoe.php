<?php
include 'rpt/botplusplus.php';
include 'rpt/botpaymentgateway.php';

$mkbot->cmd("/pppoe", function () {
    include '../config/system.conn.php';
    $message    = Bot::message();
    $name       = $message['from']['first_name'];
    $name2      = $message['from']['last_name'];
    $idtelegram = $message['from']['id'];
    $chatid     = $message['chat']['id'];
    $usertele   = $message['from']['username'];
    if ($idtelegram == $id_own) {
        bot::sendChatAction('typing');
        $API = new routeros_api();
        if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            $semuasecret = $API->comm('/ppp/secret/getall');
            $secretarray    = [];
            $i              = 0;
            $arraychunk     = 2;
            $arraydalam     = [];
            $tanda          = 0;
            $jumlahsecret   = count($semuasecret);
            $halaman        = 1;
            foreach ($semuasecret as $index => $secret) {
                $secretkomen = isset($secret['comment']) ? $secret['comment'] : '';
                if (strpos($secretkomen, "PPPoE-MITHA-MIKBOTAM") !== false) {
                    $comment = explode(" | ", $secretkomen);
                    $stkomen = explode("status : ", $comment[0])[1];
                    if ($stkomen == 'daftar') {
                        $status = "🔵 ";
                    } else if ($stkomen == 'aktif') {
                        $status = "🟢 ";
                    } else if ($stkomen == 'expired') {
                        $status = "🔴 ";
                    }
                    $simpantext     = ['text' => $status . $secret['name'], 'callback_data' => 'idsecret : ' . $secret['.id'] . " ||| " . $halaman . " || 0"];
                    $arraydalam[$tanda] = $simpantext;

                    if ($tanda == $arraychunk - 1) {
                        array_push($secretarray, $arraydalam);
                        $tanda = 0;
                        $arraydalam = [];
                    } else {
                        $tanda++;
                    }

                    $i++;
                }

                if ($i == 11) {
                    $arraydalam[0]['text'] = "NEXT >>";
                    $arraydalam[0]['callback_data'] = "tombol : " . ($halaman + 1) . " || 0 | $index";
                    array_push($secretarray, $arraydalam);
                    break;
                } else if ($index == $jumlahsecret - 1 && !isset($arraydalam[1]) && isset($arraydalam[0])) {
                    array_push($secretarray, $arraydalam);
                }
            }
            $send = $secretarray;
            $text = "berikut daftar client PPPoE MITHA : \n";
            $text .= "<code>";
            $text .= "=====================\n";
            $text .= "🔵 = baru terdaftar\n";
            $text .= "🟢 = status aktif\n";
            $text .= "🔴 = status expired\n";
            $text .= "=====================\n";
            $text .= "    halaman : $halaman\n";
            $text .= "</code>";

            $options = [
                'reply_markup' => json_encode(['inline_keyboard' => $send]),
                'parse_mode' => 'html'
            ];
        } else {
            $text = "mikrotik tidak terhubung";
            $options = [
                'parse_mode' => 'html'
            ];
        }
        return Bot::sendMessage($text, $options);
    }
});
