<?php

require_once 'system.medoo.php';

$mikbotamdata = new medoo([
    'database_type' => 'mysql',
    'database_name' => 'NAMADATABASE',
    'server' => 'localhost',
    'username' => 'USERDATABASE',
    'password' => 'PASSDATABASE',
    'charset' => 'utf8'
]);
