<?php
//=====================================================START====================//

/*
 *  RUMAH PETIR v2.5
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:admin/login.php");
} else {
    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Api/routeros_api.class.php';
    $API = new routeros_api();

    if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port));

    $domainnya = $_SERVER['HTTP_HOST'];

    $seeprofile = $API->comm('/ip/hotspot/user/profile/print');
    $seesever  = $API->comm('/ip/hotspot/print');
    $seeuser   = $API->comm('/ip/hotspot/user/print');

    $getallqueue = $API->comm("/queue/simple/print", [
        "?dynamic" => "false",
    ]);
    //cek nama user profile apakah sudah ada atau blm

    $proflist = $API->comm('/ip/hotspot/user/profile/getall');
    $profname = $_POST['name'];
    $cariul = array_search($profname, array_column($proflist, 'name'));
    $array_ul = $proflist[$cariul];
    $profada = $array_ul['name'];

    if ($profada == $profname) {

        echo '<script language="javascript">';
        echo 'document.addEventListener("DOMContentLoaded", function() {';
        echo 'alertify.alert("WARNING", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center>Profile Hotspot Name Already Exist </center>");';
        echo '});';
        echo '</script>';
    } else {

        if (isset($_POST['saveprofile']) && !empty($_POST['name'])) {
            $name              = $_POST['name'];
            $shared_userscount = $_POST['shared-users'];
            $rate_limittraf    = strtoupper($_POST['rate-limit']);
            $validdity         = $_POST['valid_time1'] . "d " . $_POST['valid_time2'] . ":" . $_POST['valid_time3'] . ":" . $_POST['valid_time4'];
            $lock_macs         = $_POST['lock_mac'];
            $parent            = $_POST['parent'];
            $trasparants       = $_POST['checkbox'];
            $rmvacc            = $_POST['checkbox2'];
            $bctele            = $_POST['checkbox3'];
            $bcteleres         = $_POST['checkbox4'];
            $fiturfup          = $_POST['enablefup'];

            $pecahrate = strtoupper($rate_limittraf);
            $pecahrate = explode("/", $pecahrate);

            //ratelimit sebelum fup
            $raterx = $pecahrate[0];
            $ratetx = $pecahrate[1];

            //ratelimit sesudah fup
            $rxfup      = $_POST['raterx'] . $_POST['raterxname'];
            $txfup      = $_POST['ratetx'] . $_POST['ratetxname'];

            //interval
            $interval   = $_POST['durasireset'];

            //jam reset
            $jamreset   = $_POST['jamreset'];
            if (strlen($jamreset) == 1) {
                $jamreset = "0" . $jamreset;
            }

            //targetfup
            $fup  = $_POST['fup'] . $_POST['fupname'];


            if ($trasparants == true) {
                $trasparant = 'yes';
            } else {
                $trasparant = "no";
            }

            if ($rmvacc == true) {
                $removeacc = '1';
            } else {
                $removeacc = "0";
            }

            if ($bctele == true) {
                $bctelegram = '1';
            } else {
                $bctelegram = "0";
            }

            if ($bcteleres == true) {
                $bctelegramres = '1';
            } else {
                $bctelegramres = "0";
            }

            if ($lock_macs == 'enable') {
                $kuncimac = '1';
            } else {
                $kuncimac = '0';
            }

            if ($fiturfup == true) {
                $fitfup = '1';
            } else {
                $fitfup = '0';
            }


            $on_login = ':local rmcde ("' . $bctelegram . $removeacc . $kuncimac . $bctelegramres . $fitfup . '|' . $_POST['fup'] . '|' . $_POST['fupname'] . '|' . $_POST['raterx'] . '|' . $_POST['raterxname'] . '|' . $_POST['ratetx'] . '|' . $_POST['ratetxname'] . '|' . $interval . '|' . $jamreset . '");:local ut ("' . $validdity . '");:local namaadmin ("' . $owner . '");:local bcadmin [:pick $rmcde 0];:local removeacc [:pick $rmcde 1];:local kuncimacnya [:pick $rmcde 2];:local bcreseller [:pick $rmcde 3];:local date [/system clock get date];:local timeq [/system clock get time];:local jamskr [/system clock get time];:local tglskr [:pick $date 4 6];:local blnskr [:pick $date 0 3];:local thnskr [:pick $date 7 11];:local tglq [:pick $date 4 6];:local blnq [:pick $date 0 3];:local thnq [:pick $date 7 11];:local garing ("/");:local td (":");:local macadd $"mac-address";:local ambilkomen [/ip hotspot user get [find where name="$user"] comment];:local ambilvoc [:pick $ambilkomen [:find $ambilkomen "voc :"] [:find $ambilkomen " | tgl :"]];:local ambilreseller [:pick $ambilkomen [:find $ambilkomen "ID : "] [:find $ambilkomen " | voc :"]];:local jenisvcnya [:pick $ambilvoc 6 50];:local namareseller [:pick $ambilreseller 5 50];:if ([:len [/system scheduler find name=$user]]=0) do={:if ($kuncimacnya=1) do={/ip hotspot user set mac-address=$"macadd" [find where name=$user]};/system scheduler add name="$user" interval=$ut  on-even=":local hitung [/system scheduler get [find where name=\"$user\"] run-count];:if (\$hitung < 5) do={/tool fetch http-method=post url=\"https://' . $domainnya . '/telegram_response.php\" http-data=\"idtelegram=$namareseller&status=expired&info=$user|$jenisvcnya|0|$namareseller|0|0|0|0|$rmcde\" keep-result=no};/ip hotspot active remove [find where user=$user];/ip hotspot user set [find where name=\"$user\"] limit-uptime=\"00:00:01\" comment=\"masuk masa tenggat\";/sys sch set [find where name=\"$user\"] name=\"tenggat_$user\" on-even=\":if ($removeacc=1) do={/ip hotspot user remove [find where name=\\\\\"$user\\\\\"]} else={/ip hotspot user set [find where name=\\\\\"$user\\\\\"] disable=yes};/ip hotspot cookie remove [find user=\\\\\"$user\\\\\"];/sys sch remove [find where name=\\\\\"tenggat_$user\\\\\"];\";";:delay 2s;:local exp [/sys sch get [find where name="$user"] next-run];:local lexp [len $exp];:local komenusr [/ip hotspot user get [find where name="$user"] comment];:if ($lexp = 8) do={:set timeq [:pick $exp 0 8];};:if ($lexp = 15) do={:set blnq [:pick $exp 0 3];:set tglq [:pick $exp 4 6];:set timeq [:pick $exp 7 15];};:if ($lexp = 20) do={:set blnq [:pick $exp 0 3];:set tglq [:pick $exp 4 6];:set thnq [:pick $exp 7 11];:set timeq [:pick $exp 12 20];};/ip hotspot user set [find where name="$user"] comment="start $jamskr - $tglskr-$blnskr-$thnskr end $timeq - $tglq-$blnq-$thnq | $komenusr";/sys sch set [find where name="$user"] start-date="$blnq$garing$tglq$garing$thnq" start-time="$timeq" comment="berakhir pada $td $tglq $blnq $thnq pukul $timeq " interval="01:00:00";/tool fetch http-method=post url="https://' . $domainnya . '/telegram_response.php" http-data="idtelegram=$namareseller&status=start&info=$user|$jenisvcnya|$macadd|$namareseller|$jamskr|$tglskr-$blnskr-$thnskr|$timeq|$tglq-$blnq-$thnq|$rmcde" keep-result=no;};';

            //----tambah script FUP----


            // ubah rate rx dan tx ke bits lalu ke bytes
            // rx dan tx
            if (strpos($raterx, 'K')) {
                $rx = str_replace("K", "", $raterx);
                $bitsrx = $rx * 1024;
            } else if (strpos($raterx, 'M')) {
                $rx = str_replace("M", "", $raterx);
                $bitsrx = $rx * 1048576;
            } else if (strpos($raterx, 'G')) {
                $rx = str_replace("G", "", $raterx);
                $bitsrx = $rx * 1073741824;
            } else {
                $bitsrx = $raterx;
            }

            if (strpos($ratetx, 'K')) {
                $tx = str_replace("K", "", $ratetx);
                $bitstx = $tx * 1024;
            } else if (strpos($ratetx, 'M')) {
                $tx = str_replace("M", "", $ratetx);
                $bitstx = $tx * 1048576;
            } else if (strpos($ratetx, 'G')) {
                $tx = str_replace("G", "", $ratetx);
                $bitstx = $tx * 1073741824;
            } else {
                $bitstx = $ratetx;
            }

            $bytesrx = $bitsrx / 8;
            $bytestx = $bitstx / 8;

            // fup
            if (strpos($fup, 'K')) {
                $fup = str_replace("K", "", $fup);
                $bytefup = $fup * 1024;
            } else if (strpos($fup, 'M')) {
                $fup = str_replace("M", "", $fup);
                $bytefup = $fup * 1048576;
            } else if (strpos($fup, 'G')) {
                $fup = str_replace("G", "", $fup);
                $bytefup = $fup * 1073741824;
            } else {
                $bytefup = $fup;
            }

            // olah data
            $jmlbytes       = $bytesrx + $bytestx;
            $detiklomfup    = ($bytefup / $jmlbytes) + 60;

            // ratelimitnya di split, lalu colok ke on-login
            if ($fiturfup == true) {
                $on_login .= ':local ambilprofile [/ip hotspot user get [find where name="$user"] profile];:local apb [/ip hotspot user profile get [find where name="$ambilprofile"] insert-queue-before ];:if ([:len $apb] = 0 || $apb = "first") do={:set apb [/queue simple get [([find]->1)] name];};:local ratel [/ip hotspot user profile get [find where name="$ambilprofile"] rate-limit];:local ratel2;:local rtrate;:local rtburst;:local rtbt;:local rtbtime;:local prio;:local rtmin;:if ([:len $ratel] > 11) do={:for i from=0 to=([:len $ratel] - 1) do={:local char [:pick $ratel $i];:if ($char = " ") do={:set $char ",";};:set ratel2 ($ratel2 . $char);};:local ratel3 [:toarray $ratel2];:set rtrate ($ratel3->0);:set rtburst ($ratel3->1);:set rtbt ($ratel3->2);:set rtbtime ($ratel3->3);:set prio ($ratel3->4);:set rtmin ($ratel3->5);} else={:set rtrate $ratel;:set rtburst "0/0";:set rtbt "0/0";:set rtbtime "0/0";:set prio "8";:set rtmin "0/0";};/queue simple remove [find where name="<hotspot-$user>"];:local usedquota ([/ip hotspot user get [find where name="$user"] bytes-in] + [/ip hotspot user get [find where name="$user"] bytes-out]);:local date [/system clock get date];:local jam [/system clock get time];:local bln [:pick $date 0 3];:local tgl [:pick $date 4 6];:local thn [:pick $date 7 11];:local garing ("/");:if (' . $bytefup . ' < $usedquota) do={/queue simple add name="$user_hotspot_fup" target="$address" max-limit="' . $rxfup . '/' . $txfup . '" parent="' . $parent . '" place-before="$apb" comment="$user sudah fup - MITHA FUP SCRIPT v1.2";} else={/queue simple add name="$user_hotspot_fup" target="$address" max-limit="$rtrate" burst-limit="$rtburst" burst-threshold="$rtbt" burst-time="$rtbtime" priority="$prio" limit-at="$rtmin" parent="' . $parent . '" place-before="$apb" comment="$user belum fup - MITHA FUP SCRIPT v1.2";:if ([:len [/system scheduler find name="$user_FUP_MITHA"]]=0) do={/system scheduler add name="$user_FUP_MITHA" interval="00:00:' . $detiklomfup . '" on-event=":local sfup (' . $bytefup . ');:local susqu ([/ip hotspot user get [find where name=\"$user\"] bytes-in] + [/ip hotspot user get [find where name=\"$user\"] bytes-out]);:local data [/queue simple get [find where name=\"$user_hotspot_fup\"] bytes];:local data1 [:pick \$data 0 [:find \$data \"/\"]];:local data2 [:pick \$data ([:find \$data \"/\"] + 1) [:len \$data]];:local susqa (\$data1 + \$data2);:local sbytes (' . $jmlbytes . ');:local susq (\$susqu + \$susqa);:local slfup (' . $bytefup . ' - \$susq);:local ssec ((\$slfup / \$sbytes)+60);:local date [/system clock get date];:local jam [/system clock get time];:local bln [:pick \$date 0 3];:local tgl [:pick \$date 4 6];:local thn [:pick \$date 7 11];:local garing (\"/\");:if (' . $bytefup . ' < \$susq) do={/queue simple set [find where name=\"$user_hotspot_fup\"] max-limit=\"' . $rxfup . '/' . $txfup . '\" comment=\"$user sudah fup - MITHA FUP SCRIPT v1.0\";/sys schedule remove [find where name=\"$user_FUP_MITHA\"];} else={/sys sch set [find where name=\"$user_FUP_MITHA\"] interval=\"00:00:\$ssec\";:delay 5s;:local sexp [/sys sch get [find where name=\"$user_FUP_MITHA\"] next-run];:local slexp [len \$sexp];:if (\$slexp = 8) do={:set jam [:pick \$sexp 0 8];};:if (\$slexp = 15) do={:set bln [:pick \$sexp 0 3];:set tgl [:pick \$sexp 4 6];:set jam [:pick \$sexp 7 15];};:if (\$slexp = 20) do={:set bln [:pick \$sexp 0 3];:set tgl [:pick \$sexp 4 6];:set thn [:pick \$sexp 7 11];:set jam [:pick \$sexp 12 20];};/sys sch set [find where name=\"$user_FUP_MITHA\"] start-date=\"\$bln\$garing\$tgl\$garing\$thn\" start-time=\"\$jam\" interval=\"00:10:00\" comment=\"akan di cek kembali pada : \$jam - \$tgl \$bln \$thn\";}";:delay 5s;:local exp [/sys sch get [find where name="$user_FUP_MITHA"] next-run];:local lexp [len $exp];:if ($lexp = 8) do={:set jam [:pick $exp 0 8];};:if ($lexp = 15) do={:set bln [:pick $exp 0 3];:set tgl [:pick $exp 4 6];:set jam [:pick $exp 7 15];};:if ($lexp = 20) do={:set bln [:pick $exp 0 3];:set tgl [:pick $exp 4 6];:set thn [:pick $exp 7 11];:set jam [:pick $exp 12 20];};/sys sch set [find where name="$user_FUP_MITHA"] start-date="$bln$garing$tgl$garing$thn" start-time="$jam" interval="00:10:00" comment="akan di cek kembali pada : $jam - $tgl $bln $thn";}};:local prof [/ip hotspot user get [find where name="$user"] profile];:if ([:len [/sys sch find name="durasi_$prof_mitha"]]=0) do={/sys sch add name="durasi_$prof_mitha" interval="' . $interval . ':00:00" start-time="' . $jamreset . ':00:01" on-event=":local lst [/ip hotspot user find profile=\"$prof\"];:foreach usr in=\$lst do={:local nm [/ip hot us get \$usr name];/ip hot us res \$usr;/queue simple reset-counters [find where name=\"\$nm_hotspot_fup\"];:if ([:len [/ip hotspot active find user=\"\$nm\"]]=0) do={:local none \"0\";} else={/queue simple set [find where name=\"\$nm_hotspot_fup\"] max-limit=\"' . $raterx . '/' . $ratetx . '\" comment=\"\$nm belum fup - MITHA FUP SCRIPT v1.2\";:if ([:len [/system scheduler find name=\"\$nm_FUP_MITHA\"]]=0) do={/system scheduler add name=\"\$nm_FUP_MITHA\" interval=\"00:00:' . $detiklomfup . '\" on-event=\":local sfup (' . $bytefup . ');:local susqu ([/ip hotspot user get [find where name=\\\\\"\$nm\\\\\"] bytes-in] + [/ip hotspot user get [find where name=\\\\\"\$nm\\\\\"] bytes-out]);:local data [/queue simple get [find where name=\\\\\"\$nm_hotspot_fup\\\\\"] bytes];:local data1 [:pick \\\\\$data 0 [:find \\\\\$data \\\\\"/\\\\\"]];:local data2 [:pick \\\\\$data ([:find \\\\\$data \\\\\"/\\\\\"] + 1) [:len \\\\\$data]];:local susqa (\\\\\$data1 + \\\\\$data2);:local sbytes (' . $jmlbytes . ');:local susq (\\\\\$susqu + \\\\\$susqa);:local slfup (' . $bytefup . ' - \\\\\$susq);:local ssec ((\\\\\$slfup / \\\\\$sbytes)+60);:local date [/system clock get date];:local jam [/system clock get time];:local bln [:pick \\\\\$date 0 3];:local tgl [:pick \\\\\$date 4 6];:local thn [:pick \\\\\$date 7 11];:local garing (\\\\\"/\\\\\");:if (' . $bytefup . ' < \\\\\$susq) do={/queue simple set [find where name=\\\\\"\$nm_hotspot_fup\\\\\"] max-limit=\\\\\"' . $rxfup . '/' . $txfup . '\\\\\" comment=\\\\\"\$nm sudah fup - MITHA FUP SCRIPT v1.2\\\\\";/sys schedule remove [find where name=\\\\\"\$nm_FUP_MITHA\\\\\"];} else={/sys sch set [find where name=\\\\\"\$nm_FUP_MITHA\\\\\"] interval=\\\\\"00:00:\\\\\$ssec\\\\\";:delay 6s;:local sexp [/sys sch get [find where name=\\\\\"\$nm_FUP_MITHA\\\\\"] next-run];:local slexp [len \\\\\$sexp];:if (\\\\\$slexp = 8) do={:set jam [:pick \\\\\$sexp 0 8];};:if (\\\\\$slexp = 15) do={:set bln [:pick \\\\\$sexp 0 3];:set tgl [:pick \\\\\$sexp 4 6];:set jam [:pick \\\\\$sexp 7 15];};:if (\\\\\$slexp = 20) do={:set bln [:pick \\\\\$sexp 0 3];:set tgl [:pick \\\\\$sexp 4 6];:set thn [:pick \\\\\$sexp 7 11];:set jam [:pick \\\\\$sexp 12 20];};/sys sch set [find where name=\\\\\"\$nm_FUP_MITHA\\\\\"] start-date=\\\\\"\\\\\$bln\\\\\$garing\\\\\$tgl\\\\\$garing\\\\\$thn\\\\\" start-time=\\\\\"\\\\\$jam\\\\\" interval=\\\\\"00:10:00\\\\\" comment=\\\\\"akan di cek kembali pada : \\\\\$jam - \\\\\$tgl \\\\\$bln \\\\\$thn\\\\\";}\";}};delay 0.2s;};:log warning \"FUP RESET\";/sys sch rem \"durasi_$prof_mitha\";"}';

                $on_logout = '/queue simple remove [find where name="$user_hotspot_fup"];/sys schedule remove [find where name="$user_FUP_MITHA"];';
            } else {
                $on_logout = '';
            }



            $profile = $API->comm("/ip/hotspot/user/profile/add", [
                "name" => $name,
                "rate-limit" => $rate_limittraf,
                "shared-users" => $shared_userscount,
                "status-autorefresh" => "1m",
                "transparent-proxy" => $trasparant,
                "on-login" => $on_login,
                "parent-queue" => $parent,
                "on-logout" => $on_logout,
            ]);

            echo '<script language="javascript">';
            echo 'document.addEventListener("DOMContentLoaded", function() {';
            echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success  Add Profile Hotspot </center>");';
            echo '});';
            echo '</script>';
            echo "<script>setTimeout(\"location.href = '?Mikbotam=profilelist';\");</script>";
        }
    }
}



if (isset($_POST['saveprofileedit'])) {

    //cek nama user profile apakah sudah ada belum

    $proflist2 = $API->comm('/ip/hotspot/user/profile/getall');
    $profname2 = $_POST['name_editprofile'];
    $cariul2 = array_search($profname2, array_column($proflist2, 'name'));
    $array_ul2 = $proflist2[$cariul2];
    $profadaid = $array_ul2['.id'];
    $profadanm = $array_ul2['name'];

    $id_edit                = $_POST['uid_editprofile'];
    $name_edit              = $_POST['name_editprofile'];
    $shared_userscount_edit = $_POST['shared-users_editprofile'];
    $rate_limittraf_edit    = strtoupper($_POST['rate-limit_editprofile']);
    $validdity_edit         = $_POST['valid_time1_editprofile'] . "d " . $_POST['valid_time2_editprofile'] . ":" . $_POST['valid_time3_editprofile'] . ":" . $_POST['valid_time4_editprofile'];
    $lock_macs_edit         = $_POST['lock_mac_editprofile'];
    $parent_edit            = $_POST['parent_editprofile'];
    $trasparants_edit       = $_POST['checkbox_editprofile'];
    $rmvacc_edit            = $_POST['checkbox2_editprofile'];
    $bctele_edit            = $_POST['checkbox3_editprofile'];
    $bcteleres_edit         = $_POST['checkbox4_editprofile'];
    $fiturfup_edit          = $_POST['enablefup_editprofile'];
    $pecahrate = strtoupper($rate_limittraf_edit);
    $pecahrate = explode("/", $pecahrate);

    //ratelimit sebelum fup
    $raterx = $pecahrate[0];
    $ratetx = $pecahrate[1];

    //ratelimit sesudah fup
    $rxfup      = $_POST['raterx_editprofile'] . $_POST['raterxname_editprofile'];
    $txfup      = $_POST['ratetx_editprofile'] . $_POST['ratetxname_editprofile'];

    //interval
    $interval   = $_POST['durasireset_editprofile'];

    //jam reset
    $jamreset   = $_POST['jamreset_editprofile'];
    if (strlen($jamreset) == 1) {
        $jamreset = "0" . $jamreset;
    }

    //targetfup
    $fup  = $_POST['fup_editprofile'] . $_POST['fupname_editprofile'];


    if ($trasparants_edit == true) {
        $trasparant_edit = 'yes';
    } else {
        $trasparant_edit = "no";
    }
    if ($rmvacc_edit == true) {
        $removeacc_edit = '1';
    } else {
        $removeacc_edit = "0";
    }
    if ($bctele_edit == true) {
        $bctelegram_edit = '1';
    } else {
        $bctelegram_edit = "0";
    }
    if ($bcteleres_edit == true) {
        $bctelegramres_edit = '1';
    } else {
        $bctelegramres_edit = "0";
    }

    if ($lock_macs_edit == 'enable') {
        $kuncimac_edit = '1';
    } else {
        $kuncimac_edit = '0';
    }

    if ($fiturfup_edit == true) {
        $fitfup_edit = '1';
    } else {
        $fitfup_edit = '0';
    }

    $on_login_edit = ':local rmcde ("' . $bctelegram_edit . $removeacc_edit . $kuncimac_edit . $bctelegramres_edit . $fitfup_edit . '|' . $_POST['fup_editprofile'] . '|' . $_POST['fupname_editprofile'] . '|' . $_POST['raterx_editprofile'] . '|' . $_POST['raterxname_editprofile'] . '|' . $_POST['ratetx_editprofile'] . '|' . $_POST['ratetxname_editprofile'] . '|' . $interval . '|' . $jamreset .  '");:local ut ("' . $validdity_edit . '");:local namaadmin ("' . $owner . '");:local bcadmin [:pick $rmcde 0];:local removeacc [:pick $rmcde 1];:local kuncimacnya [:pick $rmcde 2];:local bcreseller [:pick $rmcde 3];:local date [/system clock get date];:local timeq [/system clock get time];:local jamskr [/system clock get time];:local tglskr [:pick $date 4 6];:local blnskr [:pick $date 0 3];:local thnskr [:pick $date 7 11];:local tglq [:pick $date 4 6];:local blnq [:pick $date 0 3];:local thnq [:pick $date 7 11];:local garing ("/");:local td (":");:local macadd $"mac-address";:local ambilkomen [/ip hotspot user get [find where name="$user"] comment];:local ambilvoc [:pick $ambilkomen [:find $ambilkomen "voc :"] [:find $ambilkomen " | tgl :"]];:local ambilreseller [:pick $ambilkomen [:find $ambilkomen "ID : "] [:find $ambilkomen " | voc :"]];:local jenisvcnya [:pick $ambilvoc 6 50];:local namareseller [:pick $ambilreseller 5 50];:if ([:len [/system scheduler find name=$user]]=0) do={:if ($kuncimacnya=1) do={/ip hotspot user set mac-address=$"macadd" [find where name=$user]};/system scheduler add name="$user" interval=$ut  on-even="/ip hotspot active remove [find where user=$user];/ip hotspot user set [find where name=\"$user\"] limit-uptime=\"00:00:01\" comment=\"masuk masa tenggang\";/sys sch set [find where name=\"$user\"] name=\"tenggat_$user\" on-even=\":local hitung [/system scheduler get [find where name=\\\\\"tenggat_$user\\\\\"] run-count];:if ($removeacc=1) do={/ip hotspot user remove [find where name=\\\\\"$user\\\\\"]} else={/ip hotspot user set [find where name=\\\\\"$user\\\\\"] disable=yes};/ip hotspot cookie remove [find user=\\\\\"$user\\\\\"];:if (\\\\\$hitung < 5) do={/tool fetch http-method=post url=\\\\\"https://' . $domainnya . '/telegram_response.php\\\\\" http-data=\\\\\"idtelegram=$namareseller&status=expired&info=$user|$jenisvcnya|0|$namareseller|0|0|0|0|$rmcde\\\\\" keep-result=no};/sys sch remove [find where name=\\\\\"tenggat_$user\\\\\"];\";";:delay 2s;:local exp [/sys sch get [find where name="$user"] next-run];:local lexp [len $exp];:local komenusr [/ip hotspot user get [find where name="$user"] comment];:if ($lexp = 8) do={:set timeq [:pick $exp 0 8];};:if ($lexp = 15) do={:set blnq [:pick $exp 0 3];:set tglq [:pick $exp 4 6];:set timeq [:pick $exp 7 15];};:if ($lexp = 20) do={:set blnq [:pick $exp 0 3];:set tglq [:pick $exp 4 6];:set thnq [:pick $exp 7 11];:set timeq [:pick $exp 12 20];};/ip hotspot user set [find where name="$user"] comment="start $jamskr - $tglskr-$blnskr-$thnskr end $timeq - $tglq-$blnq-$thnq | $komenusr";/sys sch set [find where name="$user"] start-date="$blnq$garing$tglq$garing$thnq" start-time="$timeq" comment="berakhir pada $td $tglq $blnq $thnq pukul $timeq " interval="01:00:00";/tool fetch http-method=post url="https://' . $domainnya . '/telegram_response.php" http-data="idtelegram=$namareseller&status=start&info=$user|$jenisvcnya|$macadd|$namareseller|$jamskr|$tglskr-$blnskr-$thnskr|$timeq|$tglq-$blnq-$thnq|$rmcde" keep-result=no;};';

    //----tambah script FUP----


    // ubah rate rx dan tx ke bits lalu ke bytes
    // rx dan tx
    if (strpos($raterx, 'K')) {
        $rx = str_replace("K", "", $raterx);
        $bitsrx = $rx * 1024;
    } else if (strpos($raterx, 'M')) {
        $rx = str_replace("M", "", $raterx);
        $bitsrx = $rx * 1048576;
    } else if (strpos($raterx, 'G')) {
        $rx = str_replace("G", "", $raterx);
        $bitsrx = $rx * 1073741824;
    } else {
        $bitsrx = $raterx;
    }

    if (strpos($ratetx, 'K')) {
        $tx = str_replace("K", "", $ratetx);
        $bitstx = $tx * 1024;
    } else if (strpos($ratetx, 'M')) {
        $tx = str_replace("M", "", $ratetx);
        $bitstx = $tx * 1048576;
    } else if (strpos($ratetx, 'G')) {
        $tx = str_replace("G", "", $ratetx);
        $bitstx = $tx * 1073741824;
    } else {
        $bitstx = $ratetx;
    }

    $bytesrx = $bitsrx / 8;
    $bytestx = $bitstx / 8;

    // fup
    if (strpos($fup, 'K')) {
        $fup = str_replace("K", "", $fup);
        $bytefup = $fup * 1024;
    } else if (strpos($fup, 'M')) {
        $fup = str_replace("M", "", $fup);
        $bytefup = $fup * 1048576;
    } else if (strpos($fup, 'G')) {
        $fup = str_replace("G", "", $fup);
        $bytefup = $fup * 1073741824;
    } else {
        $bytefup = $fup;
    }

    // olah data
    $jmlbytes       = $bytesrx + $bytestx;
    $detiklomfup    = ($bytefup / $jmlbytes) + 60;

    // ratelimitnya di split, lalu colok ke on-login
    if ($fiturfup_edit == true) {
        $on_login_edit .= ':local ambilprofile [/ip hotspot user get [find where name="$user"] profile];:local apb [/ip hotspot user profile get [find where name="$ambilprofile"] insert-queue-before ];:if ([:len $apb] = 0 || $apb = "first") do={:set apb [/queue simple get [([find]->1)] name];};:local ratel [/ip hotspot user profile get [find where name="$ambilprofile"] rate-limit];:local ratel2;:local rtrate;:local rtburst;:local rtbt;:local rtbtime;:local prio;:local rtmin;:if ([:len $ratel] > 11) do={:for i from=0 to=([:len $ratel] - 1) do={:local char [:pick $ratel $i];:if ($char = " ") do={:set $char ",";};:set ratel2 ($ratel2 . $char);};:local ratel3 [:toarray $ratel2];:set rtrate ($ratel3->0);:set rtburst ($ratel3->1);:set rtbt ($ratel3->2);:set rtbtime ($ratel3->3);:set prio ($ratel3->4);:set rtmin ($ratel3->5);} else={:set rtrate $ratel;:set rtburst "0/0";:set rtbt "0/0";:set rtbtime "0/0";:set prio "8";:set rtmin "0/0";};/queue simple remove [find where name="<hotspot-$user>"];:local usedquota ([/ip hotspot user get [find where name="$user"] bytes-in] + [/ip hotspot user get [find where name="$user"] bytes-out]);:local date [/system clock get date];:local jam [/system clock get time];:local bln [:pick $date 0 3];:local tgl [:pick $date 4 6];:local thn [:pick $date 7 11];:local garing ("/");:if (' . $bytefup . ' < $usedquota) do={/queue simple add name="$user_hotspot_fup" target="$address" max-limit="' . $rxfup . '/' . $txfup . '" parent="' . $parent_edit . '" place-before="$apb" comment="$user sudah fup - MITHA FUP SCRIPT v1.2";} else={/queue simple add name="$user_hotspot_fup" target="$address" max-limit="$rtrate" burst-limit="$rtburst" burst-threshold="$rtbt" burst-time="$rtbtime" priority="$prio" limit-at="$rtmin" parent="' . $parent_edit . '" place-before="$apb" comment="$user belum fup - MITHA FUP SCRIPT v1.2";:if ([:len [/system scheduler find name="$user_FUP_MITHA"]]=0) do={/system scheduler add name="$user_FUP_MITHA" interval="00:00:' . $detiklomfup . '" on-event=":local sfup (' . $bytefup . ');:local susqu ([/ip hotspot user get [find where name=\"$user\"] bytes-in] + [/ip hotspot user get [find where name=\"$user\"] bytes-out]);:local data [/queue simple get [find where name=\"$user_hotspot_fup\"] bytes];:local data1 [:pick \$data 0 [:find \$data \"/\"]];:local data2 [:pick \$data ([:find \$data \"/\"] + 1) [:len \$data]];:local susqa (\$data1 + \$data2);:local sbytes (' . $jmlbytes . ');:local susq (\$susqu + \$susqa);:local slfup (' . $bytefup . ' - \$susq);:local ssec ((\$slfup / \$sbytes)+60);:local date [/system clock get date];:local jam [/system clock get time];:local bln [:pick \$date 0 3];:local tgl [:pick \$date 4 6];:local thn [:pick \$date 7 11];:local garing (\"/\");:if (' . $bytefup . ' < \$susq) do={/queue simple set [find where name=\"$user_hotspot_fup\"] max-limit=\"' . $rxfup . '/' . $txfup . '\" comment=\"$user sudah fup - MITHA FUP SCRIPT v1.0\";/sys schedule remove [find where name=\"$user_FUP_MITHA\"];} else={/sys sch set [find where name=\"$user_FUP_MITHA\"] interval=\"00:00:\$ssec\";:delay 5s;:local sexp [/sys sch get [find where name=\"$user_FUP_MITHA\"] next-run];:local slexp [len \$sexp];:if (\$slexp = 8) do={:set jam [:pick \$sexp 0 8];};:if (\$slexp = 15) do={:set bln [:pick \$sexp 0 3];:set tgl [:pick \$sexp 4 6];:set jam [:pick \$sexp 7 15];};:if (\$slexp = 20) do={:set bln [:pick \$sexp 0 3];:set tgl [:pick \$sexp 4 6];:set thn [:pick \$sexp 7 11];:set jam [:pick \$sexp 12 20];};/sys sch set [find where name=\"$user_FUP_MITHA\"] start-date=\"\$bln\$garing\$tgl\$garing\$thn\" start-time=\"\$jam\" interval=\"00:10:00\" comment=\"akan di cek kembali pada : \$jam - \$tgl \$bln \$thn\";}";:delay 5s;:local exp [/sys sch get [find where name="$user_FUP_MITHA"] next-run];:local lexp [len $exp];:if ($lexp = 8) do={:set jam [:pick $exp 0 8];};:if ($lexp = 15) do={:set bln [:pick $exp 0 3];:set tgl [:pick $exp 4 6];:set jam [:pick $exp 7 15];};:if ($lexp = 20) do={:set bln [:pick $exp 0 3];:set tgl [:pick $exp 4 6];:set thn [:pick $exp 7 11];:set jam [:pick $exp 12 20];};/sys sch set [find where name="$user_FUP_MITHA"] start-date="$bln$garing$tgl$garing$thn" start-time="$jam" interval="00:10:00" comment="akan di cek kembali pada : $jam - $tgl $bln $thn";}};:local prof [/ip hotspot user get [find where name="$user"] profile];:if ([:len [/sys sch find name="durasi_$prof_mitha"]]=0) do={/sys sch add name="durasi_$prof_mitha" interval="' . $interval . ':00:00" start-time="' . $jamreset . ':00:01" on-event=":local lst [/ip hotspot user find profile=\"$prof\"];:foreach usr in=\$lst do={:local nm [/ip hot us get \$usr name];/ip hot us res \$usr;/queue simple reset-counters [find where name=\"\$nm_hotspot_fup\"];:if ([:len [/ip hotspot active find user=\"\$nm\"]]=0) do={:local none \"0\";} else={/queue simple set [find where name=\"\$nm_hotspot_fup\"] max-limit=\"' . $raterx . '/' . $ratetx . '\" comment=\"\$nm belum fup - MITHA FUP SCRIPT v1.2\";:if ([:len [/system scheduler find name=\"\$nm_FUP_MITHA\"]]=0) do={/system scheduler add name=\"\$nm_FUP_MITHA\" interval=\"00:00:' . $detiklomfup . '\" on-event=\":local sfup (' . $bytefup . ');:local susqu ([/ip hotspot user get [find where name=\\\\\"\$nm\\\\\"] bytes-in] + [/ip hotspot user get [find where name=\\\\\"\$nm\\\\\"] bytes-out]);:local data [/queue simple get [find where name=\\\\\"\$nm_hotspot_fup\\\\\"] bytes];:local data1 [:pick \\\\\$data 0 [:find \\\\\$data \\\\\"/\\\\\"]];:local data2 [:pick \\\\\$data ([:find \\\\\$data \\\\\"/\\\\\"] + 1) [:len \\\\\$data]];:local susqa (\\\\\$data1 + \\\\\$data2);:local sbytes (' . $jmlbytes . ');:local susq (\\\\\$susqu + \\\\\$susqa);:local slfup (' . $bytefup . ' - \\\\\$susq);:local ssec ((\\\\\$slfup / \\\\\$sbytes)+60);:local date [/system clock get date];:local jam [/system clock get time];:local bln [:pick \\\\\$date 0 3];:local tgl [:pick \\\\\$date 4 6];:local thn [:pick \\\\\$date 7 11];:local garing (\\\\\"/\\\\\");:if (' . $bytefup . ' < \\\\\$susq) do={/queue simple set [find where name=\\\\\"\$nm_hotspot_fup\\\\\"] max-limit=\\\\\"' . $rxfup . '/' . $txfup . '\\\\\" comment=\\\\\"\$nm sudah fup - MITHA FUP SCRIPT v1.2\\\\\";/sys schedule remove [find where name=\\\\\"\$nm_FUP_MITHA\\\\\"];} else={/sys sch set [find where name=\\\\\"\$nm_FUP_MITHA\\\\\"] interval=\\\\\"00:00:\\\\\$ssec\\\\\";:delay 6s;:local sexp [/sys sch get [find where name=\\\\\"\$nm_FUP_MITHA\\\\\"] next-run];:local slexp [len \\\\\$sexp];:if (\\\\\$slexp = 8) do={:set jam [:pick \\\\\$sexp 0 8];};:if (\\\\\$slexp = 15) do={:set bln [:pick \\\\\$sexp 0 3];:set tgl [:pick \\\\\$sexp 4 6];:set jam [:pick \\\\\$sexp 7 15];};:if (\\\\\$slexp = 20) do={:set bln [:pick \\\\\$sexp 0 3];:set tgl [:pick \\\\\$sexp 4 6];:set thn [:pick \\\\\$sexp 7 11];:set jam [:pick \\\\\$sexp 12 20];};/sys sch set [find where name=\\\\\"\$nm_FUP_MITHA\\\\\"] start-date=\\\\\"\\\\\$bln\\\\\$garing\\\\\$tgl\\\\\$garing\\\\\$thn\\\\\" start-time=\\\\\"\\\\\$jam\\\\\" interval=\\\\\"00:10:00\\\\\" comment=\\\\\"akan di cek kembali pada : \\\\\$jam - \\\\\$tgl \\\\\$bln \\\\\$thn\\\\\";}\";}};delay 0.2s;};:log warning \"FUP RESET\";/sys sch rem \"durasi_$prof_mitha\";"}';

        $on_logout_edit = '/queue simple remove [find where name="$user_hotspot_fup"];/sys schedule remove [find where name="$user_FUP_MITHA"];';
    } else {
        $on_logout_edit = '';
    }

    $API->comm(
        '/ip/hotspot/user/profile/set',
        [
            '.id'               => $id_edit,
            'on-login'          => $on_login_edit,
            'parent-queue'      => $parent_edit,
            'shared-users'      => $shared_userscount_edit,
            'rate-limit'        => $rate_limittraf_edit,
            'transparent-proxy' => $trasparant_edit,
            'on-logout'         => $on_logout_edit,


        ]
    );



    echo '<script language="javascript">';
    echo 'document.addEventListener("DOMContentLoaded", function() {';
    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success  Edit Profile Hotspot </center>");';
    echo '});';
    echo '</script>';
    echo "<script>setTimeout(\"location.href = '?Mikbotam=profilelist';\", 2000);</script>";
}

if (isset($_POST['deleteprofile'])) {

    $id_edit = $_POST['uid_editprofile'];
    $API->comm("/ip/hotspot/user/profile/remove", [".id" => $id_edit]);

    echo '<script language="javascript">';
    echo 'document.addEventListener("DOMContentLoaded", function() {';
    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success Remove Profile Hotspot </center>");';
    echo '});';
    echo '</script>';
    echo "<script>setTimeout(\"location.href = '?Mikbotam=profilelist';\", 2000);</script>";
}





?>

<script>
    var _0x82f1 = ["show.bs.modal", "id", "data", "relatedTarget", "cursor", "wait", "css", "body", "../hotspot/profile_edit.php", "id=", "html", "#view-respont", "default", "ajax", "on", "#profileedit"];

    function editprofileuser() {
        $(_0x82f1[15])[_0x82f1[14]](_0x82f1[0], function(_0xfe4ax2) {
            var _0xfe4ax3 = $(_0xfe4ax2[_0x82f1[3]])[_0x82f1[2]](_0x82f1[1]);
            $(_0x82f1[7])[_0x82f1[6]](_0x82f1[4], _0x82f1[5]);
            $[_0x82f1[13]]({
                url: _0x82f1[8],
                data: _0x82f1[9] + _0xfe4ax3,
                cache: false,
                success: function(_0xfe4ax4) {
                    $(_0x82f1[11])[_0x82f1[10]](_0xfe4ax4);
                    $(_0x82f1[7])[_0x82f1[6]](_0x82f1[4], _0x82f1[12])
                }
            })
        })
    }
</script>

<div class="sl-pagebody">
    <div class="card bd-primary mg-t-3">
        <div class="card-header bg-primary tx-white"><i class="fa fa-user"></i> User Profile Manager</div>
        <div class="card-body pd-sm-15">

            <div class="table-wrapper">
                <table id="profilehotspot" class="table display nowrap " width="100%">
                    <thead>
                        <tr>
                            <th>Profile Name</th>
                            <th>Rate Limit <br>(rx/tx)</th>
                            <th>Parent Queue</th>
                            <th>Duration</th>
                            <th>Auto Delete <br>Voucher</th>
                            <th>Owner<br>Telegram<br>Notif</th>
                            <th>Reseller<br>Telegram<br>Notif</th>
                            <th>Lock <br>User</th>
                            <th>Shared<br> User</th>
                            <th>Transparent <br>Proxy</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($seeprofile as $index => $baris) :
                        ?>
                            <tr>
                                <!--AMBIL DATA DULU-->
                                <?php

                                $dataonlogin = $baris['on-login'];
                                $dataonlogin2 = explode(":local rmcde (\"", $dataonlogin);
                                $dataonlogin3 = explode("\");:local ut (\"", $dataonlogin2[1]);


                                ?>
                                <!--nama-->
                                <td><a href='#profileedit' class="txt-black" data-toggle='modal' onclick='editprofileuser();' data-id="<?= $baris['.id']; ?>"><i class='fa fa-pencil-square-o'></i> <?php echo $baris['name']; ?></a></td>
                                <!--Rate Limit-->
                                <td><?php echo $baris['rate-limit']; ?></td>
                                <!--Parent Queue-->
                                <td><?php echo $baris['parent-queue']; ?></td>
                                <!--Duration-->
                                <td><?php

                                    if (preg_match("/rmcde/i", $dataonlogin)) {

                                        $ambildata = explode("ut (\"", $dataonlogin);

                                        if (preg_match("/idtelegram/", $dataonlogin)) {

                                            $ambildata2 = explode("\");:local idtelegram (\"", $ambildata[1]);

                                            echo $ambildata2[0];
                                        } else if (preg_match("/namaadmin/", $dataonlogin)) {

                                            $ambildata2 = explode("\");:local namaadmin (\"", $ambildata[1]);

                                            echo $ambildata2[0];
                                        } else {
                                            echo "NONE";
                                        }
                                    } else {

                                        echo "NONE";
                                    }

                                    ?></td>
                                <!--Auto Delete Voucher-->
                                <td><?php

                                    if (preg_match("/rmcde/i", $dataonlogin)) {

                                        $delvcr = substr($dataonlogin3[0], 1, 1);

                                        if ($delvcr == 1) {
                                            echo "YES";
                                        } else {
                                            echo "NO";
                                        }
                                    } else {

                                        echo "NO";
                                    }
                                    ?></td>

                                <!--Owner Telegram Notif-->
                                <td><?php

                                    if (preg_match("/rmcde/i", $dataonlogin)) {

                                        $telenotip = substr($dataonlogin3[0], 0, 1);

                                        if ($telenotip == 1) {
                                            echo "YES";
                                        } else {
                                            echo "NO";
                                        }
                                    } else {

                                        echo "NO";
                                    }
                                    ?></td>
                                <!--Reseller Telegram Notif-->
                                <td><?php

                                    if (preg_match("/rmcde/i", $dataonlogin)) {

                                        $restelenotip = substr($dataonlogin3[0], 3, 1);

                                        if ($restelenotip == 1) {
                                            echo "YES";
                                        } else {
                                            echo "NO";
                                        }
                                    } else {

                                        echo "NO";
                                    }
                                    ?></td>
                                <!--Lock User-->
                                <td><?php

                                    if (preg_match("/rmcde/i", $dataonlogin)) {

                                        $lockuser = substr($dataonlogin3[0], 2, 1);;


                                        if ($lockuser == 1) {
                                            echo "YES";
                                        } else {
                                            echo "NO";
                                        }
                                    } else {

                                        echo "NO";
                                    }
                                    ?></td>
                                <!--Shared User-->
                                <td><?php echo $baris['shared-users']; ?></td>
                                <!--Transparent Proxy-->
                                <td><?php

                                    $tranprox = $baris['transparent-proxy'];


                                    if ($tranprox == "true") {
                                        echo 'YES';
                                    } else {
                                        echo "NO";
                                    }

                                    ?></td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<!-- CODE VARIABLE POP UP NYA -->



<!-- FORM POP UP NYA -->

<div id="ProfileHotspotAdd" class="modal fade" role="dialog">

    <div class="modal-dialog wd-100p mn-wd-50p" role="document">
        <div class="modal-content tx-size-sm">
            <div class="modal-header pd-x-25 bg-primary">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-white tx-bold">Add Profile Hotspot </h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body pd-15">
                <div class="card bd bd-primary  ">
                    <div class="card-body pd-sm-15">

                        <form action="" method="post">

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Profile Name : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                            </div>


                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Parent Queue : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <select class="form-control" name="parent" data-toggle="tooltip" data-placement="top" title="Jika kosong pilih none">
                                        <option>none</option>
                                        <?php foreach ($getallqueue as $index => $barisan) : ?>

                                            <option value="<?= $barisan['name'] ?>"><?= $barisan['name'] ?></option>

                                        <?php endforeach;
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Rate Limit [rx/tx] : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" class="form-control" name="rate-limit" value="" data-toggle="tooltip" data-placement="top" title="example 1M/512k, salah penulisan maka data tidak terinput" placeholder="1M/512k">
                                </div>
                            </div>



                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Shared Users : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input id="colorful2" class="form-control" name="shared-users" type="number" min="1" max="100" value="1" onkeypress="return isNumber(event)" />
                                </div>
                            </div>



                            <div class="row mg-t-10">
                                <label class="col-sm-4 form-control-label">DURATION </label>

                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">day/s : </label>
                                <div class="col-sm-2 mg-t-0 mg-sm-t-0">
                                    <input type="number" class="form-control" name="valid_time1" value="00" data-toggle="tooltip" data-placement="top" title="numerik only" placeholder="00" required>
                                </div>
                                <div class="col-sm-0 mg-t-0 mg-sm-t-10">
                                    day/s
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Hours : Mnt : Scnd</label>
                                <div class="col-sm-2 mg-t-10 mg-sm-t-0">
                                    <input type="number" class="form-control" name="valid_time2" value="00" data-toggle="tooltip" data-placement="top" title="numerik only" placeholder="00" required>
                                </div>
                                <div class="col-sm-0 mg-t-0 mg-sm-t-10">
                                    :
                                </div>
                                <div class="col-sm-2 mg-t-10 mg-sm-t-0">
                                    <input type="number" class="form-control" name="valid_time3" value="00" data-toggle="tooltip" data-placement="top" title="numerik only" placeholder="00" required>
                                </div>
                                <div class="col-sm-0 mg-t-0 mg-sm-t-10">
                                    :
                                </div>
                                <div class="col-sm-2 mg-t-10 mg-sm-t-0">
                                    <input type="number" class="form-control" name="valid_time4" value="00" data-toggle="tooltip" data-placement="top" title="numerik only" placeholder="00" required>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Lock User : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <select class="form-control select2id" name="lock_mac" data-placeholder="Select Type" data-toggle="tooltip" data-placement="top" title="Lock username dengan Mac">
                                        <option value="disable">Disable</option>
                                        <option value="enable">Enable</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label" for="checkbox2">Auto Delete Voucher : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <label class="ckbox">
                                        <input type="checkbox" name="checkbox2" value="true" id="checkbox2"><span>Yes</span> </label>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label" for="checkbox3">Owner Telegram Notification :</label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <label class="ckbox">
                                        <input type="checkbox" name="checkbox3" value="true" id="checkbox3"><span>Yes</span> </label>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label" for="checkbox4">Reseller Telegram Notification :</label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <label class="ckbox">
                                        <input type="checkbox" name="checkbox4" value="true" id="checkbox4"><span>Yes</span> </label>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label" for="checkbox">Transparent Proxy :</label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <label class="ckbox">
                                        <input type="checkbox" name="checkbox" value="true" id="checkbox"><span>Transparent</span> </label>
                                </div>
                            </div>
                            <br>
                            <hr>
                            <br>
                            <!-- FORM FUP -->
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label" for="enablefup">ENABLE FUP :</label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <label class="ckbox">
                                        <input type="checkbox" name="enablefup" value="true" id="enablefup"><span>YES</span> </label>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Target FUP : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="number" value="1" name="fup" size="5" id="targetfup" disabled required>
                                    <select name="fupname" id="fupid" disabled>
                                        <option value="">Byte</option>
                                        <option value="K">kByte</option>
                                        <option value="M">MByte</option>
                                        <option value="G">GByte</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Rate Limit Sesudah FUP (Rx/Tx) (Upload/Download) : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="number" value="1" name="raterx" size="5" id="raterx" disabled required>
                                    <select name="raterxname" id="raterxid" disabled>
                                        <option value="">bps</option>
                                        <option value="K">Kbps</option>
                                        <option value="M">Mbps</option>
                                        <option value="G">Gbps</option>
                                    </select> /
                                    <input type="number" value="1" name="ratetx" size="5" id="ratetx" disabled required>
                                    <select name="ratetxname" id="ratetxid" disabled>
                                        <option value="">bps</option>
                                        <option value="K">Kbps</option>
                                        <option value="M">Mbps</option>
                                        <option value="G">Gbps</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Reset Tiap : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="number" value="1" name="durasireset" size="5" id="durasireset" disabled required> Jam

                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Jam Reset (00 - 23) : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="number" value="01" min="00" max="23" name="jamreset" size="5" id="jamreset" disabled required>

                                </div>
                            </div>


                            <div class="row row-xs mg-t-10">
                                <div class="col-sm-15 mg-l-auto">
                                    <div class="form-layout-footer">
                                        <button type="submit" class="btn bg-primary tx-white" name="saveprofile">Save changes</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="reset" class="btn btn-danger">Reset</button>
                                    </div>
                                    <!-- form-layout-footer -->
                                </div>
                                <!-- col-8 -->
                            </div>

                        </form>
                    </div>

                </div>


            </div>
        </div>

    </div>
</div>

</div>

<div id="profileedit" class="modal fade" role="dialog">
    <div class="modal-dialog wd-100p mn-wd-50p" role="document">
        <div class="modal-content tx-size-sm">
            <div class="modal-header pd-x-25 bg-primary">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-white tx-bold">Edit Profile Hotspot </h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body pd-15">
                <div id="view-respont">

                    <h2>Loading...</h2>
                </div>

            </div>
        </div>

    </div>
</div>

<script src="../lib/bootstrap/bootstrap.js"></script>
<script src="../js/MikbotamNumberCheck.js"></script>

<script>
    $(document).ready(function() {


        // Initialize tooltip
        $('[data-toggle="tooltip"]').tooltip();

        // Initialize popover
        $('[data-popover-color="default"]').popover();

        $(document).on('click', function(e) {
            $('[data-toggle="popover"],[data-original-title]').each(function() {
                //the 'is' for buttons that trigger popups
                //the 'has' for icons within a button that triggers a popup
                if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
                    (($(this).popover('hide').data('bs.popover') || {}).inState || {}).click = false // fix for BS 3.3.6
                }

            });
        });

    });
    $('#colorful1,#colorful2,#colorful3,#colorful4,#colorful5,#colorful6').bootstrapNumber({
        upClass: 'success',
        downClass: 'danger'
    });



    document.getElementById("enablefup").onchange = function() {
        document.getElementById("targetfup").disabled = !this.checked;
        document.getElementById("fupid").disabled = !this.checked;
        document.getElementById("raterx").disabled = !this.checked;
        document.getElementById("raterxid").disabled = !this.checked;
        document.getElementById("ratetx").disabled = !this.checked;
        document.getElementById("ratetxid").disabled = !this.checked;
        document.getElementById("durasireset").disabled = !this.checked;
        document.getElementById("jamreset").disabled = !this.checked;



    }
</script>