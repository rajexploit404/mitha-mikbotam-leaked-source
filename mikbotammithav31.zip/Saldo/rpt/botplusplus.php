<?php

/*
PERINTAH YANG SUDAH DIGUNAKAN
- /laptgl
- /lapbul
- /reseller
- /cekvcr
- /pesan
- /lap
- /rekap
- /transfer
- /rekapall
- /delreport

*/
date_default_timezone_set('Asia/Jakarta');
include 'src/FrameBot.php';
include 'rpt/functions.php';
require_once '../config/system.conn.php';
$mkbot = new FrameBot($token, $usernamebot);
require_once '../config/system.byte.php';
require_once '../Api/routeros_api.class.php';

//---------rekap harian-------
$mkbot->cmd('/laptgl', function ($tglnya, $blnnya, $thnnya) {

   include('../config/system.conn.php');
   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');

   if ($idtelegram == $id_own) {
      if (empty($tglnya) || empty($blnnya) || empty($thnnya) || strlen($tglnya) !== 2 || strlen($blnnya) !== 2 || strlen($thnnya) !== 4 || is_numeric($tglnya) == false || is_numeric($blnnya) == false || is_numeric($thnnya) == false) {
         $text = "maaf format salah, tulis dengan format /laptgl(spasi)tgl bln thn, contoh : /laptgl 30 03 2020";
      } else {

         $tanggalan = $thnnya . "-" . $blnnya . "-" . $tglnya;
         $tanggalnya = $tglnya . "-" . $blnnya . "-" . $thnnya;

         $totalvchr = jumlahvchrharian($tanggalan);
         $mutasivchr = rupiah(mutasivchrharian($tanggalan));
         $topupvchr =  rupiah(ngitungtopup($tanggalan));

         $text = "LAPORAN tanggal <b>" . $tanggalnya . "</b>\n";
         $text .= "==============\n";
         $text .= "Voucher terjual : <b>" . $totalvchr . " Vouchers</b>\n";
         $text .= "Mutasi Voucher : <b>" . $mutasivchr . "</b>\n";
         $text .= "Top Up : <b>" . $topupvchr . "</b>\n";
         $text .= "==============";
      }
   } else {

      $text = "Maaf..! Akses Hanya untuk Administator";
   }

   $options = ['parse_mode' => 'html'];

   return Bot::sendMessage($text, $options);
});
//---------------------------  
// mentransfer saldo ke reseller lain
$mkbot->cmd('/transfer', function ($idtujuan, $nominal) {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   $isipesan     = $info['text'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');

   $text = "";

   if (has($idtelegram)) {

      if (!empty($idtujuan) || !empty($nominal)) {

         if (has($idtujuan)) {

            $saldopengirim = lihatsaldo($idtelegram);
            $saldopenerima = lihatsaldo($idtujuan);

            if ($saldopengirim > $nominal) {

               $saldoawal = lihatsaldo($idtelegram);
               $transfersaldo = transfersaldo($idtelegram, $idtujuan, $nominal);
               $sisasaldo = lihatsaldo($idtelegram);

               $text .= "TRANSFER BERHASIL\n";
               $text .= "=============\n";
               $text .= "ID tujuan : " . $idtujuan . "\n";
               $text .= "Nominal transfer : " . rupiah($nominal) . "\n";
               $text .= "Saldo awal : " . rupiah($saldoawal) . "\n";
               $text .= "Saldo akhir : " . rupiah($sisasaldo) . "\n";
               $text .= "=============\n";

               $isipesan = "anda mendapat transfer deposit senilai " . $nominal;


               $website = "https://api.telegram.org/bot" . $token;
               $params  = [
                  'chat_id' => $idtujuan,
                  'text' => $isipesan,
                  'parse_mode' => 'html',
               ];
               $ch = curl_init($website . '/sendMessage');
               curl_setopt($ch, CURLOPT_HEADER, false);
               curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
               curl_setopt($ch, CURLOPT_POST, 1);
               curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
               curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
               $result = curl_exec($ch);
               curl_close($ch);
            } else {
               $text .= "maaf saldo anda tidak cukup";
            }
         } else {
            $text .= "maaf id user ini tidak terdaftar";
         }
      } else {
         $text .= "maaf penulisan belum lengkap, contoh : /transfer 12345678 100000";
      }
   } else {
      $text .= "maaf id anda belum terdaftar, silahkan ketik /daftar terlebih dahulu";
   }

   $options = ['parse_mode' => 'html',];
   return Bot::sendMessage($text, $options);
});

//---------/cekvcr----------
$mkbot->cmd('/cekvcr', function ($cek_vcr) {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');
   $cekpcr       = $cek_vcr;
   $API = new routeros_api();
   if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
      $jadwal = $API->comm('/system/scheduler/getall');
      $userlst = $API->comm('/ip/hotspot/user/getall');
      $useract = $API->comm('/ip/hotspot/active/getall');

      $cari = array_search($cekpcr, array_column($jadwal, 'name'));
      $array_jadwal = $jadwal[$cari];
      $hasilakhir = $array_jadwal['comment'];

      $cariul = array_search($cekpcr, array_column($userlst, 'name'));
      $array_ul = $userlst[$cariul];
      $user_comment = $array_ul['comment'];
      $user_status = $array_ul['disabled'];

      $cariac = array_search($cekpcr, array_column($useract, 'user'));
      $array_ac = $useract[$cariac];

      //ambil data limit byte total
      $lbttl = ceil($array_ul['limit-bytes-total'] / 1000000);
      if ($lbttl == 0) {
         $lbttl = "unlimited";
      }
      //ambil data byte in dan out di USER
      $dtin = $array_ul['bytes-in'];
      $dtout = $array_ul['bytes-out'];
      //ambil data byte in dan out di ACTIVE
      $adtin = $array_ac['bytes-in'];
      $adtout = $array_ac['bytes-out'];

      //total kuota terpakai
      $ttlkuota = ($dtin + $dtout + $adtin + $adtout) / 1000000;

      //sisa kuota
      $sisakuota = floor($lbttl - $ttlkuota);
      if ($sisakuota < 0) {
         $sisakuota = "-";
      }
   } else {
      $hasilakhir = "maaf server error, silahkan coba 5 menit lagi";
   }

   if (strpos($hasilakhir, "berakhir") !== false) {

      $cetak = "masa aktif voucher <b>" . $cekpcr . " " . $hasilakhir . "</b>\n";
      $cetak .= "sisa kuota anda <b>" . $sisakuota . " Mb </b>\n";
      $cetak .= "kuota yang sudah digunakan <b>" . ceil($ttlkuota) . " Mb </b>\n";
      $cetak .= "total kuota anda <b>" . $lbttl . " Mb </b>";
   } else if ($cekpcr == "") {

      $cetak = "silahkan tulis kode voucher dengan format /cekvcr(spasi)<b>(kode voucher)</b> contoh : /cekvcr 1234";
   } else if (strpos($user_comment, "MIKBOTAM") !== false && $user_status == "false") {

      $cetak = "voucher <b>" . $cekpcr . "</b> tersedia dan belum digunakan";
   } else {

      $cetak = "maaf kode <b>" . $cekpcr . "</b> tidak ditemukan/sudah expired ";
   }


   $options = [
      'parse_mode' => 'html'
   ];
   return Bot::sendMessage($cetak, $options);
});

//------ list reseller --------

$mkbot->cmd('/reseller', function () {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');
   $data = lihatdata();
   $pecahdata = array_chunk($data, 10);

   if ($idtelegram == $id_own) {

      $num = count($data);
      $text = "    Total reseller " . $num . "\n";
      $text .= "==============================\n";
      $options = ['parse_mode' => 'html'];
      Bot::sendMessage($text, $options);

      foreach ($pecahdata as $a) :
         $text = "";
         foreach ($a as $index => $baris) :

            $barisdiskon  = $baris['other'];
            $barissaldo   = $baris['saldo'];
            $barisvctele  = $baris['voucher_terjual'];
            $barisvcfisik = $baris['voucherlast'];
            $barisvcomset = $baris['othertho'];

            if (empty($baris['other'])) {
               $barisdiskon = 0;
            }
            if (empty($baris['saldo'])) {
               $barissaldo = 0;
            }
            if (empty($baris['voucher_terjual'])) {
               $barisvctele = 0;
            }
            if (empty($baris['voucherlast'])) {
               $barisvcfisik = 0;
            }
            if (empty($baris['othertho'])) {
               $barisvcomset = 0;
            }

            $text .= "<code>===============\n";
            $text .= "ID     : " . $baris['id_user'] . "\n";
            $text .= "USER   : " . $baris['nama_seller'] . "\n";
            $text .= "---------------\n";
            $text .= "SALDO  : " . rupiah($barissaldo) . "\n";
            $text .= "DISKON : " . $barisdiskon . " %\n";
            $text .= "==============================</code>\n";

            $options = ['parse_mode' => 'html'];

         endforeach;
         Bot::sendMessage($text, $options);
      endforeach;

      $text = "ket : \n";
      $text .= "<b> untuk cek data transaksi reseller, silahkan pakai perintah </b> /rekapall";
      $options = ['parse_mode' => 'html'];

      return Bot::sendMessage($text, $options);
   } else {

      $text = "Maaf..! Akses Hanya untuk Administator";
      $options = ['parse_mode' => 'html'];

      return Bot::sendMessage($text, $options);
   }
});

//-----------rekap bulanan------
$mkbot->cmd('/lapbul', function () {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');
   $data = lihatdata();

   if ($idtelegram == $id_own) {

      $totalvcbln = countvoucher();
      $mutasivcbln = rupiah(estimasidata());
      $topupvcbln =  rupiah(getcounttopup());
      $text = "LAPORAN BULAN INI\n";
      $text .= "==============\n";
      $text .= "Voucher Bulan ini <b>" . $totalvcbln . " Vouchers</b>\n";
      $text .= "Mutasi Voucher Bulan ini <b>" . $mutasivcbln . "</b>\n";
      $text .= "Top Up Bulan ini <b>" . $topupvcbln . "</b>\n";
      $text .= "==============";
   } else {

      $text = "Maaf..!!! Akses Hanya untuk Administator";
   }
   $options = ['parse_mode' => 'html'];

   return Bot::sendMessage($text, $options);
});

//--------------kirim pesan massal-----

$mkbot->cmd('/pesan', function ($isipesan) {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');
   $data = lihatdata();

   if ($idtelegram == $id_own) {

      $text = "kirim pesan massal ke : \n\n";

      foreach ($data as $index => $jembreng) {

         $ids = $jembreng['id_user'];
         $resellernya = $jembreng['nama_seller'];

         $website = "https://api.telegram.org/bot" . $token;
         $params  = [
            'chat_id' => $ids,
            'text' => $isipesan,
            'parse_mode' => 'html',
         ];
         $ch = curl_init($website . '/sendMessage');
         curl_setopt($ch, CURLOPT_HEADER, false);
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
         curl_setopt($ch, CURLOPT_POST, 1);
         curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
         $result = curl_exec($ch);
         curl_close($ch);
         $text .= "- @" . $resellernya . "\n";
      }

      $text .= "\n sukses";
   } else {

      $text = "Maaf..!!! Akses Hanya untuk Administator";
   }
   $options = ['parse_mode' => 'html'];

   return Bot::sendMessage($text, $options);
});



//===================== cek laporan range tanggal tertentu ==========


$mkbot->cmd('/lap', function ($tglnya1, $tglnya2) {

   include('../config/system.conn.php');
   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');
   $data = lihatdata();
   $num = count($data);

   if ($idtelegram == $id_own) {
      if (empty($tglnya1) || empty($tglnya2) || strlen($tglnya1) !== 8 || strlen($tglnya2) !== 8 || is_numeric($tglnya1) == false || is_numeric($tglnya2) == false) {
         $text = "maaf format salah, tulis dengan format /lap(spasi)tglblntahunawal(spasi)tglblntahunakhir, contoh : /lap 01032020 30032020";
         $options = ['parse_mode' => 'html'];
      } else {
         //$thnnya."-".$blnnya."-".$tglnya;

         $tglawal = substr($tglnya1, -4) . "-" . substr($tglnya1, 2, 2) . "-" . substr($tglnya1, 0, 2);
         $tglakhir = substr($tglnya2, -4) . "-" . substr($tglnya2, 2, 2) . "-" . substr($tglnya2, 0, 2);

         $tglawalctk = substr($tglnya1, 0, 2) . "-" . substr($tglnya1, 2, 2) . "-" . substr($tglnya1, -4);
         $tglakhirctk = substr($tglnya2, 0, 2) . "-" . substr($tglnya2, 2, 2) . "-" . substr($tglnya2, -4);

         $topupvchr = ngitungtopuprange($tglawal, $tglakhir);
         $mutasivchr = mutasivchrrange($tglawal, $tglakhir);
         $totalvchr = jumlahvchrrange($tglawal, $tglakhir);


         $text = "LAPORAN tanggal <b>" . $tglawalctk . " - " . $tglakhirctk . "</b>\n";
         $text .= "==============\n";
         $text .= "Voucher terjual : <b>" . $totalvchr . " Vouchers</b>\n";
         $text .= "Mutasi Voucher : <b>" . rupiah($mutasivchr) . "</b>\n";
         $text .= "Top Up : <b>" . rupiah($topupvchr) . "</b>\n";
         $text .= "==============\n";
         $text .= "Total reseller " . $num . "\n";
         $text .= "===============\n";

         $options = ['parse_mode' => 'html'];

         Bot::sendMessage($text, $options);


         foreach ($data as $index => $baris) :
            $text = "ID : " . $baris['id_user'] . "\n";
            $text .= "USER : " . $baris['nama_seller'] . "\n";
            $text .= "jml pendapatan : " . rupiah(jmlpendapatanrange($baris['id_user'], $tglawal, $tglakhir)) . "\n";
            $text .= "Jml Vcr dicetak : " . jmlvcrange($baris['id_user'], $tglawal, $tglakhir) . "\n";
            $text .= "===============\n";
            $options = ['parse_mode' => 'html'];
            Bot::sendMessage($text, $options);
         endforeach;
         $text = "==END==";

         $options = ['parse_mode' => 'html'];
         return Bot::sendMessage($text, $options);
      }
   } else {

      $text = "Maaf..! Akses Hanya untuk Administator";

      $options = ['parse_mode' => 'html'];

      return Bot::sendMessage($text, $options);
   }
});

//-----------rekap reseller untuk owner ------
$mkbot->cmd('/rekapall', function () {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');
   $data = lihatdata();
   $pecahdata = array_chunk($data, 2);

   if ($idtelegram == $id_own) {
      $text = "silahkan pilih reseller yang akan direkap";
      $send = [];
      foreach ($pecahdata as $index => $satuan) {

         $reseller1 = ['text' => $satuan[0]['nama_seller'] . '', 'callback_data' => $satuan[0]['nama_seller'] . 'resellerinfo' . $satuan[0]['id_user'] . ''];

         $reseller2 = ['text' => $satuan[1]['nama_seller'] . '', 'callback_data' => $satuan[1]['nama_seller'] . 'resellerinfo' . $satuan[1]['id_user'] . ''];

         $baris = array_filter([$reseller1, $reseller2]);

         array_push($send, $baris);
      }

      $options = [
         'reply_markup' => json_encode(['inline_keyboard' => $send]),
         'parse_mode' => 'html'
      ];
   } else {

      $text = "Maaf..!!! Akses Hanya untuk Administator";
      $options = ['parse_mode' => 'html'];
   }


   return Bot::sendMessage($text, $options);
});

//-----------hapus report 3 bulan kebelakang dan bulan lalu ------
$mkbot->cmd('/delreport', function () {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');
   $data = lihatdata();
   $pecahdata = array_chunk($data, 2);

   if ($idtelegram == $id_own) {
      $text = "<b>Pilih data rekap yang akan dihapus</b>";
      $text .= "\ndengan menghapus data ini maka akan meringankan kerja server mikbotam anda";

      $send = [

         [
            ['text' => '1 BLN LALU', 'callback_data' => 'hapusreport1blnlalu']
         ],
         [
            ['text' => 'SETELAH 3 BLN ', 'callback_data' => 'hapusreport3blnlalu']
         ]
      ];

      $options = [
         'reply_markup' => json_encode(['inline_keyboard' => $send]),
         'parse_mode' => 'html'
      ];
   } else {

      $text = "Maaf..!!! Akses Hanya untuk Administator";
      $options = ['parse_mode' => 'html'];
   }


   return Bot::sendMessage($text, $options);
});

//-----------rekap reseller omset dan jumlah vc telegram dan generate (bulan ini dan hari ini)------
$mkbot->cmd('/rekap', function ($tglawal, $tglakhir) {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');
   $text = "";

   if (!empty($tglawal) || !empty($tglakhir)) {
      if (strlen($tglawal) !== 8 || strlen($tglakhir) !== 8 || is_numeric($tglawal) == false || is_numeric($tglakhir) == false) {
         $text .= 'maaf format salah, yang benar "/rekap" atau "/rekap tglblnthn tglblnthn",';
         $text .= "\nuntuk contoh format => /rekap 30112020 01122020";
      } else {
         $formattglawal = substr($tglawal, -4) . "-" . substr($tglawal, 2, 2) . "-" . substr($tglawal, 0, 2);
         $formattglakhir = substr($tglakhir, -4) . "-" . substr($tglakhir, 2, 2) . "-" . substr($tglakhir, 0, 2);

         $tglawalctk = substr($tglawal, 0, 2) . "-" . substr($tglawal, 2, 2) . "-" . substr($tglawal, -4);
         $tglakhirctk = substr($tglakhir, 0, 2) . "-" . substr($tglakhir, 2, 2) . "-" . substr($tglakhir, -4);
         $waktu = [$formattglawal, $formattglakhir];
         $rekap = grabvc($idtelegram, $waktu);

         $text .= "<code>Rekap Tgl : " . $tglawalctk . " s/d " . $tglakhirctk . "\n";
         $text .= "\n== OMSET Voucher Telegram ==\n";
         $text .= "VC-Telegram : " . $rekap['jmlvc'] . " vcr\n";
         $text .= "Omset : " . rupiah($rekap['hrgvc'] + $rekap['markvc']) . " \n";
         $text .= "Modal : " . rupiah($rekap['hrgvc']) . " \n";
         $text .= "Keuntungan : " . rupiah($rekap['markvc']) . " \n";
         $text .= "\n== OMSET Voucher Fisik ==\n";
         $text .= "VC-Fisik terjual : " . $rekap['vcgenlaku'] . " vcr\n";
         $text .= "Omset : " . rupiah($rekap['hrggen'] + $rekap['markgen']) . " \n";
         $text .= "Modal : " . rupiah($rekap['hrggen']) . " \n";
         $text .= "Keuntungan : " . rupiah($rekap['markgen']) . " \n";
         $text .= "=======</code>\n";
      }
   } else {
      $rekap = rekapreseller($idtelegram);
      $text .= "<code>REKAP PENJUALAN\n\n";
      $text .= "Saldo saat ini : " . rupiah($rekap['saldo']) . " \n";
      $text .= "\n== HARI INI ==\n";
      $text .= "\n== OMSET Voucher Telegram ==\n";
      $text .= "VC-Telegram : " . $rekap['jmlvc_hariini'] . " vcr\n";
      $text .= "Omset : " . rupiah($rekap['omsetvc_hariini'] + $rekap['markvc_hariini']) . " \n";
      $text .= "Modal : " . rupiah($rekap['omsetvc_hariini']) . " \n";
      $text .= "Keuntungan : " . rupiah($rekap['markvc_hariini']) . " \n";
      $text .= "\n== OMSET Voucher Fisik ==\n";
      $text .= "VC-Fisik dicetak : " . $rekap['jmlgen_hariini'] . " vcr\n";
      $text .= "VC-Fisik terjual : " . $rekap['vcgenlaku_hariini'] . " vcr\n";
      $text .= "Omset : " . rupiah($rekap['omsetgen_hariini'] + $rekap['markgen_hariini']) . " \n";
      $text .= "Modal : " . rupiah($rekap['omsetgen_hariini']) . " \n";
      $text .= "Keuntungan : " . rupiah($rekap['markgen_hariini']) . " \n";

      $text .= "\n== BULAN INI ==\n";
      $text .= "\n== OMSET Voucher Telegram ==\n";
      $text .= "VC-Telegram : " . $rekap['jmlvc_blnini'] . " vcr\n";
      $text .= "Omset : " . rupiah($rekap['omsetvc_blnini'] + $rekap['markvc_blnini']) . " \n";
      $text .= "Modal : " . rupiah($rekap['omsetvc_blnini']) . " \n";
      $text .= "Keuntungan : " . rupiah($rekap['markvc_blnini']) . " \n";
      $text .= "\n== OMSET Voucher Fisik ==\n";
      $text .= "VC-Fisik dicetak : " . $rekap['jmlgen_blnini'] . " vcr\n";
      $text .= "VC-Fisik terjual : " . $rekap['vcgenlaku_blnini'] . " vcr\n";
      $text .= "Omset : " . rupiah($rekap['omsetgen_blnini'] + $rekap['markgen_blnini']) . " \n";
      $text .= "Modal : " . rupiah($rekap['omsetgen_blnini']) . " \n";
      $text .= "Keuntungan : " . rupiah($rekap['markgen_blnini']) . " \n";
      $text .= "=======</code>\n";
   }
   $options = ['parse_mode' => 'html'];

   return Bot::sendMessage($text, $options);
});

//cek HOTSPOT
$mkbot->cmd('!Hotspot|?hotspot|/hotspot|/Hotspot|!Hotspot', function ($user, $telo) {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');

   include('../config/system.conn.php');

   if ($idtelegram == $id_own) {
      $API = new routeros_api();

      if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
         if ($user == 'aktif') {
            if ($telo != "") {
               $pepaya = $API->comm("/ip/hotspot/active/print", ["?server" => "" . $telo . ""]);
               $anggur = count($pepaya);
               $apel   = $API->comm("/ip/hotspot/active/print", ["count-only" => "", "?server" => "" . $telo . ""]);
            } else {
               $pepaya = $API->comm("/ip/hotspot/active/print");
               $anggur = count($pepaya);
               $apel   = $API->comm("/ip/hotspot/active/print", ["count-only" => "",]);
            }

            $text .= "User Aktif $apel item\n\n";

            for ($i = 0; $i < $anggur; $i++) {
               $mangga    = $pepaya[$i];
               $id        = $mangga['.id'];
               $server    = $mangga['server'];
               $user      = $mangga['user'];
               $address   = $mangga['address'];
               $mac       = $mangga['mac-address'];
               $uptime    = $mangga['uptime'];
               $usesstime = $mangga['session-time-left'];
               $bytesi    = formatBytes($mangga['bytes-in'], 2);
               $byteso    = formatBytes($mangga['bytes-out'], 2);
               $loginby   = $mangga['login-by'];
               $comment   = $mangga['comment'];
               $text .= "";
               $text .= "👤 User aktif\n";
               $text .= "┠ ID :$id\n";
               $text .= "┠ User  : $user\n";
               $text .= "┠ IP    : $address\n";
               $text .= "┠ Uptime : $uptime\n";
               $text .= "┠ Byte IN      : $bytesi\n";
               $text .= "┠ Byte OUT   : $byteso\n";
               $text .= "┠ Sesion  : $usesstime\n";
               $text .= "┗ Login    : $loginby\n \n";
               $text .= "/see_$server\n \n";
            }

            $arr2       = str_split($text, 4000);
            $amount_gen = count($arr2);

            for ($i = 0; $i < $amount_gen; $i++) {
               $texta = $arr2[$i];
               Bot::sendMessage($texta);
            }
         } elseif ($user == 'user') {
            $ARRAY = $API->comm("/ip/hotspot/user/print");
            $num   = count($ARRAY);
            $text  = "Total $num User\n\n";

            for ($i = 0; $i < $num; $i++) {
               $no     = $i;
               $data   = $ARRAY[$i]['.id'];
               $dataid = str_replace('*', 'id', $data);
               $server = $ARRAY[$i]['server'];
               $name   = $ARRAY[$i]['name'];
               $data3  = $ARRAY[$i]['password'];
               $data4  = $ARRAY[$i]['mac-address'];
               $data5  = $ARRAY[$i]['profile'];
               $data6  = $ARRAY[$i]['limit-uptime'];
               $text .= "";
               $text .= "👥  ($dataid)\n";
               $text .= "┣Nama : $name\n";
               $text .= "┣password : $data3 \n";
               $text .= "┣mac : $data4\n";
               $text .= "┣Profil : $data5\n\n";
               $text .= "┗RemoveNow User /rEm0v$dataid\n\n";
            }

            $arr2       = str_split($text, 4000);
            $amount_gen = count($arr2);

            for ($i = 0; $i < $amount_gen; $i++) {
               $texta = $arr2[$i];

               Bot::sendMessage($texta);
            }
         } else {
            $text .= "";
            $text = "User list or aktif\n";
            $text .= "Filter by server\n";
            $serverhot = $API->comm('/ip/hotspot/print');

            foreach ($serverhot as $index => $jambu) {
               $sapubasah      = str_replace('-', '0', $jambu['name']);
               $sapubasahbasah = str_replace(' ', '11', $sapubasah);

               $text .= "/see_" . $sapubasahbasah . "\n";
            }

            $keyboard    = [['!Hotspot user', '!Hotspot aktif'], ['!Menu', '!Help'], ['!Hide'],];
            $replyMarkup = ['keyboard' => $keyboard, 'resize_keyboard' => true, 'one_time_keyboard' => true, 'selective' => true];
            $options     = [
               'reply' => true,
               'reply_markup' => json_encode($replyMarkup),
            ];
            Bot::sendMessage($text, $options);
         }
      } else {
         $text    = "Tidak dapat Terhubung dengan Mikrotik Coba Kembali";
         $options = [
            'reply' => true,
         ];
         Bot::sendMessage($text, $options);
      }
   } else {
      $denid = "Maaf..! Aksess Hanya untuk Administator";
      Bot::sendMessage($denid);
   }
});
//---------------------------  

/*
VERSI 3.2 MITHA
   - sistem master dealer
   - delete voucher via winbox, akan dikroscek dengan mikbotam (jika belum ada data keterangan dipakai maka akan dihapus yang dimikbotam) masih dipertimbangkan
   - PPPoE dengan fitur durasi dan FUP
   - tombol cetak ulang (dompdf lib)
   - warning telegram ketika ada yang online
   - payment gateway
   - queue selalu diletakkan di nomor 0
   

VERSI 3.1 MITHA
   - remake template generate voucher menggunakan template mikhmon dan turunannya [done]
   - tambah keyboard menu [done]
   - transfer saldo antar reseller [done]
   - omset bulan lalu dan bulan sekarang [done]
   - hilangkan omset all time [done]
   - grouping reseller dan voucher [done]
   - voucher generate tertulis (laku brp/total brp) [done]
   - top up instant via /deposit [done]
   - rekap omset di sisi reseller => bulanan dan harian [done]
            - omset hari ini
            - omset bulan ini
            - omset bulan lalu
            - vc telegram terjual hari ini
            - vc telegram terjual bulan ini
            - vc telegram terjual bulan lalu
            - vc generate hari ini
            - vc generate bulan ini
            - vc generate bulan lalu
            - sisa saldo
   - rekap owner tentang detail reseller [done]
   - tombol delete rekap setelah 3 bulan, 1 bulan [done]
   - template di cek ulang, terutama variable yang terkait dengan template mikhmon [done]
   - edit new user add supaya lebih rapih dan sesuai menu [done]
   - reseller list di web, remake, ambil datanya dll, omset bulan ini/bulan lalu, vcr telegram bulan ini/blnlalu, vcr fisik bulan ini/blnlalu [done]
   - profile ada fitur FUP [done]
   - interval schedule di kasih gap lebih lega [done]
   
  
VERSI 3.0 reborn (rumahpetir => M.I.T.H.Assistant)
   - cetak massal (jumlah banyak)
   - cetak voucher dengan nama khusus
   - remake dashboard
   - diskon reseller
   - notif via telegram atas penggunaan voucher ke reseller
   - hapus section edit core.php
   
VERSI 2.7 (rumahpetir)
   - revisi VOUCHER masih banyak bug [done]
   - menu radio (QRcode / logo / disable) [done]
   - bot kirim pesan ke reseller secara massal [done]
   - bot cek laporan dari tanggal tertentu sampe tanggal tertentu [done]
   - prefix voucher bot [done]
   - remake tampilan voucher sukses [done]
   - tombol reseller hapus history dan voucher [done]
   - bot display reseller info [done]
   - memperpanjang display (defaultnya separo layar) [done]
   - revisi voucher setelah masa aktif berakhir [done]
   - menu json diatas : info versi dan newversion [done]
  

VERSI 2.6 (rumahpetir)
   - delete nonsaldo
   - perampingan user profile on login script
   - unlimited voucher list
   - remake voucher setting and edit
   - edit core.php untuk menyesuaikan voucher baru
   - fitur edit untuk ucapan / aksesoris di bot
   - maximal topup via bot menjadi 9.999.999
   - menghapus drop down opsi di tools > edit bot core

   
   - menu daftar
   - menu generate voucher (header dan footer hotspot)
   - menu start
   
   


Versi 2.5 (rumahpetir)
26 Februari 2020 (rumahpetir) v2.5.1 
   - bug fix delete active user
   - char length default set 5
   
25 Februari 2020 (rumahpetir) v2.5 
   - menambah fitur EDIT User Profile
   
23 Februari 2020 (rumahpetir) v2.5 
   - hapus PPP

18 Februari 2020 (rumahpetir) v2.5 
   - menambah style di header
   - mengubah Duration format di add profile hotspot
   - mengembangkan halaman profile list
   - menambah script di mikbotamGreenUI.js
   
17 Februari 2020 (rumahpetir) v2.5 
   - menambah halaman profile_list
   - menyesuaikan profile_list
   
15 Februari 2020 (rumahpetir) v2.5 
   - mengubah alert login mikbotam

13 Februari 2020 (rumahpetir) v2.5 
   - tambah menu di USER PROFILE HOTSPOT
   - tambah fitur pilihan auto delete voucher jika sudah berakhir
   - tambah fitur pilihan notif via telegram ketika pertama kali voucher digunakan
     (fitur ditambahkan di file add_profile.php)
   - edit limit uptime di voucher dari null menjadi default 0
   - hapus GoCostumer
   - hapus Voucher Non Saldo
   - hapus SMS Gateway
   - menambah menu change log

05 Februari 2020 (rumahpetir) v2.3
   - hapus /qrcode
   
28 Januari 2020 (rumahpetir) v2.3
   - create botplusplus.php file
   - create functions.php file
   - create folder rpt
   - move some codes to new files

27 Januari 2020 (rumahpetir) v2.2.2
   - update daily report via telegram
   - update monthly report via telegram
   - add /cekuser, /reseller, and new command to /help

24 Januari 2020 (rumahpetir) v2.2.1 
   - update check voucher

02 Januari 2020 (rumahpetir) v2.2
   - Add reseller list to bot

19 November 2019 (rumahpetir) v2.1
   - Add delete button on history user

2 November 2019 (rumahpetir) v2.0
   - Add Check Voucher Expired page
   - Add command /cekvcr
*/
