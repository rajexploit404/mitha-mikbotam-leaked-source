<?php

//=====================================================START====================//

/*
	 *  Base Code   : BangAchil
	 *  Email       : kesumaerlangga@gmail.com
	 *  Telegram    : @bangachil
	 *
	 *  Name        : Mikrotik bot telegram - php
	 *  Function    : Mikortik api
	 *  Manufacture : November 2018
	 *  Last Edited : 26 Desember 2019
	 *
	 *  Please do not change this code
	 *  All damage caused by editing we will not be responsible please think carefully,
	 *
	 */

//=====================================================START SCRIPT====================//

error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
	header("Location:../admin/login.php");
} else {
	include '../config/system.conn.php';
	include '../config/system.byte.php';
	include '../Api/routeros_api.class.php';
	$datavoucher = sethistory($id);
	date_default_timezone_set('Asia/Jakarta');
	$API = new routeros_api();

	if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
		$konek 		   = "ya";
		$IDENTITY      = $API->comm('/system/identity/getall');
		$routername    = $IDENTITY['0']['name'];
		$health        = $API->comm("/system/health/print");
		$dhealth       = $health['0'];
		$ARRAY         = $API->comm("/system/resource/print");
		$first         = $ARRAY['0'];
		$memperc       = ($first['free-memory'] / $first['total-memory']);
		$hddperc       = ($first['free-hdd-space'] / $first['total-hdd-space']);
		$mem           = ($memperc * 100);
		$hdd           = ($hddperc * 100);
		$sehat         = $dhealth['temperature'];
		$platform      = $first['platform'];
		$board         = $first['board-name'];
		$version       = $first['version'];
		$architecture  = $first['architecture-name'];
		$cpu           = $first['cpu'];
		$cpuload       = $first['cpu-load'];
		$uptime        = $first['uptime'];
		$cpufreq       = $first['cpu-frequency'];
		$cpucount      = $first['cpu-count'];
		$memory        = formatBytes($first['total-memory']);
		$fremem        = formatBytes($first['free-memory']);
		$mempersen     = number_format($mem, 3);
		$hdd           = formatBytes($first['total-hdd-space']);
		$frehdd        = formatBytes($first['free-hdd-space']);
		$hddpersen     = number_format($hdd, 3);
		$sector        = $first['write-sect-total'];
		$setelahreboot = $first['write-sect-since-reboot'];
		$kerusakan     = $first['bad-blocks'];
		//====buat graphnya
		$API->write('/interface/getall');
		$ARRAY2 = $API->read();
	} else {
		$konek 	   = "no";
	}
}

?>


<script src="../lib/highchart/highcharts.js"></script>
<style type="text/css"></style>

<script type="text/javascript">
	var timer;

	var auto_refresh = setInterval(function() {
		$(".user-online")["load"]("../Graph/Getactive.php?Online")["fadeIn"]("fast");
		$(".cpu-load")["load"]("../Graph/Getactive.php?cpu")["fadeIn"]("fast");
		$(".free-memory")["load"]("../Graph/Getactive.php?free-memory")["fadeIn"]("fast");
		$(".up-time")["load"]("../Graph/Getactive.php?uptime")["fadeIn"]("fast");
		$(".ap-online")["load"]("../Graph/Getactive.php?aponline")["fadeIn"]("fast");
		$(".clock")["load"]("../Graph/Getactive.php?Clock")["fadeIn"]("fast");
	}, 5000)
</script>
<div class="sl-pagebody">
	<!-- bikin 4 card teratas -->
	<div class="row row-sm">
		<!-- col mikrotik -->
		<div class="col-sm-6 col-xl-3 mg-t-10 mg-sm-t-0">
			<div class="card pd-20 pd-sm-10 border-dark h-100 bg-info ">
				<div class="mg-l-15 text-white">
					<div class="text-center card-header tx-20 tx-spacing-1 bg-info"><strong>MIKROTIK STATUS</div></strong><br>
					<span class="tx-14"><strong>User Online : <span class="user-online">Loading..</span></span></strong><br>
					<span class="tx-14"><strong>CPU load : <span class="cpu-load">Loading..</span></span></strong><br>
					<span class="tx-14"><strong>Free RAM : <span class="free-memory">Loading..</span> / <?php echo $memory ?></span></strong><br>
					<span class="tx-14"><strong>Uptime : <span class="up-time">Loading..</span></span></strong><br>
					<span class="tx-14"><strong>RB Clock : <span class="clock">Loading..</span></span></strong><br>
					<span class="tx-14"><strong>Version : <?php echo $version ?></span></strong><br>
					<span class="tx-14"><strong>Model : <?php echo $architecture ?></span></strong><br>
				</div>
			</div>
		</div>
		<!-- col voucher -->
		<div class="col-sm-6 col-xl-3 mg-t-10 mg-sm-t-0">
			<div class="card pd-20 pd-sm-10 border-dark bg-success h-100">
				<div class="mg-l-15 text-white">
					<div class="text-center card-header tx-20 tx-spacing-1 bg-success"><strong>VOUCHER INFO</div></strong><br>
					<span class="tx-18 tx-spacing-1 tx-gray-500"><strong>from telegram</span></strong><br>
					<span class="tx-15">This month : <?= countvoucher(); ?> Vouchers</span><br>
					<span class="tx-15">Last month : <?= jmlvcteleblnlalu(); ?> Vouchers</span><br><br>
					<span class="tx-18 tx-spacing-1 tx-gray-500"><strong>from generate</span></strong><br>
					<span class="tx-15">This month : <?= countvouchergen(); ?> Vouchers</span><br>
					<span class="tx-15">Last month : <?= countvouchergenall(); ?> Vouchers</span></br>

				</div>
			</div>
		</div>
		<!-- col income -->
		<div class="col-sm-6 col-xl-3 mg-t-10 mg-xl-t-0">
			<div class="card pd-20 pd-sm-10 border-dark bg-warning h-100">
				<div class="mg-l-15 text-white">
					<div class="text-center card-header tx-20 tx-spacing-1 bg-warning"><strong>INCOME</div></strong><br>
					<span class="tx-18 tx-spacing-1 tx-gray-500"><strong>from telegram</span></strong><br>
					<span class="">This month : <?= rupiah(estimasidata());; ?> </span><br>
					<span class="">Last month : <?= rupiah(omsetvcteleblnlalu()); ?></span><br><br>
					<span class="tx-18 tx-spacing-1 tx-gray-500"><strong>from generate</span></strong><br>
					<span class="">This month : <?= rupiah(estimasidatagen()); ?></span><br>
					<span class="">Last month : <?= rupiah(omsetvcfisikblnlalu()); ?></span><br><br>
				</div>
			</div>
		</div>
		<!-- col deposit -->
		<div class="col-sm-6 col-xl-3 mg-t-10 mg-xl-t-0">
			<div class="card pd-20 pd-sm-10 border-dark bg-secondary h-100">
				<div class="mg-l-10">
					<div class="text-center card-header tx-20 tx-spacing-1 bg-secondary"><strong>DEPOSIT USERS</div></strong><br>
					<span class="">This month : </span><br>
					<h6><?= rupiah(getcounttopup());; ?> </h6><br>
					<span class="">Last month : </span><br>
					<h6><?= rupiah(deporesblnlalu()); ?></h6><br><br>
				</div>
			</div>
		</div>
	</div>

	<!-- end 4 card teratas -->


	<!-- baris 2 card-->
	<div class="row row-sm mg-t-10-force">
		<!-- card kolom 1 isi trafik-->
		<div class=" col-sm-6 mg-t-10 mg-xl-t-0">
			<div class="card bg-info col-sm mg-t-10 mg-xl-t-0 h-100">
				<div class="mg-l-10">
					<div class="card-header bg-info tx-white text-center tx-20 tx-spacing-1"><strong>TRAFFIC MONITORING</strong>
					</div>
					<div class="card-body">
						<div class="col-sm mg-b-10 mg-sm-t-0 center">
							<select class="form-control select2id" id="interface" name="interface" data-placeholder="Select interface">
								<?php
								foreach ($ARRAY2 as $ARRAY1 => $jengkol) : ?>
									<option value="<?= $jengkol['name']; ?>"><?php echo $jengkol['name']; ?></option>
								<?php endforeach; ?>
							</select>
						</div>

						<script type="text/javascript">
							var chart;

							function requestDatta(interface) {

								if (interface.length == 0) {

								} else {

									$.ajax({
										url: '../Graph/Graph.php?interface=' + interface,
										datatype: "json",
										success: function(data) {
											var midata = JSON.parse(data);
											if (midata.length > 0) {
												var TX = parseInt(midata[0].data);
												var RX = parseInt(midata[1].data);
												var x = (new Date()).getTime();
												shift = chart.series[0].data.length > 19;
												chart.series[0].addPoint([x, TX], true, shift);
												chart.series[1].addPoint([x, RX], true, shift);
											}
										},
										error: function(XMLHttpRequest, textStatus, errorThrown) {
											console.error("Status: " + textStatus + " request: " + XMLHttpRequest);
											console.error("Error: " + errorThrown);
										}
									});
								}
							}

							$(document).ready(function() {

								Highcharts.theme = {
									colors: ["#008080", "#f86c6b"],
									xAxis: {
										gridLineColor: '#c1c1c1',
										gridLineWidth: 1,
										labels: {
											style: {
												color: '#3E3E3E'
											}
										},

										lineColor: '#c1c1c1',
										tickColor: '#c1c1c1',
										title: {
											style: {
												color: '#3E3E3E',
												fontWeight: 'bold',
												fontSize: '12px',
												fontFamily: 'bold 16px "Trebuchet MS", Verdana, sans-serif, Roboto,"Seggoe UI"'

											}
										}
									},
									yAxis: {
										gridLineColor: '#c1c1c1',
										labels: {
											style: {
												color: '#3E3E3E'
											}
										},
										lineColor: '#c1c1c1',
										minorTickInterval: null,
										tickColor: '#c1c1c1',
										tickWidth: 1,
										title: {
											style: {
												color: '#3E3E3E',
												fontWeight: 'bold',
												fontSize: '12px',
												fontFamily: 'bold 16px "Trebuchet MS", Verdana, sans-serif, Roboto,"Seggoe UI"'
											}
										}
									},
									plotOptions: {
										series: {
											fillOpacity: 0.1
										}
									},
									tooltip: {
										backgroundColor: null,
										borderWidth: 0,
										shadow: false,
										useHTML: true,
										style: {
											padding: 0
										}

									},
									legend: {
										itemStyle: {
											font: '9pt Trebuchet MS, Verdana, sans-serif',
											color: '#3E3E3E'
										},
										itemHoverStyle: {
											color: '#20a8d8'
										},
										itemHiddenStyle: {
											color: '#E9EBEE'
										}
									},
									credits: {
										enabled: 0,
									}
								};

								var highchartsOptions = Highcharts.setOptions(Highcharts.theme);

								Highcharts.setOptions({
									global: {
										useUTC: false
									},
								});

								var namerouter = '<?= $Name_router; ?>';

								chart = new Highcharts.Chart({

									chart: {
										renderTo: 'graphmikbotam',
										animation: Highcharts.svg,
										type: 'areaspline',
										events: {
											load: function() {
												setInterval(function() {
													requestDatta(document.getElementById("interface").value);
													chart.setTitle({
														text: namerouter
													});
												}, 5000);
											}
										}
									},
									title: {
										text: namerouter
									},
									subtitle: {
										text: '',
										style: {
											display: 'none'
										}
									},

									xAxis: {
										type: 'datetime',
										tickPixelInterval: 150,
										maxZoom: 20 * 1000,
									},
									yAxis: {
										minPadding: 0,
										maxPadding: 0,
										title: {
											text: '',
											margin: 0
										},
										labels: {
											formatter: function() {
												var bytes = this.value;
												var sizes = ['bps', 'kbps', 'Mbps', 'Gbps', 'Tbps'];
												if (bytes == 0) return '0 bps';
												var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
												return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
											},
											style: {
												color: '#c1c1c1',
												fontSize: '11px',
												fontFamily: '"Trebuchet MS", Verdana, sans-serif, Roboto,"Seggoe UI"'

											},
										},
									},
									tooltip: {
										formatter: function() {

											var _0xcd73 = ["y", "bps", "kbps", "Mbps", "Gbps", "Tbps", "0 bps", "log", "floor", "toFixed", "pow", " ", '<span style="color:', "color", '">.  </span> <b>', "name", "series", "</b>", ": ", "<hr>", '<div class="card-header bg-primary tx-white"><i class="fa fa-shield"></i>  ', "</div><center>", "</center>", "reduce", "points"];
											return this[_0xcd73[24]][_0xcd73[23]](function(_0x5456x1, _0x5456x2) {
												var _0x5456x3 = _0x5456x2[_0xcd73[0]];
												var _0x5456x4 = [_0xcd73[1], _0xcd73[2], _0xcd73[3], _0xcd73[4], _0xcd73[5]];
												if (_0x5456x3 == 0) {
													return _0xcd73[6]
												};
												var _0x5456x5 = parseInt(Math[_0xcd73[8]](Math[_0xcd73[7]](_0x5456x3) / Math[_0xcd73[7]](1024)));
												var _0x5456x6 = parseFloat((_0x5456x3 / Math[_0xcd73[10]](1024, _0x5456x5))[_0xcd73[9]](2)) + _0xcd73[11] + _0x5456x4[_0x5456x5];
												return _0x5456x1 + _0xcd73[12] + _0x5456x2[_0xcd73[13]] + _0xcd73[14] + _0x5456x2[_0xcd73[16]][_0xcd73[15]] + _0xcd73[17] + _0xcd73[18] + _0x5456x6 + _0xcd73[19]
											}, _0xcd73[20] + namerouter + _0xcd73[21] + formatDate(new Date()) + _0xcd73[22])

										},

										shared: true
									},

									plotOptions: {
										line: {
											marker: {
												enabled: false
											}
										}
									},
									series: [{
										name: 'Tx',
										data: [],
									}, {
										name: 'Rx',
										data: [],
									}]
								});
							});
						</script>

						<!-- menampilkan grafiknya -->
						<div id="graphmikbotam"></div>
						<!-- tutup div-->
					</div>
				</div>
			</div>
		</div>
		<!-- card voucher list -->
		<div class="col-sm-6 mg-t-10 mg-xl-t-0">
			<div class="card bd-primary">
				<div class="card-header bg-primary tx-white ">
					Transaksi dalam 1 bulan terkahir
				</div>
				<div class="card-body">
					<div class="table-wrapper">
						<table id="userhistory" class="table table-bordered table-dark">
							<thead>
								<tr>
									<th>No</th>
									<th>Reseller</th>
									<th>Kode Voc<br>Password</th>
									<th>Info Voc</th>
									<th>Waktu<br>Tanggal</th>
									<th>Keterangan</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$TotalReg = count($datavoucher);
								$no = 1;
								for ($i = 0; $i < $TotalReg; $i++) {
									$datas 				= $datavoucher[$i];
									$id_user 			= $datas['id_user'];
									$nama_seller 		= $datas['nama_seller'];
									$saldo_awal 		= $datas['saldo_awal'];
									$beli_voucher 		= $datas['beli_voucher'];
									$saldo_akhir 		= $datas['saldo_akhir'];
									$top_up 			= $datas['top_up'];
									$top_up_fromid 		= $datas['top_up_fromid'];
									$username_voucher 	= $datas['username_voucher'];
									$password_voucher 	= $datas['password_voucher'];
									$exp_voucher 		= $datas['exp_voucher'];
									$info_vc 			= $datas['penjualan'];
									$nominaltransfer	= $datas['bagi_saldo'];
									$idtransfer			= $datas['bagi_saldo_to_id'];
									$namatransfer		= lihatuser($idtransfer)['nama_seller'];

									if (!empty($info_vc)) {
										$pecahdata = explode("|", $info_vc);
										$info_vc_fin = "<span class='label label-info m-r-15 text-uppercase'>Start : " . $pecahdata[0] . " | " . $pecahdata[1] . "</span><br><br><span class='label label-danger m-r-15 text-uppercase'>Expired : " . $pecahdata[2] . " | " . $pecahdata[3] . "</span>";
									} else {
										$info_vc_fin = "belum terdata";
									}
									$keterangan = $datas['keterangan'];
									if ($keterangan == 'Success') {
										$ket = "<span class='label label-success m-r-15 text-uppercase'>SUCCESS  Voc $exp_voucher</span>";
										$tratas = '<tr class="table-primary">';
									} elseif ($keterangan == 'gagalprint') {
										$ket = "<span class='label label-danger m-r-15 text-uppercase'>INVALID PRINT </span>";
										$tratas = '<tr class="table-danger">';
									} elseif ($keterangan == 'generate') {
										$ket = "<span class='label label-success m-r-15 text-uppercase'>SUCCESS GENERATE </span>";
										$tratas = '<tr class="table-success">';
									} elseif ($keterangan == 'gagal') {
										$ket = "<span class='label label-danger m-r-15 text-uppercase'>INVALID SERVER</span>";
										$tratas = '<tr class="table-danger">';
									} elseif ($keterangan == 'transfer') {
										$ket = "<span class='label label-info m-r-15 text-uppercase'>TRANSFER ke $namatransfer ( $idtransfer ) <br><br>===> " . rupiah($nominaltransfer) . " </span>";
										$beli_voucher = $top_up;
									} else {
										$ket = "<span class='label label-info m-r-15 text-uppercase'>TOP UP " . rupiah($top_up) . " </span>";
										$beli_voucher = $top_up;
										$tratas = '<tr class="bg-default">';
									}
									if ($info_vc_fin == "belum terdata" && $keterangan == "Success") {
										$tratas = '<tr class="table-warning">';
									}
									if ($info_vc_fin == "belum terdata" && $keterangan == "generate") {
										$tratas = '<tr class="table-info">';
									}
									if ($keterangan == "Success" || $keterangan == 'generate') {
										$hargareseller = rupiah($beli_voucher);
									} else {
										$hargareseller = "-";
										$info_vc_fin = "-";
									}

									$Waktu = $datas['Waktu'];
									$Tanggal = $datas['Tanggal'];

									if ($keterangan == "generate" || $keterangan == "Success") {
										echo $tratas;
										echo "<td>" . $no . "</td>";
										echo "<td>" . $nama_seller . "</td>";
										echo "<td>" . $username_voucher . "<br>" . $password_voucher . "</td>";
										echo "<td>" . $info_vc_fin . "</td>";
										echo "<td>" . $Waktu . "<br>" . $Tanggal . "</td>";
										echo "<td>" . $ket . "<br><br>Harga vcr : " . $hargareseller . "</td>";
										echo "</tr>";
										$no = $no + 1;
									} else if ($keterangan == "topup") {

										echo $tratas;
										echo "<td>" . $no . "</td>";
										echo "<td>" . $nama_seller . "</td>";
										echo "<td>-</td>";
										echo "<td>-</td>";
										echo "<td>" . $Waktu . "<br>" . $Tanggal . "</td>";
										echo "<td>" . $ket . "</td>";
										echo "</tr>";
										$no = $no + 1;
									} else if ($keterangan == "transfer") {

										echo $tratas;
										echo "<td>" . $no . "</td>";
										echo "<td>" . $nama_seller . "</td>";
										echo "<td>" . $username_voucher . "<br>" . $password_voucher . "</td>";
										echo "<td>" . $info_vc_fin . "</td>";
										echo "<td>" . $Waktu . "<br>" . $Tanggal . "</td>";
										echo "<td>" . $ket . "</td>";
										echo "</tr>";
										$no = $no + 1;
									}
								}

								?>
							</tbody>
						</table>
					</div>
				</div>
				<!-- card-body -->
			</div>

		</div>

	</div>