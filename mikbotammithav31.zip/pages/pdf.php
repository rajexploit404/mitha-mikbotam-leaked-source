<?php 
function bikinpdf ($username,$password,$namahotspot,$harga,$paket,$dns,$ket,$jmlvc,$siggy) {
require('fpdf.php');

$pdfnya = new FPDF('P','mm','A4');

$pdfnya->SetMargins(5,5);
$pdfnya->SetAutoPageBreak(true,5);

$pdfnya->AddPage();

$pdfnya->SetFont('Arial','',10);

$barisnya = 0;

for ($i=0; $i<$jmlvc; $i=$i+4) {

    $barisnya = $barisnya+1;

    // if ($i%36 == 0 && $i!=0 ) {

       
    //     $pdfnya->AddPage();
             

    // }

    
    if (($i+3) < $jmlvc) {

        $empat = 4;
    } else if (($i+2) < $jmlvc) {

        $empat = 3;
    } else if (($i+1) < $jmlvc) {

        $empat = 2;
    } else if ($i < $jmlvc) {

        $empat = 1;
    }



    for($s=0+$i; $s<($i+$empat); $s++) {

        $pdfnya->SetFont('Arial','',10);
        $pdfnya->Cell(41,5,$namahotspot,1,0,'C');
        $pdfnya->SetFont('Arial','',8);
        $pdfnya->Cell(7,5,$s+1,1,0,'C');
        $pdfnya->SetFont('Arial','',10);
        $pdfnya->Cell(2,5,'',0,0);

    }

    $pdfnya->Ln();

    for($s=0+$i; $s<($i+$empat); $s++) {

        $pdfnya->Cell(9,5,'user',"LBR",0,'C');
        $pdfnya->SetFont('Arial','B',10);
        $pdfnya->Cell(39,5,$username[$s],"LBR",0,'C');
        $pdfnya->Cell(2,5,'',0,0);
        $pdfnya->SetFont('Arial','',10);

    }

    $pdfnya->Ln();
    

    for($s=0+$i; $s<($i+$empat); $s++) {

        $pdfnya->Cell(9,5,'pass',"LBR",0,'C');
        $pdfnya->SetFont('Arial','B',10);
        $pdfnya->Cell(39,5,$password[$s],"LBR",0,'C');
        $pdfnya->Cell(2,5,'',0,0);
        $pdfnya->SetFont('Arial','',10);

    }

    $pdfnya->Ln();
    $pdfnya->SetFont('Arial','',8);

    for($s=0+$i; $s<($i+$empat); $s++) {

        $pdfnya->Cell(24,5,$harga,1,0,'C');
        $pdfnya->Cell(24,5,$paket,1,0,'C');
        $pdfnya->Cell(2,5,'',0,0);

    }

    $pdfnya->Ln();

    for($s=0+$i; $s<($i+$empat); $s++) {

        $pdfnya->Cell(48,5,$dns,1,0,'C');
        $pdfnya->Cell(2,5,'',0,0);

    }

    $pdfnya->Ln();

    for($s=0+$i; $s<($i+$empat); $s++) {

        $pdfnya->Cell(48,5,$ket,1,0,'C');
        $pdfnya->Cell(2,5,'',0,0);

    }

    if ($barisnya%9==0) {

        $pdfnya->AddPage();
        

    } else {

        $pdfnya->Ln();
        $pdfnya->Cell(1,2,'',0,0);
        $pdfnya->Ln();

    }
    
}
//simpan di server
$pdfnya->Output('F','generate'.$siggy.'.pdf');
//kirim ke user
//$pdfnya->Output('D','generate'.$siggy.'.pdf');



}

?>