<?php

include 'pdf.php';
include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Saldo/rpt/functions.php';
include '../Api/routeros_api.class.php';

//hapus file pdf lama

$namafile = glob('generate*.pdf');

foreach ($namafile as $file) {
    unlink($file);
}


$API = new routeros_api();

if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {


    $domainnya = $_SERVER['HTTP_HOST'];
    $usernya = $API->comm('/ip/hotspot/user/getall');
    //===nama user hotspot dikumpulin jadi 1
    $namauser = "";
    foreach ($usernya as $index => $baris) :
        $namauser .= "|" . $baris['name'];
    endforeach;
    $namauser .= "|";

    $gn_jml     = $_POST['jml_vc'];
    $gn_res     = json_decode($_POST['reseller'], true)['nama_seller'];
    $gn_id      = json_decode($_POST['reseller'], true)['id_user'];
    $gn_dis     = $_POST['diskon'];
    $gn_jvc     = json_decode($_POST['voucherlist'], true)['Voucher'];
    $gn_prv     = $_POST['prefix_gn'];
    $gn_hrg     = $_POST['harga'];
    $gn_mku     = $_POST['markup'];
    $gn_lup     = $_POST['limit_uptime'];
    $gn_lqu     = toBytes($_POST['limit_quota']);
    $gn_srv     = $_POST['server'];
    $gn_pro     = $_POST['profile'];
    $gn_tyc     = $_POST['typechar'];
    $gn_tyl     = $_POST['typelogin'];
    $gn_len     = $_POST['len_char'];
    $waktuskr   = time();;

    $_POST = array();



    if ($gn_jml > 0) {
        //=====jika diskon diatas 0, maka data potongan yg digunakan adalah data diskon

        if ($gn_dis > 0) {

            $gn_mku = ($gn_hrg * $gn_dis) / 100;
        }

        $hargadiskon = $gn_hrg - $gn_mku;
        //==== generate vc nya

        $vcgn = "{";
        $psgn = "{";
        $vcdb = "";
        $psdb = "";

        for ($jmlvc = 0; $jmlvc < $gn_jml; $jmlvc++) {

            $produksi = make_string($gn_len, $gn_tyc);
            $pass = make_string($gn_len, $gn_tyc);
            $produksi = $gn_prv . $produksi;

            if (preg_match("|" . $produksi . "|", $namauser) || preg_match("\"" . $produksi . "\"", $vcgn)) {
                $jmlvc = $jmlvc - 1;
            } else {
                $vcgn .= "\"" . $produksi . "\";";
                $psgn .= "\"" . $pass . "\";";
                $vcdb .= $produksi . "|";
                $psdb .= $pass . "|";
            }
        }
        //===== hasil setelah digenerate seluruhnya
        $vcgn = substr($vcgn, 0, -1);
        $vcgn .= "}";
        $psgn = substr($psgn, 0, -1);
        $psgn .= "}";
        $vcdb = substr($vcdb, 0, -1);
        $psdb = substr($psdb, 0, -1);


        //===== user = pass || user != pass
        if ($gn_tyl == "userpass") {

            $psgn = $vcgn;
            $psdb = $vcdb;
        }

        //==========masukkan ke mikrotik dan eksekusi


        $colokscript = $API->comm("/system/script/add", [
            "name" => $waktuskr,
            "source" => ':local ausr ' . $vcgn . ';:local apss ' . $psgn . '; for i from=0 to=([:len $ausr]-1) do={:local username ($ausr->$i);:local password ($apss->$i);/ip hotspot user add name="$username" password="$password" profile="' . $gn_pro . '" server="' . $gn_srv . '" limit-uptime="' . $gn_lup . '" limit-bytes-total="' . $gn_lqu . '" comment="| ID : ' . $gn_res . ' | voc : ' . $gn_jvc . ' (' . rupiah($gn_hrg) . ') | tgl : ' . date('d-m-Y') . ' | MIKBOTAM-AUTO GENERATE |";:delay 0.2s;};/system script remove [find name="' . $waktuskr . '"];',
            "comment" => "GENERATOR MIKBOTAM",
        ]);

        //=======bikin schedule running

        $bikinschedule = $API->comm("/system/schedule/add", [
            "name" => $waktuskr,
            "interval" => "00:00:10",
            "on-event" => ':local hitung [/system schedule get  [find name="' . $waktuskr . '"] run-count];if ($hitung = 1) do={/system script run "' . $waktuskr . '";};/system schedule remove [find name="' . $waktuskr . '"]',
            "comment" => "GENERATOR MIKBOTAM",
        ]);


        //=========simpan di database server

        $vcdb = explode("|", $vcdb);
        $psdb = explode("|", $psdb);

        for ($jmlvc = 0; $jmlvc < $gn_jml; $jmlvc++) {
            $simpankedb = generatevc($gn_id, $gn_res, $hargadiskon, $gn_mku, $vcdb[$jmlvc], $psdb[$jmlvc], $gn_pro, 'generate');
        }


        //bikinpdfnya
        bikinpdf($vcdb, $psdb, $identitiy, rupiah($gn_hrg), $gn_jvc, "http://" . $dnsname . "/", "Reseller : " . $gn_res, $gn_jml, $waktuskr);

        //kirim ke telegram owner


        $website = "https://api.telegram.org/bot" . $token;
        $params  = [
            'chat_id' => $id_own,
            'document' => 'https://' . $domainnya . '/pages/generate' . $waktuskr . '.pdf',
            'caption' => 'digenerate pada tanggal ' . date('d-m-Y') . "\njumlah voucher " . $gn_jml,
            'parse_mode' => 'html',
        ];
        $ch = curl_init($website . '/sendDocument');
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);

        // echo '<form method="get" action="generate'.$waktuskr.'.pdf">';
        // echo "<button type='submit'>Download</button>";

        echo '<meta http-equiv="refresh" content="0; url=https://' . $domainnya . '/pages/generate' . $waktuskr . '.pdf" />';
    }
} else {
    echo "MIKROTIK DISCONNECTED";
}
