<?php
//=====================================================START====================//

/*
 *  RUMAH PETIR v2.7
 *
 */

//=====================================================START SCRIPT====================//
error_reporting(0);
session_start();
if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {


    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Saldo/rpt/functions.php';
    include '../Api/routeros_api.class.php';




    $API = new routeros_api();

    if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {

        $seeprofile = $API->comm('/ip/hotspot/user/profile/print');
        $serverhot = $API->comm('/ip/hotspot/print');



        $id = $_SESSION['Mikbotamid'];

        //===ambil datanya vc
        $arrayvoc = getvoc($id);
        $textnya = json_decode($arrayvoc, true);

        //====ambil data reseller

        $arrayres = lihatdata();



        //===simpen datanya

    } else {
        echo '<script language="javascript">';
        echo 'document.addEventListener("DOMContentLoaded", function() {';
        echo 'alertify.alert("ERROR", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> MIKROTIK TIDAK TERHUBUNG </center>");';
        echo '});';
        echo '</script>';
    }
}
?>
<div class="sl-pagebody">
    <h1 class="tx-center">Generate Voucher</h1>
    <div class="row row-sm mg-t--1">
        <div class="col-xl-6 mg-t-10">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white">
                    <i class="fa  fa-paper-plane"></i> Generate Form
                </div>
                <div class="card-body pd-sm-15">
                    <form method="post" action="print.php" target="_blank">

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="1"> Jumlah Voucher : </label>
                            <div class="col-lg">
                                <input type="number" value="1" id="1" name="jml_vc" min="1" max="300" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; "> </input>
                            </div>
                        </div>
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="2">Reseller : </label>
                            <div class="col-lg">
                                <select onchange="myReseller()" class="form-control" id="2" name="reseller" data-placeholder="Pilih Voucher" style="margin-top: 0px; margin-bottom: 0px; height: 40px;">
                                    <option value="none">NONE</option>
                                    <?php foreach ($arrayres as $index => $baris) :
                                    ?>

                                        <option value='<?php echo json_encode($baris); ?>'><?php echo $baris['nama_seller']; ?></option>


                                    <?php endforeach; ?>


                                </select>
                            </div>
                        </div>
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="3">Diskon Reseller (%): </label>
                            <div class="col-lg">
                                <input type="number" value="0" id="3" name="diskon" maxlength="2" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                            </div>
                        </div>
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="4">Jenis Voucher : </label>
                            <div class="col-lg">
                                <select onchange="myVoucher()" class="form-control" id="4" name="voucherlist" data-placeholder="Pilih Voucher" style="margin-top: 0px; margin-bottom: 0px; height: 40px;">
                                    <option>choose ..</option>
                                    <?php foreach ($textnya as $index => $baris) :
                                    ?>

                                        <option value='<?php echo json_encode($baris); ?>'><?php echo $baris['Voucher']; ?></option>


                                    <?php endforeach; ?>



                                </select>
                            </div>
                        </div>
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="5">Prefix : </label>
                            <div class="col-lg">
                                <input value="" id="5" name="prefix_gn" maxlength="10" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="6">Harga End User (Rp): </label>
                            <div class="col-lg">
                                <input type="number" value="" id="6" name="harga" maxlength="10" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" required> </input>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="7">Mark up (Rp) : </label>
                            <div class="col-lg">
                                <input type="number" value="" id="7" name="markup" maxlength="10" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="8">Limit Uptime : </label>
                            <div class="col-lg">
                                <input value="" id="8" name="limit_uptime" maxlength="50" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="9">Limit Quota (Mb) : </label>
                            <div class="col-lg">
                                <input type="number" value="" id="9" name="limit_quota" maxlength="10" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;"> </input>
                            </div>
                        </div>


                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="10">Server : </label>
                            <div class="col-lg">
                                <select class="form-control" name="server" data-placeholder="Select Server  ">

                                    <option id="all" value="all">all</option>
                                    <?php foreach ($serverhot as $index => $jambu) : ?>
                                        <option id="<?= $jambu['name'];
                                                    ?>"><?php echo $jambu['name'];
                                                        ?></option>
                                    <?php endforeach;
                                    ?>

                                </select>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="11">Profile : </label>
                            <div class="col-lg">
                                <select class="form-control" name="profile" data-placeholder="Select Profile  ">

                                    <?php foreach ($seeprofile as $index => $kambing) : ?>
                                        <option id="<?= $kambing['name'];
                                                    ?>"><?php echo $kambing['name'];
                                                        ?></option>
                                    <?php endforeach;
                                    ?>

                                </select>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="12">Type Characters : </label>
                            <div class="col-lg">
                                <select id="karaktervoucher" class="form-control" name="typechar" data-placeholder="Select characters  ">

                                    <option id="1charvoc" value="1">1234</option>
                                    <option id="2charvoc" value="2">ABCDE</option>
                                    <option id="3charvoc" value="3">abcd</option>
                                    <option id="4charvoc" value="4">ABCDabcd</option>
                                    <option id="5charvoc" value="5">AbcdABCD1234</option>
                                    <option id="6charvoc" value="6">abcd1234</option>
                                    <option id="7charvoc" value="7">ABCD1234</option>
                                    <option id="checkCodecharvoc" value="checkCode">ABCDabcd1234</option>

                                </select>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="13">Type Login : </label>
                            <div class="col-lg">
                                <select class="form-control" name="typelogin" data-placeholder="Select type login  ">

                                    <option id="uptypelog" value="up">Username & Password</option>
                                    <option id="userpasstypelog" value="userpass">Username = Password</option>

                                </select>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="14">Length Character : </label>
                            <div class="col-lg">
                                <input type="number" min="5" value="" id="14" name="len_char" maxlength="2" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" required> </input>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="12">Jenis Template Print : </label>
                            <div class="col-lg">
                                <select id="printnya" class="form-control" name="printnya" data-placeholder="Select characters  ">

                                    <option value="default">default</option>
                                    <option value="tiny">tiny-default</option>


                                </select>
                            </div>
                        </div>

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead " for="12">QR CODE : </label>
                            <div class="col-lg">
                                <select id="qrcodenya" class="form-control" name="qrcodenya" data-placeholder="Select characters  ">

                                    <option value="yes">enable</option>
                                    <option value="no">disable</option>


                                </select>
                            </div>
                        </div>

                        <input type="hidden" name="id" value="<?= $id; ?>">

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead "></label>

                            <div class="col-lg">
                                <button type="submit" class="btn bg-primary tx-white" name="" onClick="return confirm('Process Now?');">GENERATE</button>
                                <button type="reset" class="btn btn-danger">Reset</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>

        </div>


        <div class="col-sm-4 mg-t-10">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white"> Petunjuk</div>
                <div class="card-body pd-sm-15">
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <p>
                                        <code>JUMLAH VOUCHER</code><br>
                                        tulis jumlah voucher yang akan di generate<br><br>
                                        <code>RESELLER</code><br>
                                        pilih reseller yang akan menjual voucher ini<br><br>
                                        <code>DISKON dan MARK UP</code><br>
                                        JIKA DISKON DIISI MAKA NILAI MARKUP DIABAIKAN<br><br>
                                        <code>JENIS VOUCHER</code><br>
                                        pilih jenis voucher yang akan digunakan, jika tidak ingin pakai jenis voucher yg tersedia, maka biarkan saja<br><br>
                                        <code>PREFIX</code><br>
                                        tulis prefix yang menjadi ciri khas voucher yg akan digenerate<br><br>
                                        <code>LAIN LAIN</code><br>
                                        semua data selanjutnya akan menyesuaikan jenis voucher yang dipilih, jika ingin mencetak tanpa menggunakan jenis voucher yang ada, maka silahkan isi semuanya secara manual<br><br>

                                    </p>



                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>


    <script>
        function myReseller() {
            var xaxa = document.getElementById("2").value;
            var data = JSON.parse(xaxa);
            document.getElementById("3").value = data['other'];
        }

        function myVoucher() {
            var xaxa = document.getElementById("4").value;
            var data = JSON.parse(xaxa);


            document.getElementById("5").value = data['prefix'];
            document.getElementById("6").value = data['price'];
            document.getElementById("7").value = data['markup'];
            document.getElementById("8").value = data['Limit'];
            document.getElementById("9").value = data['limit_total'];
            document.getElementById("14").value = data['length'];
            document.getElementById(data['profile']).selected = "true";
            document.getElementById(data['server']).selected = "true";
            document.getElementById(data['typechar'] + "charvoc").selected = "true";
            document.getElementById(data['type'] + "typelog").selected = "true";

        }
    </script>