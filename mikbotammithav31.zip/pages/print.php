<?php

include 'pdf.php';
include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Saldo/rpt/functions.php';
include '../Api/routeros_api.class.php';

//hapus file pdf lama

$namafile = glob('generate*.pdf');

foreach ($namafile as $file) {
    unlink($file);
}


$API = new routeros_api();

if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {


    $domainnya = $_SERVER['HTTP_HOST'];
    $usernya = $API->comm('/ip/hotspot/user/getall');
    //===nama user hotspot dikumpulin jadi 1
    $namauser = "";
    foreach ($usernya as $index => $baris) :
        $namauser .= "|" . $baris['name'];
    endforeach;
    $namauser .= "|";

    $gn_jml     = $_POST['jml_vc'];
    if ($_POST['reseller'] == "none") {
        $gn_id = $id_own;
        $gn_res = $owner;
    } else {
        $gn_res     = json_decode($_POST['reseller'], true)['nama_seller'];
        $gn_id      = json_decode($_POST['reseller'], true)['id_user'];
    }
    $gn_dis     = $_POST['diskon'];
    $gn_jvc     = json_decode($_POST['voucherlist'], true)['Voucher'];
    $gn_prv     = $_POST['prefix_gn'];
    $gn_hrg     = $_POST['harga'];
    $gn_mku     = $_POST['markup'];
    $gn_lup     = $_POST['limit_uptime'];
    $gn_lqu     = toBytes($_POST['limit_quota']);
    $gn_srv     = $_POST['server'];
    $gn_pro     = $_POST['profile'];
    $gn_tyc     = $_POST['typechar'];
    $gn_tyl     = $_POST['typelogin'];
    $gn_len     = $_POST['len_char'];
    $waktuskr   = time();
    $qr         = $_POST['qrcodenya'];
    $id         = $_POST['id'];
    $hotspotname = $Name_router;
    $gn_prn     = $_POST['printnya'];
    $getsprice   = $gn_hrg;


    //===ambil masa aktif di profile - validity
    $baris = $API->comm('/ip/hotspot/user/profile/print', ["?name" => $gn_pro,]);
    $dataonlogin = $baris[0]['on-login'];


    if (preg_match("/rmcde/i", $dataonlogin)) {

        $ambildata = explode("ut (\"", $dataonlogin);

        if (preg_match("/idtelegram/", $dataonlogin)) {

            $ambildata2 = explode("\");:local idtelegram (\"", $ambildata[1]);

            $durasi3 = $ambildata2[0];
        } else if (preg_match("/namaadmin/", $dataonlogin)) {

            $ambildata2 = explode("\");:local namaadmin (\"", $ambildata[1]);

            $durasi3 = $ambildata2[0];
        } else {
            $durasi3 = "";
        }
        //===ambil hari
        $hari1  = explode("d ", $durasi3);
        $hari2  = $hari1[0];
        if (empty($hari2) || $hari2 == "000" || $hari2 == "00" || $hari2 == "0") {
            $hari2 = "";
        } else {
            $hari2 = $hari2 . 'd ';
        }

        //===ambil jam
        $pecahwaktu = explode(":", $hari1[1]);
        $jam        = $pecahwaktu[0];
        $menit      = $pecahwaktu[1];
        $detik      = $pecahwaktu[2];

        if (empty($jam) || $jam == "00" || $jam == "0") {
            $jam = "";
        } else {
            $jam = $jam . 'h ';
        }
        if (empty($menit) || $menit == "00" || $menit == "0") {
            $menit = "";
        } else {
            $menit = $menit . 'm ';
        }
        if (empty($detik) || $detik == "00" || $detik == "0") {
            $detik = "";
        } else {
            $detik = $detik . 's ';
        }

        $validity = $hari2 .  $jam .  $menit . $detik;
    } else {

        $validity = "-";
    }


    //===cek jenis printnya

    if ($gn_prn == "tiny") {
        $small = "yes";
    }


    //===ambil data gambar
    $arraytext = ngambiltext($id);
    $gambar = json_decode($arraytext, true);
    $logo = $gambar['vc_url'];
    $logostatus = $gambar['vc_logo'];

    if ($logostatus == '3') {
        $logo = $logo;
    } else {
        $logo = 'https://www.rumahpetir.com/mitha.png';
    }

    //sesuaikan usermode agar bisa diprint, up = user dan pass, vc = voucher(user = pass)
    if ($gn_tyl == "up") {
        $usermode   = "up";
    } elseif ($gn_tyl == "userpass") {
        $usermode   = "vc";
    }

    $_POST = array();



    if ($gn_jml > 0) {
        //=====jika diskon diatas 0, maka data potongan yg digunakan adalah data diskon

        if ($gn_dis > 0) {

            $gn_mku = ($gn_hrg * $gn_dis) / 100;
        }

        $hargadiskon = $gn_hrg - $gn_mku;
        //==== generate vc nya

        $vcgn = "{";
        $psgn = "{";
        $vcdb = "";
        $psdb = "";

        for ($jmlvc = 0; $jmlvc < $gn_jml; $jmlvc++) {

            $produksi = make_string($gn_len, $gn_tyc);
            $pass = make_string($gn_len, $gn_tyc);
            $produksi = $gn_prv . $produksi;

            if (preg_match("|" . $produksi . "|", $namauser) || preg_match("\"" . $produksi . "\"", $vcgn)) {
                $jmlvc = $jmlvc - 1;
            } else {
                $vcgn .= "\"" . $produksi . "\";";
                $psgn .= "\"" . $pass . "\";";
                $vcdb .= $produksi . "|";
                $psdb .= $pass . "|";
            }
        }
        //===== hasil setelah digenerate seluruhnya
        $vcgn = substr($vcgn, 0, -1);
        $vcgn .= "}";
        $psgn = substr($psgn, 0, -1);
        $psgn .= "}";
        $vcdb = substr($vcdb, 0, -1);
        $psdb = substr($psdb, 0, -1);


        //===== user = pass || user != pass
        if ($gn_tyl == "userpass") {

            $psgn = $vcgn;
            $psdb = $vcdb;
        }

        //==========masukkan ke mikrotik dan eksekusi


        $colokscript = $API->comm("/system/script/add", [
            "name" => $waktuskr,
            "source" => ':local ausr ' . $vcgn . ';:local apss ' . $psgn . '; for i from=0 to=([:len $ausr]-1) do={:local username ($ausr->$i);:local password ($apss->$i);/ip hotspot user add name="$username" password="$password" profile="' . $gn_pro . '" server="' . $gn_srv . '" limit-uptime="' . $gn_lup . '" limit-bytes-total="' . $gn_lqu . '" comment="| ID : ' . $gn_res . ' | voc : ' . $gn_jvc . ' (' . rupiah($gn_hrg) . ') | tgl : ' . date('d-m-Y') . ' | MIKBOTAM-AUTO GENERATE |";:delay 0.2s;};/system script remove [find name="' . $waktuskr . '"];',
            "comment" => "GENERATOR MIKBOTAM",
        ]);

        //=======bikin schedule running

        $bikinschedule = $API->comm("/system/schedule/add", [
            "name" => $waktuskr,
            "interval" => "00:00:10",
            "on-event" => ':local hitung [/system schedule get  [find name="' . $waktuskr . '"] run-count];if ($hitung = 1) do={/system script run "' . $waktuskr . '";};/system schedule remove [find name="' . $waktuskr . '"]',
            "comment" => "GENERATOR MIKBOTAM",
        ]);


        //=========simpan di database server

        $vcdb = explode("|", $vcdb);
        $psdb = explode("|", $psdb);

        for ($jmlvc = 0; $jmlvc < $gn_jml; $jmlvc++) {
            $simpankedb = generatevc($gn_id, $gn_res, $hargadiskon, $gn_mku, $vcdb[$jmlvc], $psdb[$jmlvc], $gn_pro, 'generate');
        }


        //============================================cetak
?>
        <!DOCTYPE html>
        <html>

        <head>
            <title>Voucher-<?= $dnsname . "-" . $gn_jvc . "-" . rupiah($gn_hrg); ?></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <meta http-equiv="pragma" content="no-cache" />
            <link rel="icon" href="../img/favicon.png" />
            <script src="../js/qrious.min.js"></script>
            <style>
                body {
                    color: #000000;
                    background-color: #FFFFFF;
                    font-size: 14px;
                    font-family: 'Helvetica', arial, sans-serif;
                    margin: 0px;
                    -webkit-print-color-adjust: exact;
                }

                table.voucher {
                    display: inline-block;
                    border: 2px solid black;
                    margin: 2px;
                }

                @page {
                    size: auto;
                    margin-left: 7mm;
                    margin-right: 3mm;
                    margin-top: 9mm;
                    margin-bottom: 3mm;
                }

                @media print {
                    table {
                        page-break-after: auto
                    }

                    tr {
                        page-break-inside: avoid;
                        page-break-after: auto
                    }

                    td {
                        page-break-inside: avoid;
                        page-break-after: auto
                    }

                    thead {
                        display: table-header-group
                    }

                    tfoot {
                        display: table-footer-group
                    }
                }

                #num {
                    float: right;
                    display: inline-block;
                }

                .qrc {
                    width: 30px;
                    height: 30px;
                    margin-top: 1px;
                }
            </style>
        </head>

        <body onload="window.print()">

            <?php

            for ($i = 0; $i < $gn_jml; $i++) {;
                $regtable = $getuser[$i];
                $uid = str_replace("=", "", base64_encode($i));;
                $username = $vcdb[$i];
                $password = $psdb[$i];
                $profile = $gn_pro;
                $timelimit = $gn_lup;
                $getdatalimit = $gnlqu;
                $comment = ' | voc : ' . $gn_jvc . ' (' . rupiah($gn_hrg);
                if ($getdatalimit == 0) {
                    $datalimit = "";
                }
                $price = "(" . rupiah($gn_hrg) . ")";


                $urilogin = "http://$dnsname/login?username=$username&password=$password";
                $qrcode = "
	<canvas class='qrcode' id='" . $uid . "'></canvas>
    <script>
      (function() {
        var " . $uid . " = new QRious({
          element: document.getElementById('" . $uid . "'),
          value: '" . $urilogin . "',
          size:'256'
        });

      })();
    </script>
	";

                $num = $i + 1;
            ?>
                <?php
                if ($userp != "") {
                    include('./template-thermal.php');
                } else {
                    if ($small == "yes") {
                        include('./template-small.php');
                    } else {
                        include('./template.php');
                    }
                }
                ?>
            <?php
            } ?>

        </body>

        </html>

<?php
        //=============================================================================

        //kirim ke telegram owner


        // $website = "https://api.telegram.org/bot" . $token;
        // $params  = [
        //     'chat_id' => $id_own,
        //     'document' => 'https://' . $domainnya . '/pages/generate' . $waktuskr . '.pdf',
        //     'caption' => 'digenerate pada tanggal ' . date('d-m-Y') . "\njumlah voucher " . $gn_jml,
        //     'parse_mode' => 'html',
        // ];
        // $ch = curl_init($website . '/sendDocument');
        // curl_setopt($ch, CURLOPT_HEADER, false);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // curl_setopt($ch, CURLOPT_POST, 1);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
        // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        // $result = curl_exec($ch);
        // curl_close($ch);


        // echo '<meta http-equiv="refresh" content="0; url=https://' . $domainnya . '/pages/generate' . $waktuskr . '.pdf" />';
    }
} else {
    echo "MIKROTIK DISCONNECTED";
}
