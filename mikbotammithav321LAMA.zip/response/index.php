<?php
date_default_timezone_set('Asia/Jakarta');
if (!empty($_POST)) {
    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Api/routeros_api.class.php';
    $API = new routeros_api();

    $domainnya      = $_SERVER['HTTP_HOST'];
    $idprofile      = $_POST['idprofile'];
    $idsecret       = $_POST['idsecret'];
    $idschedule     = $_POST['idschedule'];
    $komenprof      = $_POST['commentprofile'];
    $komensecret    = $_POST['commentsecret'];

    /*
    logic script schedule, jika secret ada maka lakukan ini, jika secret tidak ada maka delete schedule ini
    data yang dikirim oleh schedule :
    - idprofile
    - idsecret
    - commentprofile
    - commentsecret
        - status : daftar | aktif | expired
    */
    //komensecret : | status : daftar | tgl-expired : 17 | jam-expired : 18:54 | eksekusi : pindah-profile(profile3) | idsecret : *13 | profile : mitha6 | PPPoE-MITHA-MIKBOTAM |
    //komenprofile : | tgl-expired : 26 | jam-expired : 21:19 | eksekusi : pindah-profile(profile1123) | idprofile : *A | price : 1500 | PPPoE-MITHA-MIKBOTAM |
    $pecahprof      = explode(" | ", $komenprof);
    $pecahsecret    = explode(" | ", $komensecret);
    //ambil hari ini
    $hariini        = strtotime("now");
    //status
    $status         = explode("status : ", $pecahsecret[0])[1];
    //tanggal
    $tanggal        = explode("tgl-expired : ", $pecahsecret[1])[1];
    //jam
    $jam            = explode("jam-expired : ", $pecahsecret[2])[1];
    //eksekusi
    $eksekusi       = explode("eksekusi : ", $pecahsecret[3])[1];
    $eksementah     = explode("(", $eksekusi);
    $jenisekse      = $eksementah[0];
    $proftuj        = explode(")", $eksementah[1])[0];
    //harga
    $harga          = explode("price : ", $pecahprof[4])[1];



    if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
        //nama secret
        $namasecret     = $API->comm("/ppp/secret/print", ["?.id" => $idsecret])[0]['name'];

        if ($status == "daftar") {
            $nextmonth  = strtotime("next Month", $hariini);
            $nextmonth2 = date("M/Y", $nextmonth);
            $pecahbln   = explode("/", $nextmonth2);
            $tglsch     = $pecahbln[0] . "/" . $tanggal . "/" . $pecahbln[1];
            $jamsch     = $jam . ":00";
            $komenbaru  = str_replace("status : daftar", "status : aktif", $komensecret);

            $setschedule = $API->comm('/system/schedule/set', [
                ".id" => $idschedule,
                "interval" => "00:10:00",
                "start-date" => $tglsch,
                "start-time" => $jamsch,
                "comment" => "script pppoe mitha mikbotam",
            ]);

            //komensecret : | status : daftar | tgl-expired : 17 | jam-expired : 18:54 | eksekusi : pindah-profile(profile3) | idsecret : *13 | profile : mitha6 | PPPoE-MITHA-MIKBOTAM |
            $setusersecret = $API->comm('/ppp/secret/set', [
                ".id" => $idsecret,
                "comment" => $komenbaru,
            ]);

            $pesannya = "akun pppoe $namasecret aktif";

            //masukin nominal harga di log agar tercatat, termasuk di (+ 1 bulan), dan (- 1 bulan)
            $inputdatabase = inputpppoe($harga, $namasecret);
        } else if ($status == "aktif") {
            $komenbaru  = str_replace("status : aktif", "status : expired", $komensecret);
            //hapus schedule
            $hapusschedule = $API->comm("/system/scheduler/remove", ['.id' => $idschedule]);
            //kick dari active connection
            $idactive = $API->comm("/ppp/active/print", ["?name" => $namasecret,])[0]['.id'];
            $kicksecret = $API->comm("/ppp/active/remove", ['.id' => $idactive]);
            //eksekusi
            if ($jenisekse == "disable") {
                //disable kan secret dan ganti comment
                $API->write("/ppp/secret/disable", false);
                $API->write("=.id=" . $idsecret);
                $API->read();
            } else if ($jenisekse == "pindah-profile") {
                $setprofile = $API->comm("/ppp/secret/set", [
                    ".id" => $idsecret,
                    "profile" => $proftuj,
                ]);
            }
            //ubah comment di secret
            $setusersecret = $API->comm('/ppp/secret/set', [
                ".id" => $idsecret,
                "comment" => $komenbaru,
            ]);
            $pesannya = "akun pppoe $namasecret expired";
        }
    } else {
        $pesannya = "koneksi mikrotik terganggu sehingga gagal proses akun pppoe $namaakunsecret, akan diproses 10 menit lagi";
    }

    $website = "https://api.telegram.org/bot" . $token;
    $params  = [
        'chat_id' => $id_own,
        'text' => $pesannya,
        'parse_mode' => 'html',
    ];
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
} else {
    echo "maintenance";
}
