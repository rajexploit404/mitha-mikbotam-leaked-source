<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2018
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);


include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Api/routeros_api.class.php';
$API = new routeros_api();

if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {;

    $id             = $_GET['id'];
    $getprofiledata = $API->comm("/ppp/profile/print", ["?.id" => $id])[0];

    //pecah comment
    $komenprofile   = explode(" | ", $getprofiledata['comment']);
    $tglexpprof     = explode("tgl-expired : ", $komenprofile[0])[1];
    $jamprof        = explode("jam-expired : ", $komenprofile[1])[1];
    $jamexpprof     = explode(":", $jamprof)[0];
    $mntexpprof     = explode(":", $jamprof)[1];
    $metodeedit     = explode("eksekusi : ", $komenprofile[2])[1];
    $prtujedit      = explode("(", $metodeedit);
    $metodefixedit  = $prtujedit[0];
    $proeditfix     = explode(")", $prtujedit[1])[0];
    $harga          = explode("price : ", $komenprofile[4])[1];

    $seeprofile     = $API->comm('/ppp/profile/print');
    $getallqueue    = $API->comm("/queue/simple/print", ["?dynamic" => "false",]);
    $poolnya        = $API->comm("/ip/pool/print");

?>

    <script type="text/javascript">
        var profile = '<?php foreach ($seeprofile as $index => $baris) : echo '<option value="' . $baris['name'] . '">' . $baris['name'] . '</option>';
                        endforeach; ?>';

        function pilihprofileedit(name) {

            if (name == 'pindah-profile') document.getElementById('pindahprofileedit').innerHTML = '<div class="row mg-t-8"><label class="col-sm-4 form-control-label align-self-center">Profile expired : </label><div class="col-sm-8 mg-t-10 mg-sm-t-0"> <select class="form-control select2id" style="width: 100%;" name="profileexpired" required><option value="<?= $proeditfix; ?>" selected><?= $proeditfix; ?></option>' + profile + '</select></div></div>';
            else document.getElementById('pindahprofileedit').innerHTML = '';
        }

        function pilihladdedit(name) {

            if (name == 'isimanual') document.getElementById('laddidedit').innerHTML = '<div class="row mg-t-8"><label class="col-sm-4 form-control-label align-self-center">Silahkan isi IP Local Add : </label><div class="col-sm-8 mg-t-10 mg-sm-t-0"><input type="text" name="laddip" class="form-control" required></div></div>';
            else document.getElementById('laddidedit').innerHTML = '';
        }

        function pilihraddedit(name) {

            if (name == 'isimanual') document.getElementById('raddidedit').innerHTML = '<div class="row mg-t-8"><label class="col-sm-4 form-control-label align-self-center">Silahkan isi IP Remote Add : </label><div class="col-sm-8 mg-t-10 mg-sm-t-0"><input type="text" name="raddip" class="form-control" required></div></div>';
            else document.getElementById('raddidedit').innerHTML = '';
        }
    </script>

    <div class="card bd bd-primary  ">
        <div class="card-body pd-sm-15">

            <form action="" method="post">
                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Profile Name : </label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <input type="text" name="name" class="form-control" value="<?= $getprofiledata['name']; ?>" required>
                    </div>
                </div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Harga : </label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <input type="number" name="harga" class="form-control" value="<?= $harga ?>" required>
                    </div>
                </div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Rate Limit [rx/tx] : </label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <input type="text" class="form-control" name="rate-limit" value="<?= $getprofiledata['rate-limit'] ?>" data-toggle="tooltip" data-placement="top" title="example 1M/512k, salah penulisan maka data tidak terinput" placeholder="1M/512k" required>
                    </div>
                </div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Only One : </label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <select class="form-control" name="onlyone" id="onlyone">
                            <option value="<?= $getprofiledata['only-one'] ?>" selected>"<?= $getprofiledata['only-one'] ?></option>
                            <option value="default">default</option>
                            <option value="yes" selected>yes</option>
                            <option value="no">no</option>
                        </select>
                    </div>
                </div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Parent Queue : </label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <select class="form-control" name="parent" data-toggle="tooltip" data-placement="top" title="Jika kosong pilih none">
                            <?php if (!empty($getprofiledata['parent-queue'])) { ?>
                                <option value="<?= $getprofiledata['parent-queue']; ?>" selected><?= $getprofiledata['parent-queue']; ?></option>
                            <?php } ?>
                            <option>none</option>
                            <?php foreach ($getallqueue as $index => $barisan) : ?>
                                <option value="<?= $barisan['name'] ?>"><?= $barisan['name'] ?></option>
                            <?php endforeach;
                            ?>
                        </select>
                    </div>
                </div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Local Address : </label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <select class="form-control" name="ladd" data-toggle="tooltip" data-placement="top" title="Jika kosong pilih none" onchange="pilihladdedit(this.options[this.selectedIndex].value)">
                            <?php if (!empty($getprofiledata['local-address'])) { ?>
                                <option value="<?= $getprofiledata['local-address'] ?>" selected><?= $getprofiledata['local-address'] ?></option>
                            <?php } ?>
                            <option>none</option>
                            <?php foreach ($poolnya as $index => $barisan) : ?>
                                <option value="<?= $barisan['name'] ?>"><?= $barisan['name'] ?></option>
                            <?php endforeach;
                            ?>
                            <option value="isimanual">isi manual</option>
                        </select>
                    </div>
                </div>

                <div id="laddidedit"></div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Remote Address : </label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <select class="form-control" name="radd" data-toggle="tooltip" data-placement="top" title="Jika kosong pilih none" onchange="pilihraddedit(this.options[this.selectedIndex].value)">
                            <?php if (!empty($getprofiledata['remote-address'])) { ?>
                                <option value="<?= $getprofiledata['remote-address'] ?>" selected><?= $getprofiledata['remote-address'] ?></option>
                            <?php } ?>
                            <option>none</option>
                            <?php foreach ($poolnya as $index => $barisan) : ?>
                                <option value="<?= $barisan['name'] ?>"><?= $barisan['name'] ?></option>
                            <?php endforeach;
                            ?>
                            <option value="isimanual">isi manual</option>
                        </select>
                    </div>
                </div>

                <div id="raddidedit"></div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Tanggal Jatuh Tempo :</label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <select class="form-control select2id" style="width: 30%;" name="tglexp" id="tglexp">
                            <option value="<?= $tglexpprof; ?>"><?= $tglexpprof; ?></option>
                            <?php for ($i = 01; $i < 29; $i++) {
                                $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                echo "<option value='$ii'>$ii</option>";
                            } ?>
                        </select>
                    </div>
                </div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Waktu Jatuh Tempo (JAM : MENIT) :</label>
                    <div class="form-inline col-sm-8 mg-t-10 mg-sm-t-0">
                        <select class="form-control select2id" style="width: 30%;" name="jamexp" id="jamexp">
                            <option value="<?= $jamexpprof; ?>"><?= $jamexpprof; ?></option>
                            <?php for ($i = 01; $i < 24; $i++) {
                                $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                echo "<option value='$ii'>$ii</option>";
                            } ?>
                        </select> &nbsp;:&nbsp;
                        <select class="form-control select2id" style="width: 30%;" name="mntexp" id="mntexp">
                            <option value="<?= $mntexpprof; ?>"><?= $mntexpprof; ?></option>
                            <?php for ($i = 00; $i < 60; $i++) {
                                $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                echo "<option value='$ii'>$ii</option>";
                            } ?>
                        </select>
                    </div>
                </div>

                <div class="row mg-t-8">
                    <label class="col-sm-4 form-control-label align-self-center">Eksekusi :</label>
                    <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                        <select class="form-control select2id" style="width: 100%;" name="eksekusi" id="eksekusi" onchange="pilihprofileedit(this.options[this.selectedIndex].value)">
                            <option value="disable" <?php if ($metodefixedit == "disable") {
                                                        echo "selected";
                                                    } ?>>disable</option>
                            <option value="pindah-profile" <?php if ($metodefixedit == "pindah-profile") {
                                                                echo "selected";
                                                            } ?>>pindah profile</option>
                        </select>
                    </div>
                </div>

                <?php if ($metodefixedit == 'pindah-profile') { ?>
                    <div id="pindahprofileedit">
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label align-self-center">Profile expired : </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <select class="form-control select2id" style="width: 100%;" name="profileexpired" required>
                                    <option value="">- choose -</option>
                                    <?php echo '<option value="' . $proeditfix . '" selected>' . $proeditfix . '</option>';
                                    foreach ($profiles as $index => $baris) : echo '<option value="' . $baris['name'] . '">' . $baris['name'] . '</option>';
                                    endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                <?php } else { ?>
                    <div id="pindahprofileedit"></div>
                <?php } ?>

                <div class="row row-xs mg-t-10">
                    <div class="col-sm-15 mg-l-auto">
                        <div class="form-layout-footer">
                            <button type="submit" class="btn bg-primary tx-white" name="saveprofileedit">Save changes</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="reset" class="btn btn-danger">Reset</button>
                        </div>
                        <!-- form-layout-footer -->
                    </div>
                    <!-- col-8 -->
                </div>

            </form>
        </div>
    </div>
<?php } ?>