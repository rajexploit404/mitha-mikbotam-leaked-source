<?php
//=====================================================START====================//

/*
 *  RUMAH PETIR v2.5
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:admin/login.php");
} else {
    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Api/routeros_api.class.php';
    $API = new routeros_api();
    $fp = @fsockopen($mikrotik_ip, $mikrotik_port, $errCode, $errStr, 1);

    if ($fp) {
        if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {

            $domainnya      = $_SERVER['HTTP_HOST'];

            //komenprofile | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(tenggat) | idprofile : *4 | price : 10000 | PPPoE-MITHA-MIKBOTAM |
            if (isset($_POST['saveprofile'])) {
                $namaprofile    = $_POST['name'];
                $hargaprofile   = $_POST['harga'];
                $ratelimitprof  = $_POST['rate-limit'];
                $onlyoneprof    = $_POST['onlyone'];
                $parentprof     = $_POST['parent'];
                $laddprof       = $_POST['ladd'];
                if ($laddprof == 'isimanual') {
                    $laddprof   = $_POST['laddip'];
                }
                $raddprof       = $_POST['radd'];
                if ($raddprof == 'isimanual') {
                    $raddprof   = $_POST['raddip'];
                }
                $tglexpprof     = $_POST['tglexp'];
                $jamexpprof     = $_POST['jamexp'];
                $mntexpprof     = $_POST['mntexp'];
                $ekseprof       = $_POST['eksekusi'];
                $profexp        = "";
                if ($ekseprof == 'pindah-profile') {
                    $profexp    = "(" . $_POST['profileexpired'] . ")";
                }

                //komenprofile : | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(profile1123) | idprofile : *4 | price : 100000 | PPPoE-MITHA-MIKBOTAM |
                //komensecret : | status : aktif | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(default) | idsecret : *4 | profile : profilemitha | PPPoE-MITHA-MIKBOTAM |
                /*
                alur :
                - user pertama kali login
                - schedule dibuat dengan isi
                    - apakah user masih ada di secret, jika tidak maka hapus schedule
                    - jika masih ada, maka kirim data post ke url fetch
                - sisanya biar dikerjakan oleh server

                */

                //script on up
                $onupprof = ':local nmprofil [/ppp secret get [find where name=$user] profile];:local usrid [:pick [/ppp secret get [find where name=$user]] 0];:local idprofil [:pick [/ppp profile get [find where name=$nmprofil]] 0];/sys sch add name="$user-ppp-mitha" interval="00:00:30" policy="read,write,test,password,sniff,sensitive,romon,api" comment="PPPoE-MITHA-MIKBOTAM" on-event=":if ([:len [/ppp secret find name=$user]]=0) do={/system schedule remove [find where name=\"$user-ppp-mitha\"];} else={:local idsche [:pick [/sys sch get [find where name=\"$user-ppp-mitha\"]] 0];:local komenprofile [/ppp profile get $idprofil comment];:local komensecret [/ppp secret get $usrid comment];/tool fetch url=\"https://' . $domainnya . '/response/\"  keep-result=no http-method=post http-data=\"idschedule=\$idsche&idprofile=$idprofil&idsecret=$usrid&commentprofile=\$komenprofile&commentsecret=\$komensecret\";}";';

                if (empty($raddprof) && empty($laddprof)) {
                    $add_prof     = $API->comm("/ppp/profile/add", [
                        "name" => $namaprofile,
                        "rate-limit" => $ratelimitprof,
                        "only-one" => $onlyoneprof,
                        "parent-queue" => $parentprof,
                        "on-up" => $onupprof,
                    ]);
                } else if (empty($laddprof)) {
                    $add_prof     = $API->comm("/ppp/profile/add", [
                        "name" => $namaprofile,
                        "rate-limit" => $ratelimitprof,
                        "only-one" => $onlyoneprof,
                        "parent-queue" => $parentprof,
                        "on-up" => $onupprof,
                        "remote-address" => $raddprof,
                    ]);
                } else if (empty($raddprof)) {
                    $add_prof     = $API->comm("/ppp/profile/add", [
                        "name" => $namaprofile,
                        "rate-limit" => $ratelimitprof,
                        "only-one" => $onlyoneprof,
                        "parent-queue" => $parentprof,
                        "on-up" => $onupprof,
                        "local-address" => $laddprof,
                    ]);
                } else {
                    $add_prof     = $API->comm("/ppp/profile/add", [
                        "name" => $namaprofile,
                        "rate-limit" => $ratelimitprof,
                        "only-one" => $onlyoneprof,
                        "parent-queue" => $parentprof,
                        "on-up" => $onupprof,
                        "remote-address" => $raddprof,
                        "local-address" => $laddprof,
                    ]);
                }
                $checkdata = json_encode($add_prof);
                if (strpos(strtolower($checkdata), '!trap')) {
                    echo '<script language="javascript">';
                    echo 'document.addEventListener("DOMContentLoaded", function() {';
                    echo 'alertify.alert("WARNING", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center>User PPP Already Exist </center>");';
                    echo '});';
                    echo '</script>';
                } else {
                    $datasecret = $API->comm("/ppp/profile/print", ["?name" => $namaprofile])[0]['.id'];
                    //komensecret : | status : daftar | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(tenggat) | idsecret : *4 | profile : profilemitha | PPPoE-MITHA-MIKBOTAM | 
                    $meracikkomen = "| tgl-expired : $tglexpprof | jam-expired : $jamexpprof:$mntexpprof | eksekusi : " . $ekseprof . $profexp . " | idprofile : $datasecret | price : $hargaprofile | PPPoE-MITHA-MIKBOTAM |";
                    $editkomensecret = $API->comm("/ppp/profile/set", [
                        ".id" => $datasecret,
                        "comment" => $meracikkomen,
                    ]);


                    echo '<script language="javascript">';
                    echo 'document.addEventListener("DOMContentLoaded", function() {';
                    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success Add User PPP  </center>");';
                    echo '});';
                    echo '</script>';
                }
            } else if (isset($_POST['saveprofileedit'])) {
                $namaprofile    = $_POST['name'];
                $hargaprofile   = $_POST['harga'];
                $ratelimitprof  = $_POST['rate-limit'];
                $onlyoneprof    = $_POST['onlyone'];
                $parentprof     = $_POST['parent'];
                $laddprof       = $_POST['ladd'];
                if ($laddprof == 'isimanual') {
                    $laddprof   = $_POST['laddip'];
                } else if ($laddprof == 'none') {
                    $laddprof = null;
                }
                $raddprof       = $_POST['radd'];
                if ($raddprof == 'isimanual') {
                    $raddprof   = $_POST['raddip'];
                } else if ($raddprof == 'none') {
                    $raddprof = null;
                }
                $tglexpprof     = $_POST['tglexp'];
                $jamexpprof     = $_POST['jamexp'];
                $mntexpprof     = $_POST['mntexp'];
                $ekseprof       = $_POST['eksekusi'];
                $profexp        = "";
                if ($ekseprof == 'pindah-profile') {
                    $profexp    = "(" . $_POST['profileexpired'] . ")";
                }

                //komenprofile : | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(profile1123) | idprofile : *4 | price : 100000 | PPPoE-MITHA-MIKBOTAM |
                //komensecret : | status : aktif | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(default) | idsecret : *4 | profile : profilemitha | PPPoE-MITHA-MIKBOTAM |
                /*
                alur :
                - user pertama kali login
                - schedule dibuat dengan isi
                    - apakah user masih ada di secret, jika tidak maka hapus schedule
                    - jika masih ada, maka kirim data post ke url fetch
                - sisanya biar dikerjakan oleh server

                */

                //script on up
                $onupprof = ':local nmprofil [/ppp secret get [find where name=$user] profile];:local usrid [:pick [/ppp secret get [find where name=$user]] 0];:local idprofil [:pick [/ppp profile get [find where name=$nmprofil]] 0];/sys sch add name="$user-ppp-mitha" interval="00:00:30" policy="read,write,test,password,sniff,sensitive,romon,api" comment="PPPoE-MITHA-MIKBOTAM" on-event=":if ([:len [/ppp secret find name=$user]]=0) do={/system schedule remove [find where name=\"$user-ppp-mitha\"];} else={:local idsche [:pick [/sys sch get [find where name=\"$user-ppp-mitha\"]] 0];:local komenprofile [/ppp profile get $idprofil comment];:local komensecret [/ppp secret get $usrid comment];/tool fetch url=\"https://' . $domainnya . '/response/\"  keep-result=no http-method=post http-data=\"idschedule=\$idsche&idprofile=$idprofil&idsecret=$usrid&commentprofile=\$komenprofile&commentsecret=\$komensecret\";}";';

                $idprofile = $API->comm("/ppp/profile/print", ["?name" => $namaprofile])[0]['.id'];

                $meracikkomen = "| tgl-expired : $tglexpprof | jam-expired : $jamexpprof:$mntexpprof | eksekusi : " . $ekseprof . $profexp . " | idprofile : $idprofile | price : $hargaprofile | PPPoE-MITHA-MIKBOTAM |";

                if (empty($raddprof) && empty($laddprof)) {
                    $add_prof     = $API->comm("/ppp/profile/set", [
                        ".id" => $idprofile,
                        "name" => $namaprofile,
                        "rate-limit" => $ratelimitprof,
                        "only-one" => $onlyoneprof,
                        "parent-queue" => $parentprof,
                        "on-up" => $onupprof,
                        "comment" => $meracikkomen,
                    ]);

                    $API->comm("/ppp/profile/unset", [
                        ".id" => $idprofile,
                        "value-name" => 'remote-address',
                    ]);

                    $API->comm("/ppp/profile/unset", [
                        ".id" => $idprofile,
                        "value-name" => 'local-address',
                    ]);
                } else if (empty($laddprof)) {
                    $add_prof     = $API->comm("/ppp/profile/set", [
                        ".id" => $idprofile,
                        "name" => $namaprofile,
                        "rate-limit" => $ratelimitprof,
                        "only-one" => $onlyoneprof,
                        "parent-queue" => $parentprof,
                        "on-up" => $onupprof,
                        "remote-address" => $raddprof,
                        "comment" => $meracikkomen,
                    ]);


                    $API->comm("/ppp/profile/unset", [
                        ".id" => $idprofile,
                        "value-name" => 'local-address',
                    ]);
                } else if (empty($raddprof)) {
                    $add_prof     = $API->comm("/ppp/profile/set", [
                        ".id" => $idprofile,
                        "name" => $namaprofile,
                        "rate-limit" => $ratelimitprof,
                        "only-one" => $onlyoneprof,
                        "parent-queue" => $parentprof,
                        "on-up" => $onupprof,
                        "local-address" => $laddprof,
                        "comment" => $meracikkomen,
                    ]);


                    $API->comm("/ppp/profile/unset", [
                        ".id" => $idprofile,
                        "value-name" => 'remote-address',
                    ]);
                } else {
                    $add_prof     = $API->comm("/ppp/profile/set", [
                        ".id" => $idprofile,
                        "name" => $namaprofile,
                        "rate-limit" => $ratelimitprof,
                        "only-one" => $onlyoneprof,
                        "parent-queue" => $parentprof,
                        "on-up" => $onupprof,
                        "remote-address" => $raddprof,
                        "local-address" => $laddprof,
                        "comment" => $meracikkomen,
                    ]);
                }
                $checkdata = json_encode($add_prof);
                if (strpos(strtolower($checkdata), '!trap')) {
                    echo '<script language="javascript">';
                    echo 'document.addEventListener("DOMContentLoaded", function() {';
                    echo 'alertify.alert("WARNING", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center>User PPP Already Exist </center>");';
                    echo '});';
                    echo '</script>';
                } else {
                    echo '<script language="javascript">';
                    echo 'document.addEventListener("DOMContentLoaded", function() {';
                    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success Add User PPP  </center>");';
                    echo '});';
                    echo '</script>';
                }
            }



            $seeprofile     = $API->comm('/ppp/profile/print');
            $getallqueue    = $API->comm("/queue/simple/print", ["?dynamic" => "false",]);
            $poolnya        = $API->comm("/ip/pool/print");


?>

            <script>
                var _0x82f1 = ["show.bs.modal", "id", "data", "relatedTarget", "cursor", "wait", "css", "body", "../pppoe/profile_edit.php", "id=", "html", "#view-respont", "default", "ajax", "on", "#profileedit"];

                function editprofileuser() {
                    $(_0x82f1[15])[_0x82f1[14]](_0x82f1[0], function(_0xfe4ax2) {
                        var _0xfe4ax3 = $(_0xfe4ax2[_0x82f1[3]])[_0x82f1[2]](_0x82f1[1]);
                        $(_0x82f1[7])[_0x82f1[6]](_0x82f1[4], _0x82f1[5]);
                        $[_0x82f1[13]]({
                            url: _0x82f1[8],
                            data: _0x82f1[9] + _0xfe4ax3,
                            cache: false,
                            success: function(_0xfe4ax4) {
                                $(_0x82f1[11])[_0x82f1[10]](_0xfe4ax4);
                                $(_0x82f1[7])[_0x82f1[6]](_0x82f1[4], _0x82f1[12])
                            }
                        })
                    })
                }
            </script>

            <script type="text/javascript">
                var profile = '<?php foreach ($seeprofile as $index => $baris) : echo '<option value="' . $baris['name'] . '">' . $baris['name'] . '</option>';
                                endforeach; ?>';

                function pilihprofile(name) {

                    if (name == 'pindah-profile') document.getElementById('pindahprofile').innerHTML = '<div class="row mg-t-8"><label class="col-sm-4 form-control-label align-self-center">Profile expired : </label><div class="col-sm-8 mg-t-10 mg-sm-t-0"> <select class="form-control select2id" style="width: 100%;" name="profileexpired" required><option value="">- choose -</option>' + profile + '</select></div></div>';
                    else document.getElementById('pindahprofile').innerHTML = '';
                }

                function pilihladd(name) {

                    if (name == 'isimanual') document.getElementById('laddid').innerHTML = '<div class="row mg-t-8"><label class="col-sm-4 form-control-label align-self-center">Silahkan isi IP Local Add : </label><div class="col-sm-8 mg-t-10 mg-sm-t-0"><input type="text" name="laddip" class="form-control" required></div></div>';
                    else document.getElementById('laddid').innerHTML = '';
                }

                function pilihradd(name) {

                    if (name == 'isimanual') document.getElementById('raddid').innerHTML = '<div class="row mg-t-8"><label class="col-sm-4 form-control-label align-self-center">Silahkan isi IP Remote Add : </label><div class="col-sm-8 mg-t-10 mg-sm-t-0"><input type="text" name="raddip" class="form-control" required></div></div>';
                    else document.getElementById('raddid').innerHTML = '';
                }
            </script>

            <div class="sl-pagebody">
                <div class="card bd-primary mg-t-3">
                    <div class="card-header bg-primary tx-white"><i class="fa fa-user"></i> PPP Profile Manager</div>
                    <div class="card-body pd-sm-15">

                        <div class="table-wrapper">
                            <table id="profileppp" class="table display nowrap " width="100%">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Harga</th>
                                        <th>Rate Limit <br>(rx/tx)</th>
                                        <th>Only One</th>
                                        <th>Parent Queue</th>
                                        <th>L. Address</th>
                                        <th>R. Address</th>
                                        <th>Expired System</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($seeprofile as $index => $baris) :
                                    ?>
                                        <tr>
                                            <!--AMBIL DATA DULU-->
                                            <?php
                                            //komenprofile | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(tenggat) | idprofile : *4 | price : 10000 | PPPoE-MITHA-MIKBOTAM |
                                            $datakomen  = explode(" | ", $baris['comment']);
                                            $tglexp     = explode("tgl-expired : ", $datakomen[0])[1];
                                            $jamexp     = explode("jam-expired : ", $datakomen[1])[1];
                                            $ekse       = explode("eksekusi : ", $datakomen[2])[1];
                                            $pecahekse  = explode("(", $ekse);
                                            $jnsekse    = $pecahekse[0];
                                            $proekse    = '';
                                            if ($jnsekse == 'pindah-profile') {
                                                $proekse = explode(')', $pecahekse[1])[0];
                                            }
                                            $harga      = rupiah(explode("price : ", $datakomen[4])[1]);

                                            if (count($datakomen) > 3) {
                                                $dataexpired = "tgl : $tglexp ($jamexp) | $jnsekse $proekse";
                                            } else {
                                                $dataexpired = "bukan mitha";
                                                $harga = "bukan mitha";
                                            }


                                            ?>
                                            <!--nama-->
                                            <td><a href='#profileedit' class="txt-black" data-toggle='modal' onclick='editprofileuser();' data-id="<?= $baris['.id']; ?>"><i class='fa fa-pencil-square-o'></i> <?php echo $baris['name']; ?></a></td>
                                            <!-- harga -->
                                            <td><?php echo $harga; ?></td>
                                            <!--Rate Limit-->
                                            <td><?php if (empty($baris['rate-limit'])) {
                                                    echo "none";
                                                } else {
                                                    echo $baris['rate-limit'];
                                                } ?></td>
                                            <!-- only one -->
                                            <td><?= $baris['only-one'] ?></td>
                                            <!-- parent queue -->
                                            <td><?= $baris['parent-queue'] ?></td>
                                            <!--Local Address-->
                                            <td><?php echo $baris['local-address']; ?></td>
                                            <!--remote Address-->
                                            <td><?php echo $baris['remote-address']; ?></td>
                                            <!--expired system-->
                                            <td><?php echo $dataexpired; ?></td>

                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

            <!-- CODE VARIABLE POP UP NYA -->



            <!-- FORM POP UP NYA -->

            <div id="ProfilePPPAdd" class="modal fade" role="dialog">

                <div class="modal-dialog wd-100p mn-wd-50p" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-25 bg-primary">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-white tx-bold">Add Profile PPPoE </h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body pd-15">
                            <div class="card bd bd-primary  ">
                                <div class="card-body pd-sm-15">

                                    <form action="" method="post">

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Profile Name : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <input type="text" name="name" class="form-control" required>
                                            </div>
                                        </div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Harga : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <input type="number" name="harga" class="form-control" required>
                                            </div>
                                        </div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Rate Limit [rx/tx] : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <input type="text" class="form-control" name="rate-limit" value="" data-toggle="tooltip" data-placement="top" title="example 1M/512k, salah penulisan maka data tidak terinput" placeholder="1M/512k" required>
                                            </div>
                                        </div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Only One : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control" name="onlyone" id="onlyone">
                                                    <option value="default">default</option>
                                                    <option value="yes" selected>yes</option>
                                                    <option value="no">no</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Parent Queue : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control" name="parent" data-toggle="tooltip" data-placement="top" title="Jika kosong pilih none">
                                                    <option>none</option>
                                                    <?php foreach ($getallqueue as $index => $barisan) : ?>
                                                        <option value="<?= $barisan['name'] ?>"><?= $barisan['name'] ?></option>
                                                    <?php endforeach;
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Local Address : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control" name="ladd" data-toggle="tooltip" data-placement="top" title="Jika kosong pilih none" onchange="pilihladd(this.options[this.selectedIndex].value)">
                                                    <option>none</option>
                                                    <?php foreach ($poolnya as $index => $barisan) : ?>
                                                        <option value="<?= $barisan['name'] ?>"><?= $barisan['name'] ?></option>
                                                    <?php endforeach;
                                                    ?>
                                                    <option value="isimanual">isi manual</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div id="laddid"></div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Remote Address : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control" name="radd" data-toggle="tooltip" data-placement="top" title="Jika kosong pilih none" onchange="pilihradd(this.options[this.selectedIndex].value)">
                                                    <option>none</option>
                                                    <?php foreach ($poolnya as $index => $barisan) : ?>
                                                        <option value="<?= $barisan['name'] ?>"><?= $barisan['name'] ?></option>
                                                    <?php endforeach;
                                                    ?>
                                                    <option value="isimanual">isi manual</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div id="raddid"></div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Tanggal Jatuh Tempo :</label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control select2id" style="width: 30%;" name="tglexp" id="tglexp">
                                                    <?php for ($i = 01; $i < 29; $i++) {
                                                        $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                                        echo "<option value='$ii'>$ii</option>";
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Waktu Jatuh Tempo (JAM : MENIT) :</label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control select2id" style="width: 30%;" name="jamexp" id="jamexp">
                                                    <?php for ($i = 01; $i < 24; $i++) {
                                                        $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                                        echo "<option value='$ii'>$ii</option>";
                                                    } ?>
                                                </select> &nbsp;:&nbsp;
                                                <select class="form-control select2id" style="width: 30%;" name="mntexp" id="mntexp">
                                                    <?php for ($i = 00; $i < 60; $i++) {
                                                        $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                                        echo "<option value='$ii'>$ii</option>";
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Eksekusi :</label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control select2id" style="width: 100%;" name="eksekusi" id="eksekusi" onchange="pilihprofile(this.options[this.selectedIndex].value)">
                                                    <option value="disable">disable</option>
                                                    <option value="pindah-profile">pindah profile</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div id="pindahprofile"></div>

                                        <div class="row row-xs mg-t-10">
                                            <div class="col-sm-15 mg-l-auto">
                                                <div class="form-layout-footer">
                                                    <button type="submit" class="btn bg-primary tx-white" name="saveprofile">Save changes</button>
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    <button type="reset" class="btn btn-danger">Reset</button>
                                                </div>
                                                <!-- form-layout-footer -->
                                            </div>
                                            <!-- col-8 -->
                                        </div>

                                    </form>
                                </div>

                            </div>


                        </div>
                    </div>

                </div>
            </div>

            </div>

            <div id="profileedit" class="modal fade" role="dialog">
                <div class="modal-dialog wd-100p mn-wd-50p" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-25 bg-primary">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-white tx-bold">Edit Profile PPP </h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body pd-15">
                            <div id="view-respont">

                                <h2>Loading...</h2>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

            <script src="../lib/bootstrap/bootstrap.js"></script>
            <script src="../js/MikbotamNumberCheck.js"></script>



<?php
        } else {
            include "disconnected.php";
        }

        fclose($fp);
    } else {
        include "disconnected.php";
    }
}

?>