//=====================================================START====================//

/*
 *  Base Code  	: BangAchil
 *  Email     		: kesumaerlangga@gmail.com
 *  Telegram  		: @bangachil
 *
 *  Name      		: Mikrotik bot telegram - php
 *  Function   	: Mikortik api 
 *  Manufacture	: November 2018
 *  Last Edited	: 26 Desember 2018
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
*/

//=====================================================START SCRIPT====================//



function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
};

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
};

function formatDate(date) {
  var monthNames = [
    "Januari", "Februari", "Maret",
    "April", "Mei", "juni", "Juli",
    "Augustus", "September", "Oktober",
    "November", "Desember"
  ];

  var day = date.getDate();
  var monthIndex = date.getMonth();
  var year = date.getFullYear();

  return day + ' ' + monthNames[monthIndex] + ' ' + year;
};

$(function() {
    'use strict';
    
  $('.fadesa').slick({
 autoplay: true,
  dots: false,
  infinite: true,
  speed: 500,
  fade: true,
  cssEase: 'linear'
});
  $('.select2').select2({
        minimumResultsForSearch: Infinity
    });        
  $('.select2id').select2({
                    minimumResultsForSearch: ''
                });
  $('.datepicker').datepicker({
    showOtherMonths: true,
    selectOtherMonths: true
  });

$("#ppplistprofile").DataTable({paging:false,ordering:false,info:false,scrollX:true,scrollY:true,language:{searchPlaceholder:"Search...",sSearch:"",lengthMenu:"_MENU_ items/page"},dom:"Bfrtip",buttons:[{text:"Add PPP Profile",action:function(_0x7e35x1,_0x7e35x2,_0x7e35x3,_0x7e35x4){$("#myModal")["modal"]("show")}}]});

$("#ppplist").DataTable({paging:false,ordering:false,info:false,scrollX:true,scrollY:true,language:{searchPlaceholder:"Search...",sSearch:"",lengthMenu:"_MENU_ items/page"},dom:"Bfrtip",buttons:[{text:"Add User Secret",action:function(_0x7e35x1,_0x7e35x2,_0x7e35x3,_0x7e35x4){$("#myModal")["modal"]("show")}}]});

$("#profileppp").DataTable({paging:false,ordering:false,info:false,scrollX:true,scrollY:true,language:{searchPlaceholder:"Search...",sSearch:"",lengthMenu:"_MENU_ items/page"},dom:"Bfrtip",buttons:[{text:"Add Profile PPP",action:function(_0x7e35x1,_0x7e35x2,_0x7e35x3,_0x7e35x4){$("#ProfilePPPAdd")["modal"]("show")}}]});

$("#hotspot").DataTable({paging:false,ordering:false,info:false,scrollX:true,scrollY:true,language:{searchPlaceholder:"Search...",sSearch:"",lengthMenu:"_MENU_ items/page"},dom:"Bfrtip",buttons:[{text:"Add User",action:function(_0x7e35x1,_0x7e35x2,_0x7e35x3,_0x7e35x4){$("#Hotspotadd")["modal"]("show")}}]});

$("#profilehotspot").DataTable({paging:false,ordering:false,info:false,scrollX:true,scrollY:true,language:{searchPlaceholder:"Search...",sSearch:"",lengthMenu:"_MENU_ items/page"},dom:"Bfrtip",buttons:[{text:"Add Profile",action:function(_0x7e35x1,_0x7e35x2,_0x7e35x3,_0x7e35x4){$("#ProfileHotspotAdd")["modal"]("show")}}]});

$("#voucherlist").DataTable({paging:false,ordering:false,info:false,scrollX:true,scrollY:true,language:{searchPlaceholder:"Search...",sSearch:"",lengthMenu:"_MENU_ items/page"},dom:"Bfrtip",buttons:[{text:"Add Voucher",action:function(_0x7e35x1,_0x7e35x2,_0x7e35x3,_0x7e35x4){$("#voucheradd")["modal"]("show")}}]});

$("#userlist").DataTable({paging:false,ordering:false,info:false,scrollX:true,scrollY:true,language:{searchPlaceholder:"Search...",sSearch:"",lengthMenu:"_MENU_ items/page"}});

$("#userhistory2").DataTable({paging:false,ordering:false,info:false,scrollX:true,scrollY:true,searching:false});$(".dataTables_length select")["select2"]({minimumResultsForSearch:Infinity});$("#notelfun")["mask"]("0000-0000-0000");$("#Saldo")["mask"]("0.000.000.000",{reverse:true});$("#ipaddress")["mask"]("0ZZ.0ZZ.0ZZ.0ZZ",{translation:{"\x5A":{pattern:/[0-9]/,optional:true}}})
  $('#textnya').keyup(function() {
                var len = this.value.length;
                if (len >= 4200) {
                    this.value = this.value.substring(0, 4200);
                }
                $('#hitung').text(4200 - len);
            });
  $('.mailbox-sideleft').perfectScrollbar();
  $('#showMailboxLeft').on('click', function(){
  $('body').toggleClass('show-mailbox-left');


        });

    $('.poll').select2({
 tags: true,
  createTag: function (params) {
    return {
      id: params.term,
      text: params.term,
      newOption: true
    }
  },
  templateResult: function (data) {
    var $result = $("<span></span>");

    $result.text(data.text);

    if (data.newOption) {
      $result.append(" <em>(custom, click me)</em>");
    }

    return $result;
  }

});

});