

<?php
//=====================================================START====================//

/*

   Core.php
   Edit hanya textnya saja
    */

//=====================================================START SCRIPT====================//

include 'rpt/botpppoe.php';

//Any commands akan di cegah dengan ini jika  perlu silahakan dihapus /* dan  */


$mkbot->cmd('*', 'gunakan perintah /help untuk melihat daftar perintah');


//Start commands
$mkbot->cmd('/start|/Start', function () {
   include('../config/system.conn.php');
   $info         = bot::message();
   $ids          = $info['chat']['id'];
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');

   if (has($idtelegram) == false) {

      $text = "";
      //Ubah text dibawah ini untuk user yang belum terdaftar
      // GANTI NAMA SEBUTAN
      $text    = 'Selamat datang @' . $nametelegram . ' silahkan ketik /daftar untuk mendaftar layanan ini';
      $options = [
         'parse_mode' => 'html'
      ];
      return Bot::sendMessage($text, $options);
   } else {
      $text = "";

      //ubah text ini untuk user yang sudah terdaftar

      $text = "Hai @$nametelegram ada yang bisa kami bantu?\n/help untuk informasi bantuan ";
   }

   $options = [
      'parse_mode' => 'html'
   ];

   return Bot::sendMessage($text, $options);
});

//deposit commands
$mkbot->cmd('/deposit|/request', function ($jumlah) {
   include('../config/system.conn.php');
   $info         = bot::message();
   $ids          = $info['chat']['id'];
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];

   $text         = "";

   if (!empty($jumlah)) {
      if (has($idtelegram) == false) {
         //jika user belum terdaftar
         $text = 'Anda tidak terdaftar Silahkan daftar terlebih dahulu ke admin atau /daftar sebelum request top up saldo';
      } else {
         if (preg_match('/^[0-9]+$/', $jumlah)) {
            if (strlen($jumlah) < 9) {
               $id_text      = getid();
               $array_text   = ngambiltext($id_text);
               $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
               $array_de     = json_decode($array_text, true);
               $infodepo     = $array_de['info_depo'];
               //jika user belum terdaftar
               $text .= "Permintaan deposit  sebesar " . rupiah($jumlah) . " sudah kami terima, \nSilahkan kirimkan foto bukti pembayaran  disertai dengan Caption #konfirmasi deposit " . rupiah($jumlah) . "\n\n" . $infodepo . "\n\nKonfirmasi selambatnya 2 jam setelah permintaan deposit";
               $textsend = "";
               $textsend .= "<code>User :  </code>@$nametelegram \n";
               $textsend .= "<code>ID   : </code> <code>$idtelegram </code>\n";
               $textsend .= "<code>Request pengisian saldo </code>\n";
               $textsend .= "<code>Nominal :" . rupiah($jumlah) . "</code>\n";
               $textsend .= "<code>Silahkan tindak lanjut \nAtau Hubungi user </code> @$nametelegram \n\n";
               $textsend .= "Dengan Menekan tombol dibawah ini saldo user otomatis terisi  ";

               //-===================rubah texnya saja ya
               $kirimpelangan = [
                  'chat_id' => $id_own,
                  'reply_markup' => json_encode([
                     'inline_keyboard' => [
                        [
                           ['text' => 'QUICK TOP UP', 'callback_data' => '12'],
                        ],
                        [
                           ['text' => '' . rupiah($jumlah) . '', 'callback_data' => 'tp|' . $jumlah . '|' . $idtelegram . '|' . $nametelegram . ''],
                        ],
                        [
                           ['text' => 'OR COSTUM', 'callback_data' => '12'],
                        ],
                        [
                           ['text' => '10000', 'callback_data' => 'tp|10000|' . $idtelegram . '|' . $nametelegram . ''],
                           ['text' => '15000', 'callback_data' => 'tp|15000|' . $idtelegram . '|' . $nametelegram . ''],
                           ['text' => '20000', 'callback_data' => 'tp|20000|' . $idtelegram . '|' . $nametelegram . ''],
                        ],
                        [

                           ['text' => '25000', 'callback_data' => 'tp|25000|' . $idtelegram . '|' . $nametelegram . ''],
                           ['text' => '30000', 'callback_data' => 'tp|30000|' . $idtelegram . '|' . $nametelegram . ''],
                           ['text' => '50000', 'callback_data' => 'tp|50000|' . $idtelegram . '|' . $nametelegram . ''],
                        ],
                        [

                           ['text' => '100000', 'callback_data' => 'tp|100000|' . $idtelegram . '|' . $nametelegram . ''],
                           ['text' => '150000', 'callback_data' => 'tp|150000|' . $idtelegram . '|' . $nametelegram . ''],
                           ['text' => '200000', 'callback_data' => 'tp|200000|' . $idtelegram . '|' . $nametelegram . ''],
                        ],
                        [

                           ['text' => 'Reject Request', 'callback_data' => 'tp|reject|' . $id . '|reject']
                        ],

                     ]
                  ]),
                  'parse_mode' => 'html'

               ];

               Bot::sendMessage($textsend, $kirimpelangan);
            } else {
               $text = 'Maaf Maksimal deposit Top Up Rp 99.999.999.00';
            }
         } else {
            $text = 'Maaf input Nominal saldo hanya berupa angka saja';
         }
      }
   } else {
      $id_text      = getid();
      $array_text   = ngambiltext($id_text);
      $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
      $array_de     = json_decode($array_text, true);
      $infodepo     = $array_de['info_depo'];
      $text .= $infodepo;
      $text .= "\n------\n";
      $text .= "Perintah ini di gunakan untuk Request Deposit Saldo kepada Adminstator \n";
      $text .= "Anda dapat  Custom Request Deposit dengan cara \n";
      $text .= "/deposit (nominal)\n";
      $text .= "Contoh\n";
      $text .= "/deposit 1000 \n";
      $text .= "/deposit 70000 \n";
      $text .= "Atau menekan tombol dibawah ini \n";
      $options = [
         'reply_markup' => json_encode([
            'inline_keyboard' => [
               [
                  ['text' => '⬇ REQUEST ⬇', 'callback_data' => '12'],
               ],
               [
                  ['text' => '10000', 'callback_data' => 'tps|10000'],
                  ['text' => '15000', 'callback_data' => 'tps|15000'],
                  ['text' => '20000', 'callback_data' => 'tps|20000'],
               ],
               [

                  ['text' => '25000', 'callback_data' => 'tps|25000'],
                  ['text' => '30000', 'callback_data' => 'tps|30000'],
                  ['text' => '50000', 'callback_data' => 'tps|50000'],
               ],
               [

                  ['text' => '100000', 'callback_data' => 'tps|100000'],
                  ['text' => '150000', 'callback_data' => 'tps|150000'],
                  ['text' => '200000', 'callback_data' => 'tps|200000'],
               ],

            ]
         ]),
         'parse_mode' => 'html'

      ];
   }

   return Bot::sendMessage($text, $options);
});

//cekid commands
$mkbot->cmd('/cekid|/Cekid', function ($jumlah) {
   include('../config/system.conn.php');
   $info   = bot::message();
   $iduser = $info['from']['id'];
   $msgid  = $info['message_id'];
   $name   = $info['from']['username'];
   $id     = $info['from']['id'];

   if (has($id) == false) {
      $text = "<code>    Informasi ID Anda</code>\n";
      $text .= "<code>========================</code>\n";
      $text .= "<code>  ID User  :</code> <code>$id</code>\n";
      $text .= "<code>  Username :</code> @$name\n";
      $text .= "<code>  Status   : - </code>\n";
      $text .= "<code>========================</code>\n";
   } else {
      $text = "<code>    Informasi ID Anda</code>\n";
      $text .= "<code>========================</code>\n";
      $text .= "<code>  ID User  : </code> <code>$id</code>\n";
      $text .= "<code>  Username : </code> @$name\n";
      $text .= "<code>  Status   : Terdaftar </code>\n";
      $text .= "<code>========================</code>\n";
   }

   $options = [
      'parse_mode' => 'html'
   ];
   return Bot::sendMessage($text, $options);
});


//daftar commands
$mkbot->cmd('/daftar', function () {
   include('../config/system.conn.php');

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];


   Bot::sendChatAction('typing');
   $ids = $info['chat']['id'];

   if (empty($nametelegram)) {
      $text = 'Maaf Akun Telegram anda belum terpasang username silahkan pasang terlebih dahulu username anda';
   } else {

      if (has($idtelegram) == false) {
         if ($idtelegram == $id_own) {
            $cek = daftar($idtelegram, $nametelegram);

            if (empty($cek)) {
               $text  = "Mohon Maaf system mengalami gangguan silahkan calon reseller untuk mencoba mendaftar ulang\n";
            } else {
               $text .= "Selamat anda telah menjadi ADMIN, dengan detail sbb :\n\n";
               $text .= "<code>   Customer ID $idtelegram   </code>\n";
               $text .= "<code>========================</code>\n";
               $text .= "<code>  ID User  :</code> <code>$idtelegram</code>\n";
               $text .= "<code>  Username :</code> @$nametelegram\n";
               $text .= "<code>  Status   : ADMIN </code>\n";
               $text .= "<code>========================</code>\n";
            }
         } else {
            $text    = "Permohonan anda telah kami terima, silahkan tunggu untuk konfirmasi selanjutnya oleh admin. terima kasih";

            //kolom ngirim ke admin

            $textkeadmin   = "akun $nametelegram ($idtelegram) mendaftar sebagai reseller.\n";
            $textkeadmin   .= "silahkan merespon melalui tombol dibawah ini.";

            $inlinekey     = [
               [
                  ['text' => "🟢 TERIMA 🟢", 'callback_data' => "pendaftaran : terima|" . $idtelegram . "|" . $nametelegram]
               ],
               [
                  ['text' => "🔴 TOLAK 🔴", 'callback_data' => "pendaftaran : tolak|" . $idtelegram . "|" . $nametelegram]
               ],
            ];

            $kirimadmin    = [
               'chat_id'         => $id_own,
               'reply_markup'   => json_encode([
                  'inline_keyboard' => $inlinekey,
               ]),
               'parse_mode'      => 'html'
            ];

            Bot::sendMessage($textkeadmin, $kirimadmin);
         }
      } else {
         $text .= "Maaf Anda sudah terdaftar dalam layanan ini\n\n";
         $text .= "<code>    Informasi ID Anda</code>\n";
         $text .= "<code>========================</code>\n";
         $text .= "<code>  ID User  : </code> <code>$idtelegram</code>\n";
         $text .= "<code>  Username : </code> @$nametelegram\n";
         $text .= "<code>  Status   : Terdaftar </code>\n";
         $text .= "<code>========================</code>\n";
      }
   }

   $options = [
      'parse_mode' => 'html'
   ];
   return Bot::sendMessage($text, $options);
});
//help commands
$mkbot->cmd('/help|!Help', function ($id, $name, $notlp, $saldo) {
   include('../config/system.conn.php');
   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');

   if ($idtelegram == $id_own) {
      $text .= "/menu - Menu Voucher\n";
      $text .= "/daftar - daftar layanan\n";
      $text .= "/ceksaldo - ceksaldo layanan\n";
      $text .= "/cek id - Status user\n";
      $text .= "/cekvcr (kode) - untuk cek voucher yang digenerate\n\n";
      $text .= "=====Admin commands========\n\n";
      $text .= "/pesan (isi pesan) - untuk mengirim pesan massal ke seluruh reseller\n\n";
      $text .= "/reseller - untuk cek status reseller\n\n";
      $text .= "/lapbul - untuk cek laporan bulanan\n\n";
      $text .= "/laptgl (tgl bln thn) - untuk cek laporan pada tanggal tertentu\n\n";
      $text .= "/lap (tglblnthn awal) (tglblnthn akhir) - untuk cek laporan reseller pada range tanggal tertentu\n\n";
      $text .= "/daftarid - daftar user manual\n";
      $text .= "/topdown - mengurangi jumlah saldo user\n";
      $text .= "/topup - TOP UP SALDO USER\n";
      $text .= "/hotspot - cek pengguna hotspot\n";
      $text .= "/transfer idtujuan nominal - mengirim saldo ke reseller lain (saldo anda berkurang)\n";
      $text .= "/rekapall - untuk melihat report dari reseller\n";
      $text .= "/rekap - untuk melihat laporan diri sendiri range tanggal tertentu\n\n";
      $text .= "/delreport - untuk menghapus laporan bulan lalu atau setelah 3 bulan yang lalu\n berguna untuk meringankan kinerja server dan bot telegram\n\n";
      $text .= "/pppoe - untuk mengontrol client pppoe\n\n";
      $text .= "/otodepo - untuk deposit melalui payment gateway (jika disediakan)\n\n";
   } else {
      $text .= "/menu - Menu Voucher\n";
      $text .= "/deposit [nominal]\n";
      $text .= "/daftar - daftar layanan\n";
      $text .= "/ceksaldo - ceksaldo layanan\n";
      $text .= "/cek id - Status user\n";
      $text .= "/transfer idtujuan nominal - mengirim saldo ke reseller lain (saldo anda berkurang)\n";
      $text .= "/cekvcr (kode) - untuk cek voucher yang digenerate\n\n";
      $text .= "/rekap - untuk melihat laporan diri sendiri range tanggal tertentu\n";
      $text .= "/otodepo - untuk deposit melalui payment gateway (jika disediakan)\n\n";
   }

   $optionss = ['parse_mode' => 'html',];
   Bot::sendMessage($text, $optionss);
});
//daftar manual khusus Administator
$mkbot->cmd('/daftarid', function ($id, $name, $notlp, $saldo) {
   include('../config/system.conn.php');
   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');

   if ($idtelegram == $id_own) {
      if (empty($id) && empty($name) && empty($notlp) && empty($saldo)) {
         $text = "Maaf Format anda salah \n\nMohon masukan format dengan benar \n/daftar noid namauser notlpn saldo";
      } else {

         $lihat = lihatuser($id);

         if (empty($lihat)) {
            $text = daftarid($id, $name, $notlp, $saldo);
         } else {
            $text = "User sudah terdaftar periksa kembali ";
         }
      }
   } else {

      $text = "Maaf..! Aksess Hanya untuk Administator";
   }

   $options = [
      'parse_mode' => 'html'
   ];
   return Bot::sendMessage($text, $options);
});
//topdown khusus Administator
$mkbot->cmd('/topdown', function ($id, $jumlahan) {
   $info       = bot::message();
   $msgid      = $info['message_id'];
   $name       = $info['from']['username'];
   $idtelegram = $info['from']['id'];
   include('../config/system.conn.php');

   if ($idtelegram == $id_own) {
      if (!empty($id) && !empty($jumlahan)) {
         if (has($id) == false) {
            $text = 'Data id tidak terdaftar silahkan periksa kembali';
         } else {

            if (preg_match('/^[0-9]+$/', $jumlahan)) {
               if (strlen($jumlahan) < 7) {
                  $topdown = topdown($id, $jumlahan);
                  $text  = "<code>     Informasi refund</code>\n";
                  $text .= "<code> ========================</code>\n";
                  $text .= "<code>  Refund      : " . rupiah($jumlahan) . "</code>\n";
                  $text .= "<code>  ID User     : $id</code>\n";
                  $text .= "<code>  Username    : $userreseller</code>\n";
                  $text .= "<code>  Saldo akhir : " . rupiah(lihatsaldo($id)) . "</code>\n";
                  $text .= "<code>  Penarikan saldo berhasil</code>\n";


                  $website = "https://api.telegram.org/bot" . $token;
                  $params  = [
                     'chat_id' => $id,
                     'text' => $text,
                     'parse_mode' => 'html',
                  ];
                  $ch = curl_init($website . '/sendMessage');
                  curl_setopt($ch, CURLOPT_HEADER, false);
                  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                  curl_setopt($ch, CURLOPT_POST, 1);
                  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
                  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                  $result = curl_exec($ch);
                  curl_close($ch);
               } else {
                  //=================>>> GANTI NOMINAL TOP DOWN
                  $text = 'Maaf Maksimal refund Rp 999.999.00';
               }
            } else {
               $text = 'Maaf input saldo hanya berupa angka saja';
            }
         }
      } else {
         $text = "Maaf format anda salah /topdown (id) (jumlah)";
      }
   } else {
      $text = "Maaf..! Aksess Hanya untuk Administator";
   }

   $optionss = ['parse_mode' => 'html',];
   Bot::sendMessage($text, $optionss);
});
//topup khusus Administator
$mkbot->cmd('/topup', function ($jumlah) {

   $info       = bot::message();
   $msgid      = $info['message_id'];
   $name       = $info['from']['username'];
   $idtelegram = $info['from']['id'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');
   $datares    = lihatdata();
   $jmldata    = count($datares);
   $pecahres   = array_chunk($datares, 2);

   if ($idtelegram == $id_own) {
      if (!empty($jumlah)) {


         if (preg_match('/^[0-9]+$/', $jumlah)) {
            if (strlen($jumlah) < 8) {
               $text = "silahkan pilih reseller yang akan di topup sebesar <b>" . rupiah($jumlah) . "</b>";
               $send = [];
               foreach ($pecahres as $index => $satuan) {
                  $reskiri = ['text' => $satuan[0]['nama_seller'] . '', 'callback_data' =>  $satuan[0]['id_user'] . 'rts' . $jumlah];
                  $reskanan = ['text' => $satuan[1]['nama_seller'] . '', 'callback_data' =>  $satuan[1]['id_user'] . 'rts' . $jumlah];
                  $barisreseller = array_filter([$reskiri, $reskanan]);
                  array_push($send, $barisreseller);
               }
               $menu_idakhir = [
                  ['text' => 'batal', 'callback_data' => 'cancel'],

               ];
               array_push($send, $menu_idakhir);
               $options = [
                  'reply_markup' => json_encode(['inline_keyboard' => $send]),
                  'parse_mode' => 'html'
               ];
            } else {
               //==============>>>>>>ganti MAX TOP UP
               $text = 'Maaf Maksimal Top Up Rp 9.999.999.00';
            }
         } else {
            $text = 'Maaf input saldo hanya berupa angka saja';
         }
      } else {
         $text = "Maaf format anda salah /topup (jumlah)";
      }
   } else {
      $text = "Maaf..! Aksess Hanya untuk Administator";
   }


   return Bot::sendMessage($text, $options);
});
//lihatsaldo commands
$mkbot->cmd('/lihatsaldo|/ceksaldo', function ($jumlah) {
   include('../config/system.conn.php');
   $info   = bot::message();
   $iduser = $info['from']['id'];
   $msgid  = $info['message_id'];
   $name   = $info['from']['username'];
   $id     = $info['from']['id'];
   $lihat  = lihatuser($id);
   $ids    = $info['chat']['id'];
   $id_text      = getid();
   $array_text   = ngambiltext($id_text);
   $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
   $array_de     = json_decode($array_text, true);
   $saldo_kaki    = $array_de['saldo_footer'];

   if (empty($saldo_kaki)) {
      $saldo_kaki = "-";
   }

   if (empty($lihat)) {
      $text = 'anda tidak terdaftar silahkan daftar terlebih dahulu ke admin atau klik /daftar';
   } else {
      $angka = lihatsaldo($id);
      $text  = "<code>      Informasi Saldo</code>\n";
      $text .= "<code>========================</code>\n";
      $text .= "<code>  ID User : $id</code>\n";
      $text .= "<code>  Name    : $name</code>\n";
      $text .= "<code>  Saldo   : " . rupiah($angka) . "</code>\n";
      $text .= "<code>========================</code>\n";
      $text .= $saldo_kaki;
   }

   $options = [
      'parse_mode' => 'html'
   ];
   return Bot::sendMessage($text, $options);
});
//resource commands
$mkbot->cmd('/resource|/Resource', function () {

   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   Bot::sendChatAction('typing');

   include('../config/system.conn.php');

   if ($idtelegram == $id_own) {
      $API = new routeros_api();

      if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
         $jambu         = $API->comm("/system/health/print");
         $dhealth       = $jambu['0'];
         $ARRAY         = $API->comm("/system/resource/print");
         $jeruk         = $ARRAY['0'];
         $memperc       = ($jeruk['free-memory'] / $jeruk['total-memory']);
         $hddperc       = ($jeruk['free-hdd-space'] / $jeruk['total-hdd-space']);
         $mem           = ($memperc * 100);
         $hdd           = ($hddperc * 100);
         $sehat         = $dhealth['temperature'];
         $platform      = $jeruk['platform'];
         $board         = $jeruk['board-name'];
         $version       = $jeruk['version'];
         $architecture  = $jeruk['architecture-name'];
         $cpu           = $jeruk['cpu'];
         $cpuload       = $jeruk['cpu-load'];
         $uptime        = $jeruk['uptime'];
         $cpufreq       = $jeruk['cpu-frequency'];
         $cpucount      = $jeruk['cpu-count'];
         $memory        = formatBytes($jeruk['total-memory']);
         $fremem        = formatBytes($jeruk['free-memory']);
         $mempersen     = number_format($mem, 3);
         $hdd           = formatBytes($jeruk['total-hdd-space']);
         $frehdd        = formatBytes($jeruk['free-hdd-space']);
         $hddpersen     = number_format($hdd, 3);
         $sector        = $jeruk['write-sect-total'];
         $setelahreboot = $jeruk['write-sect-since-reboot'];
         $kerusakan     = $jeruk['bad-blocks'];
         $text .= "";
         $text .= "📡<b> Resource</b>  $sehat C\n";
         $text .= "<code>Boardname: $board</code>\n";
         $text .= "<code>Platform : $platform</code>\n";
         $text .= "<code>Uptime is: " . formatDTM($uptime) . "</code>\n";
         $text .= "<code>Cpu Load : $cpuload%</code>\n";
         $text .= "<code>Cpu type : $cpu</code>\n";
         $text .= "<code>Cpu Hz   : $cpufreq Mhz/$cpucount core</code>\n==========================\n";
         $text .= "<code>Free memory and memory \n$memory-$fremem/$mempersen %</code>\n==========================\n";
         $text .= "<code>Free disk and disk      \n$hdd-$frehdd/$hddpersen %</code>\n==========================\n";
         $text .= "<code>Since reboot, bad blocks \n$sector-$setelahreboot/$kerusakan%</code>\n==========================\n";
      }
   } else {
      $text = "Maaf..! Aksess Hanya untuk Adminstator";
   }

   $options = ['parse_mode' => 'html',];
   Bot::sendMessage($text, $options);
});


//User commands khusus Administator

//report commands khusus Administator


//netwatch commands khusus Administator

//debug message semua

//qrcode terjemah qrcode



//===========UPDATE DIATAS TANDA INI BIAR AMAN=============     
//see_ melihat user aktif
$mkbot->regex('/^\/see_/', function ($matches) {
   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   $isipesan     = $info['text'];
   Bot::sendChatAction('typing');
   include('../config/system.conn.php');

   if ($idtelegram == $id_own) {
      if ($isi == '/see_') {
         $text .= "⛔  Periksa \n\n<b>KETERANGAN   :</b>\nTidak Ditemukan ";
      } else {
         $sapubasah  = str_replace('/see_', '', $isipesan);
         $sapulantai = str_replace('0', '-', $sapubasah);
         $sapuujuk   = str_replace('11', ' ', $sapulantai);
         $sapulidi   = str_replace('@' . $usernamebot . '', '', $sapuujuk);
         $API        = new routeros_api();

         if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            $pepaya = $API->comm("/ip/hotspot/active/print", ["?server" => $sapulidi]);

            if (empty($pepaya)) {
               $texta = "Tidak ada user aktif server $sapulidi";
               Bot::sendMessage($texta);
            }

            for ($i = 0; $i < count($pepaya); $i++) {
               $mangga    = $pepaya[$i];
               $id        = $mangga['.id'];
               $server    = $mangga['server'];
               $user      = $mangga['user'];
               $address   = $mangga['address'];
               $mac       = $mangga['mac-address'];
               $uptime    = $mangga['uptime'];
               $usesstime = $mangga['session-time-left'];
               $bytesi    = formatBytes($mangga['bytes-in'], 2);
               $byteso    = formatBytes($mangga['bytes-out'], 2);
               $loginby   = $mangga['login-by'];
               $comment   = $mangga['comment'];
               $text .= "";
               $text .= "👤 User aktif $server\n";
               $text .= "┠ ID :$id\n";
               $text .= "┠ User  : $user\n";
               $text .= "┠ IP    : $address\n";
               $text .= "┠ Uptime : $uptime\n";
               $text .= "┠ Byte IN      : $bytesi\n";
               $text .= "┠ Byte OUT   : $byteso\n";
               $text .= "┠ Sesion  : $usesstime\n";
               $text .= "┗ Login    : $loginby\n \n";

               Bot::sendMessage($text);
               $total = "Total login $server " . count($pepaya);
               Bot::sendMessage($total);
            }
         }
      }
   } else {
      $denid = "Maaf..! Aksess Hanya untuk Administator";
      Bot::sendMessage($denid);
   }
});


$mkbot->regex('/^\/rEm0vid/', function ($matches) {
   $info         = bot::message();
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   $isipesan     = $info['text'];
   Bot::sendChatAction('typing');
   $text = "";
   include('../config/system.conn.php');

   if ($idtelegram == $id_own) {
      if ($isipesan == '/rEm0vid') {
         $text .= "⛔ Gagal dihapus \n\n<b>KETERANGAN   :</b>\nTidak Ditemukan Id User";
      } else {
         $id  = str_replace('/rEm0vid', '*', $isipesan);
         $ids = str_replace('@' . $usernamebot, '', $id);
         $API = new routeros_api();

         if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            $ARRAY  = $API->comm("/ip/hotspot/user/print", ["?.id" => $ids,]);
            $data1  = $ARRAY[0]['.id'];
            $data2  = $ARRAY[0]['name'];
            $data3  = $ARRAY[0]['password'];
            $data5  = $ARRAY[0]['profile'];
            $ARRAY2 = $API->comm("/ip/hotspot/user/remove", ["numbers" => $ids,]);
            $texta  = json_encode($ARRAY2);

            if (strpos(strtolower($texta), 'no such item') !== false) {
               $gagal = $ARRAY2['!trap'][0]['message'];
               $text .= "⛔ Gagal dihapus \n\n<b>KETERANGAN   :</b>\n$gagal";
            } elseif (strpos(strtolower($texta), 'invalid internal item number') !== false) {
               $gagal = $ARRAY2['!trap'][0]['message'];
               $text .= "⛔ Gagal dihapus \n\n<b>KETERANGAN   :</b>\n$gagal";
            } elseif (strpos(strtolower($texta), 'default trial user can not be removed') !== false) {
               $gagal = $ARRAY2['!trap'][0]['message'];
               $text .= "⛔ Gagal dihapus \n\n<b>KETERANGAN   :</b>\n$gagal";
            } else {
               $text .= "Berhasil Dihapus\n\n";
               $text .= "<code>ID         : $ids</code>\n";
               $text .= "<code>Server     : $data1</code>\n";
               $text .= "<code>Name       : $data2</code>\n";
               $text .= "<code>Password   : $data3</code>\n";
               $text .= "<code>Profile    : $data5</code>\n";
               sleep(2);
               $ARRAY3 = $API->comm("/ip/hotspot/user/print");
               $jumlah = count($ARRAY3);
               $text .= "Jumlah user saat ini : $jumlah user";
            }
         } else {
            $text = "Gagal Periksa sambungan Kerouter";
         }
      }

      $options = ['parse_mode' => 'html',];
      $texta   = json_encode($ARRAY2);
      return Bot::sendMessage($text, $options);
   } else {
      $denid = "Maaf..! Aksess Hanya untuk Administator";
      Bot::sendMessage($denid);
   }
});


$mkbot->cmd('!Menu|/Menu|/menu', function ($userpass) {
   $info         = bot::message();
   $ids          = $info['chat']['id'];
   $msgid        = $info['message_id'];
   $nametelegram = $info['from']['username'];
   $idtelegram   = $info['from']['id'];
   $id_text      = getid();
   $array_text   = ngambiltext($id_text);
   $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
   $array_de     = json_decode($array_text, true);
   $text_mehe    = $array_de['menu_header'];
   /*
- ambil grup vc dari id telegram tsb
- variable grup vc tsb disingkronkan dengan grup di voucher
- tampilkan yang sesuai grup vc id = grup vc voucher
*/

   if (empty($text_mehe)) {
      $text_mehe = "-";
   }

   $userpass     = explode(" ", $userpass[0]);
   $usernya      = $userpass[1];
   $userpassfn   = $userpass[1] . " " . $userpass[2];
   include('../config/system.conn.php');
   $API        = new routeros_api();
   if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
      $userlst = $API->comm('/ip/hotspot/user/print', [
         "?name" => $usernya,
      ]);
      $namauser = $userlst[0]['name'];
   }

   if (!empty($namauser)) {

      $text = "maaf user " . $namauser . " sudah terpakai";

      $options = ['parse_mode' => 'html'];

      return Bot::sendMessage($text, $options);
   } else {
      $text         = "";
      if (has($idtelegram) && !empty($nametelegram)) {
         include('../config/system.conn.php');
         $data = json_decode($voucher_1, true);
         //ambil data reseller
         $ambildata     = lihatuser($idtelegram);
         //ambil username
         $usernamedbase = $ambildata['nama_seller'];

         //jika nama telegram tidak sama dengan nama database maka nama database diupdate menggunakan nama telegram sekarang
         if ($usernamedbase != $nametelegram) {
            updateusername($idtelegram, $nametelegram);
         }

         //filter reseller dengan vc tertentu
         $resvcgrup = lihatuser($idtelegram)['othertree'];

         if (!empty($resvcgrup) && $resvcgrup != "all") {
            $arraybaru = [];
            if (!empty($data)) {
               foreach ($data as $indeks) {
                  if (preg_match('/' . $resvcgrup . '/', $indeks['grupvc'])) {
                     $arraybaru = array_merge($arraybaru, [$indeks]);
                  }
               }
            }
            $data = $arraybaru;
         } else if (empty($resvcgrup)) {
            $arraybaru = [];
            if (!empty($data)) {
               foreach ($data as $indeks) {
                  if (preg_match('/default/', $indeks['grupvc'])) {
                     $arraybaru = array_merge($arraybaru, [$indeks]);
                  }
               }
            }
            $data = $arraybaru;
         }
         if (!empty($data)) {
            //========header====
            $text .= $text_mehe;
            //==================   
            $text .= "\n============\n";
            $text .= "<i>Silahkan Pilih voucher dibawah ini</i>\n\n";
            $text .= "<code>Daftar Voucher :</code>\n";

            foreach ($data as $hargas) {
               $textlist = $hargas['Text_List'];
               $jenisvoucher = $hargas['Voucher'];

               $text .= "<code>[$jenisvoucher] : $textlist  </code>\n";
            }


            //==========mulai bedah disini
            $splitarray = array_chunk($data, 2);
            $send = [];
            foreach ($splitarray as $index => $pocersatuan) {
               //=======mitha 3.2 ubah Vcr menjadi verifikasi agar lewat tahap cek dulu
               $database1 = ['text' => $pocersatuan[0]['Voucher'] . '', 'callback_data' => 'verifikasi' . $pocersatuan[0]['id'] . ' ' . $userpassfn . ''];

               $database2 = ['text' => $pocersatuan[1]['Voucher'] . '', 'callback_data' => 'verifikasi' . $pocersatuan[1]['id'] . ' ' . $userpassfn . ''];

               $barispocer = array_filter([$database1, $database2]);

               array_push($send, $barispocer);
            }

            //=============sampe sini
            $menu_idakhir = [
               ['text' => '💰 Cek Saldo', 'callback_data' => 'notifsaldo'],
               ['text' => '🔖 iNFORMASI', 'callback_data' => 'informasi'],
            ];
            //=======lalu modif ini

            array_push($send, $menu_idakhir);

            //======sampe sini
            $options = [
               'reply_markup' => json_encode(['inline_keyboard' => $send]),
               'parse_mode' => 'html'
            ];

            Bot::sendMessage($text, $options);
            unset($data, $voucher_1, $splitarray);
         } else {

            Bot::sendMessage('Maaf system tidak terdapat voucher');
         }
      } else {
         Bot::sendMessage('Anda tidak terdaftar silahkan daftar terlebih dahulu ke admin atau klik /daftar, atau username telegram anda kosong, silahkan buat username telegram kembali');
      }
   }
});



$mkbot->on('callback', function ($command) {

   $message           = Bot::message();
   $id                = $message['from']['id'];
   $usernamepelanggan = $message['from']['username'];
   $namatele          = $message['from']['first_name'];
   $chatidtele        = $message["message"]['chat']['id'];
   $message_idtele    = $message["message"]["message_id"];

   include('../config/system.conn.php');

   if (has($id)) {
      if (strpos($command, 'Vcr') !== false) {
         $data  = json_decode($voucher_1, true);
         $cekid = "";
         //=========bedah disini 
         foreach ($data as $index => $pocernya) {

            $cekid .= ",Vcr" . $pocernya['id'];
         }
         //=========bedain user create sendiri atau generate

         $pecahkoman = explode(' ', $command);
         $command = $pecahkoman[0];
         $usernamereal = $pecahkoman[1];
         $passwordreal = $pecahkoman[2];

         //=========ambil data diskon

         $diskonreseller = lihatuser($id)['other'];

         //========sampe sini

         if (preg_match('/' . $command . '/i', $cekid)) {
            $API = new routeros_api();

            foreach ($data as $datas => $getdata) {
               $getid2         = $getdata['id'];
               $princevoc      = $getdata['price'];
               $profile        = $getdata['profile'];
               $length         = $getdata['length'];
               $vouchername    = $getdata['Voucher'];
               $markup         = $getdata['markup'];
               $server         = $getdata['server'];
               $type           = $getdata['type'];
               $typechar       = $getdata['typechar'];
               $Color          = $getdata['Color'];
               $limituptime    = $getdata['Limit'];
               $prefixvc       = $getdata['prefix'];
               $limit_download = toBytes($getdata['limit_download']);
               $limit_upload   = toBytes($getdata['limit_upload']);
               $limit_total    = toBytes($getdata['limit_total']);

               //===========jika diskon diatas 0, maka gunakan data diskon, jika diskon 0 maka gunakan markup
               if ($diskonreseller > 0) {

                  $markup = ($princevoc * $diskonreseller) / 100;
               }
               // ambil data uplink
               $id_uplink  = lihatuser($id)['markuplast'];
               $datareseller    = namareseller($id_uplink);
               // jika uplink tersedia maka munculkan fee uplink
               if ($datareseller) {
                  $fee_uplink = 0.1 * $markup;
               }

               if ($command == 'Vcr' . $getid2) {
                  if (sisasaldo($id, ($princevoc - $markup + $fee_uplink)) == true) {
                     $limitsaldo .= "Maaf saldo anda tidak mencukupi untuk melakukan pembelian voucher\n";

                     $options = [
                        'chat_id' => $chatidtele,
                        'message_id' => (int) $message['message']['message_id'],
                        'text' => $limitsaldo,
                        'reply_markup' => json_encode([
                           'inline_keyboard' => [
                              [
                                 ['text' => '🔙 Back', 'callback_data' => 'Menu'],
                              ],
                           ]
                        ]),
                        'parse_mode' => 'html'

                     ];

                     Bot::editMessageText($options);
                  } else {
                     $sendupdate = "";
                     $sendupdate .= "<code>  Beli Voucher " . rupiah($princevoc) . "   </code>\n";
                     $sendupdate .= "<code>========================</code>\n";
                     $sendupdate .= "<code>  ID User  :</code> <code>$id</code>\n";
                     $sendupdate .= "<code>  Username :</code> @$usernamepelanggan\n";
                     $sendupdate .= "<code>  Status   : Pending </code>\n";
                     $sendupdate .= "<code>========================</code>\n";
                     $sendupdate .= "Mohon ditunggu Voucher akan segera dibuat\n";

                     $options = [
                        'chat_id' => $chatidtele,
                        'message_id' => (int) $message['message']['message_id'],
                        'text' => $sendupdate,
                        'parse_mode' => 'html'

                     ];

                     Bot::editMessageText($options);

                     $delete = [
                        'chat_id' => $chatidtele,
                        'message_id' => (int) $message['message']['message_id'],
                     ];
                     sleep(1);
                     Bot::deleteMessage($delete);

                     if (empty($pecahkoman[1])) {

                        if ($type == 'up') {
                           $usernamereal = $prefixvc . (make_string($length, $typechar));
                           $passwordreal = make_string($length, $typechar);
                        } else {
                           $usernamereal = $prefixvc . (make_string($length, $typechar));
                           $passwordreal = $usernamereal;
                        }
                     }

                     switch ($limituptime) {
                        case null:
                           $limituptimereal = '00:00:00';
                           break;
                        case '00:00:00':
                           $limituptimereal = '00:00:00';
                           break;
                        default:
                           $limituptimereal = $limituptime;

                           if (strpos(strtolower($limituptimereal), 'h') !== false) {
                              $uptime = str_replace('h', ' Jam', $limituptime);
                           } elseif (strpos(strtolower($limituptime), 'd') !== false) {
                              $uptime = str_replace('d', ' Hari', $limituptime);
                           }

                           $echoexperid .= "<code>  Experid    :</code> <code>{$uptime}</code>\n";
                           break;
                     }

                     if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
                        $add_user_api = $API->comm("/ip/hotspot/user/add", [
                           "server" => $server,
                           "profile" => $profile,
                           "name" => $usernamereal,
                           "limit-uptime" => $limituptimereal,
                           "limit-bytes-out" => $limit_upload,
                           "limit-bytes-in" => $limit_download,
                           "limit-bytes-total" => $limit_total,
                           "password" => $passwordreal,
                           "comment" => "| ID : $usernamepelanggan | voc : $vouchername (" . rupiah($princevoc) . ") | tgl : " . date('d-m-Y') . " | MIKBOTAM |",
                        ]);

                        $id_text      = getid();
                        $array_text   = ngambiltext($id_text);
                        $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
                        $array_de     = json_decode($array_text, true);
                        $vc_kaki    = $array_de['vc_footer'];

                        if (empty($vc_kaki)) {
                           $vc_kaki = "-";
                        }

                        if ($limit_total == "0") {
                           $limit_total2 = 'Unlimited';
                        } else {
                           $panjangbyte = strlen($limit_total);
                           if ($panjangbyte > 9) {
                              $potongpanjang = $panjangbyte - 8;
                              $ambilkuotagb  = substr($limit_total, 0, $potongpanjang);
                              $ambilkomagb   = substr($ambilkuotagb, -1);
                              $ambildepangb  = substr($ambilkuotagb, 0, -1);
                              $limit_total2  = $ambildepangb . ',' . $ambilkomagb . ' Gb';
                           } else if ($panjangbyte < 10 && $panjangbyte > 6) {
                              $potongpanjang = $panjangbyte - 5;
                              $ambilkuotagb  = substr($limit_total, 0, $potongpanjang);
                              $ambilkomagb   = substr($ambilkuotagb, -1);
                              $ambildepangb  = substr($ambilkuotagb, 0, -1);
                              $limit_total2  = $ambildepangb . ',' . $ambilkomagb . ' Mb';
                           } else {

                              $limit_total2  = $limit_total2 . ' Bytes';
                           }
                        }

                        if ($type == 'up') {
                           $caption = "";
                           $caption .= "<code>         VOUCHER         </code>\n";
                           $caption .= "<code>=========================</code>\n";
                           $caption .= "<code>  ID         : $add_user_api</code>\n";
                           $caption .= "<b>  Username   : $usernamereal</b>\n";
                           $caption .= "<b>  Password   : $passwordreal</b>\n";
                           //$caption .= $echoexperid;
                           $caption .= "<code>=========================</code>\n";
                           $caption .= "<code>Paket Vc     : $vouchername </code>\n";
                           $caption .= "<code>Harga Vc     : " . rupiah($princevoc) . " </code>\n";
                           $caption .= "<code>Kuota        : $limit_total2 </code>\n";
                           $caption .= "<code>=========================</code>\n";
                           $caption .= "<code>" . $vc_kaki . "</code>\n";
                           $caption .= "<code>=========================</code>\n";
                        } else {
                           $caption = "";
                           $caption .= "<code>         VOUCHER         </code>\n";
                           $caption .= "<code>=========================</code>\n";
                           $caption .= "<code>  ID         : $add_user_api</code>\n";
                           $caption .= "<b>  ID Voucher : $usernamereal</b>\n";
                           //$caption .= $echoexperid;
                           $caption .= "<code>=========================</code>\n";
                           $caption .= "<code>Paket Vc     : $vouchername </code>\n";
                           $caption .= "<code>Harga Vc     : " . rupiah($princevoc) . " </code>\n";
                           $caption .= "<code>Kuota        : $limit_total2 </code>\n";
                           $caption .= "<code>=========================</code>\n";
                           $caption .= "<code>" . $vc_kaki . "</code>\n";
                           $caption .= "<code>=========================</code>\n";
                        }

                        //cek apakah ada kesalahan pada setting voucher.
                        $cekvalidasiadd = json_encode($add_user_api);

                        if (strpos(strtolower($cekvalidasiadd), '!trap')) {
                           //salah maka bot akan dianggap salah
                           $ganguan = true;
                        } else {

                           //benar maka bot akan send voucher

                           //cek dnsname sudah ada http belum?
                           if (strpos($dnsname, 'http://') !== false) {
                              $url = "$dnsname/login?username=$usernamereal&password=$passwordreal";
                           } else {
                              $url = "http://$dnsname/login?username=$usernamereal&password=$passwordreal";
                           }

                           //==========OPSI GANTI LOGO, DIMULAI DARI SINI
                           $id_text      = getid();
                           $ambil_text   = ngambiltext($id_text);
                           $array_de     = json_decode($array_text, true);
                           $vc_logo      = $array_de['vc_logo'];
                           $vc_url       = $array_de['vc_url'];

                           $kirimget   = "username=$usernamereal&password=$passwordreal&profile=$profile&reseller=$id&qrcode=no&harga=$princevoc&timelimit=$limituptimereal&datalimit=$limit_total";

                           $kirimgetqr = "username=$usernamereal&password=$passwordreal&profile=$profile&reseller=$id&qrcode=yes&harga=$princevoc&timelimit=$limituptimereal&datalimit=$limit_total";
                           $domain     = $_SERVER['HTTP_HOST'];

                           if (!isset($vc_url)) {
                              $vc_url  = "https://" . $domain . "/img/logo.png";
                           }

                           if ($vc_logo == "3") {

                              $qrcode     = "https://www.rumahpetir.com/imgtele/hanyalogo.php?gambar=" . $vc_url;


                              $options = [
                                 'chat_id' => $chatidtele,
                                 'caption' => $caption,
                                 'reply_markup' => json_encode(
                                    ['inline_keyboard' => [
                                       [
                                          ['text' => 'cetak voucher', 'url' => 'https://' . $domain . '/response/cetak.php?' . $kirimget],
                                       ],
                                       [
                                          ['text' => 'cetak voucher QR', 'url' => 'https://' . $domain . '/response/cetak.php?' . $kirimgetqr],
                                       ]
                                    ]]
                                 ),

                                 'parse_mode' => 'html'
                              ];
                              $succes = Bot::sendPhoto($qrcode, $options);
                           } else if ($vc_logo == "2") {

                              $options = [
                                 'chat_id' => $chatidtele,
                                 'caption' => $caption,
                                 'reply_markup' => json_encode(
                                    ['inline_keyboard' => [
                                       [
                                          ['text' => 'cetak voucher', 'url' => 'https://' . $domain . '/response/cetak.php?' . $kirimget],
                                       ],
                                       [
                                          ['text' => 'cetak voucher QR', 'url' => 'https://' . $domain . '/response/cetak.php?' . $kirimgetqr],
                                       ]
                                    ]]
                                 ),

                                 'parse_mode' => 'html'
                              ];
                              $succes = Bot::sendMessage($caption, $options);
                           } else {
                              // $qrcode     = 'https://www.rumahpetir.com/kotak/header.php?warna=' . $Color . '&voc=' . $vouchername;
                              $qrcode = "https://www.rumahpetir.com/imgtele/final.php?warna=" . $Color . "&logo=" . $vc_url . "&namapaket=" . $vouchername . "&dnsname=" . $dnsname . "&username=" . $usernamereal . "&password=" . $passwordreal . "&typevc=" . $type . "&url=" . $url;
                              // $qrcode = "https://www.rumahpetir.com/imgtele/final.php?warna=fff000&logo=http://www.rumahpetir.com/imgtele/logo.png&namapaket=PAKETASIK&dnsname=waru-hotspot&username=paijo&password=123123&typevc=up&url=http://waru.hotspot/login?username=abc&password=acd";

                              //http://localhost/3_2_MITHA/response/cetak.php?username=mitha&password=aaaal&profile=5mbps_7hari&reseller=tekinamaku&qrcode=yes&harga=10000&timelimit=0&datalimit=0

                              //$domain     = 'waru.rumahpetir.com'; // untuk tester, diarahkan ke server tester
                              $options = [
                                 'chat_id' => $chatidtele,
                                 'caption' => $caption,
                                 'reply_markup' => json_encode(
                                    ['inline_keyboard' => [
                                       [
                                          ['text' => 'cetak voucher', 'url' => 'https://' . $domain . '/response/cetak.php?' . $kirimget],
                                       ],
                                       [
                                          ['text' => 'cetak voucher QR', 'url' => 'https://' . $domain . '/response/cetak.php?' . $kirimgetqr],
                                       ]
                                    ]]
                                 ),
                                 'parse_mode' => 'html',
                              ];
                              $succes = Bot::sendPhoto($qrcode, $options);
                           }
                        }

                        $success = json_decode($succes, true);
                        if ($success['ok'] !== true) {
                           $errorprint = true;
                        }
                     } else {
                        $ganguan = true;
                     }

                     break;
                  }
               }
            }

            if (!empty($ganguan)) {
               //remove User jika terjadi error
               if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
                  $ARRAY2 = $API->comm("/ip/hotspot/user/remove", ["numbers" => $add_user_api,]);
               }

               $gagal .= "<code>  Beli Voucher " . rupiah($princevoc) . "   </code>\n";
               $gagal .= "<code>========================</code>\n";
               $gagal .= "<code>  ID User  :</code> <code>$id</code>\n";
               $gagal .= "<code>  Username :</code> @$usernamepelanggan\n";
               $gagal .= "<code>  Status   : invalid Conect Server </code>\n";
               $gagal .= "<code>========================</code>\n";
               $gagal .= "Maaf koneksi ke mikrotik mengalami gangguan silahkan hubungi admin atau tunggu 5 menit dan generate ulang\n";
               $options = [
                  'chat_id' => $chatidtele,
                  'parse_mode' => 'html'

               ];
               $keterangan = 'gagal';
               Bot::sendMessage($gagal, $options);

               $set = belivoucher($id, $usernamepelanggan, '0', '0', $usernamereal, $passwordreal, $profile, $keterangan);
            } elseif (!empty($errorprint)) {

               //remove User jika terjadi error
               if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
                  $ARRAY2 = $API->comm("/ip/hotspot/user/remove", ["numbers" => $add_user_api,]);
               }

               $gagalprint .= "";
               $gagalprint .= "<code>   Beli Voucher " . rupiah($princevoc) . "  </code>\n";
               $gagalprint .= "<code>========================</code>\n";
               $gagalprint .= "<code>  ID User  :</code> <code>$id</code>\n";
               $gagalprint .= "<code>  Username :</code> @$usernamepelanggan\n";
               $gagalprint .= "<code>  Status   : INVALID Print Voucher </code>\n";
               $gagalprint .= "<code>========================</code>\n";
               $gagalprint .= "Maaf koneksi ke mikrotik mengalami gangguan silahkan hubungi admin atau tunggu 5 menit dan generate ulang\n";
               $options    = ['chat_id' => $chatidtele, 'parse_mode' => 'html'];
               $keterangan = 'gagalprint';
               Bot::sendMessage($gagalprint, $options);

               $set = belivoucher($id, $usernamepelanggan, '0', '0', $usernamereal, $passwordreal, $profile, $keterangan);
            } else if (!empty($succes)) {

               //===================>>NAMBAH MENU SISA SALDO==============
               $angka = lihatsaldo($id);
               $Success = "";
               $Success = "<code>      INFO RESELLER $id_uplink      </code>\n";
               $Success .= "<code>========================</code>\n";
               $Success .= "<code>Paket Voucher : $vouchername</code>\n";
               $Success .= "<code>Status        : Success </code>\n";
               $Success .= "<code>------------------------</code>\n";
               $Success .= "<code>Hrga Reseller : " . rupiah($princevoc - $markup) . "</code>\n";
               $Success .= "<code>Fee Reseller  : " . rupiah($markup - $fee_uplink) . "</code>\n";
               if (isset($fee_uplink)) {
                  $Success .= "<code>Fee Uplink    : " . rupiah($fee_uplink) . "</code>\n";
               }
               $Success .= "<code>Harga Voucher : </code><b>" . rupiah($princevoc) . "</b>\n";
               $Success .= "<code>------------------------</code>\n";
               $Success .= "<code>SALDO AWAL    : " . rupiah($angka) . "</code>\n";
               $Success .= "<code>SISA SALDO    : </code><b>" . rupiah($angka - $princevoc + $markup) . "</b>\n";
               $Success .= "<code>------------------------</code>\n";
               $Success .= "<code>ID Reseller   : </code> <code>$id</code>\n";
               $Success .= "<code>Username      : </code> @$usernamepelanggan\n";
               $Success .= "<code>========================</code>\n";

               if (isset($Success)) {
                  $saldoawal   = lihatsaldo($id);
                  $keterangan  = 'Success';
                  $markupakhir = minus($princevoc, $markup);
                  $set         = belivoucher($id, $usernamepelanggan, $markupakhir, $markup, $usernamereal, $passwordreal, $profile, $keterangan);
                  $angka       = lihatsaldo($id);

                  $options     = [
                     'chat_id' => $chatidtele,
                     'reply_markup' => json_encode([
                        'inline_keyboard' => [
                           [
                              ['text' => '⏱ History', 'callback_data' => 'VMarkup|' . $princevoc . '|' . $markup . '|' . $markupakhir . '|' . $saldoawal . '|' . $angka . ''],
                              ['text' => '🔙 Back', 'callback_data' => 'Menu'],
                           ], [
                              ['text' => '💰 Cek Saldo', 'callback_data' => 'notifsaldo'],
                           ],
                        ]
                     ]),
                     'parse_mode' => 'html'

                  ];

                  Bot::sendMessage($Success, $options);
                  $id_uplink = '';
               }
            }
         } else {
            $Success = "";
            $Success = "Maaf voucher ini tidak lagi tersedia \n";

            $options = [
               'chat_id' => $chatidtele,
               'parse_mode' => 'html'

            ];

            Bot::sendMessage($Success, $options);
         }
      } elseif ($command == 'Menu') {
         $id_text      = getid();
         $array_text   = ngambiltext($id_text);
         $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
         $array_de     = json_decode($array_text, true);
         $text_mehe    = $array_de['menu_header'];

         if (empty($text_mehe)) {
            $text_mehe = '-';
         }
         $data = json_decode($voucher_1, true);
         $text = "";
         //filter reseller dengan vc tertentu
         $resvcgrup = lihatuser($id)['othertree'];

         if (!empty($resvcgrup) && $resvcgrup != "all") {
            $arraybaru = [];
            foreach ($data as $indeks) {
               if (preg_match('/' . $resvcgrup . '/', $indeks['grupvc'])) {
                  $arraybaru = array_merge($arraybaru, [$indeks]);
               }
            }
            $data = $arraybaru;
         } else if (empty($resvcgrup)) {
            $arraybaru = [];
            foreach ($data as $indeks) {
               if (preg_match('/default/', $indeks['grupvc'])) {
                  $arraybaru = array_merge($arraybaru, [$indeks]);
               }
            }
            $data = $arraybaru;
         }
         if (!empty($data)) {
            //========header====
            $text .= $text_mehe;
            //==================   
            $text .= "\n============\n";
            $text .= "<i>Silahkan Pilih voucher dibawah ini</i>\n\n";
            $text .= "<code>Daftar Voucher :</code>\n";
            foreach ($data as $hargas) {
               $textlist = $hargas['Text_List'];
               $jenisvoucher = $hargas['Voucher'];
               $text .= "<code>[$jenisvoucher] : $textlist </code>\n";
            }

            //============mulai sini
            $splitarray = array_chunk($data, 2);
            $send = [];
            foreach ($splitarray as $index => $pocersatuan) {

               $database1 = ['text' => $pocersatuan[0]['Voucher'] . '', 'callback_data' => 'verifikasi' . $pocersatuan[0]['id'] . ''];

               $database2 = ['text' => $pocersatuan[1]['Voucher'] . '', 'callback_data' => 'verifikasi' . $pocersatuan[1]['id'] . ''];

               $barispocer = array_filter([$database1, $database2]);

               array_push($send, $barispocer);
            }
            //===========sampe sini
            $menu_idakhir = [
               ['text' => '💰 Cek Saldo', 'callback_data' => 'notifsaldo'],
               ['text' => '🔖 iNFORMASI', 'callback_data' => 'informasi'],
            ];
            //==========modif disini

            array_push($send, $menu_idakhir);

            //=========sampe sini

            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'reply_markup' => json_encode(['inline_keyboard' => $send]),
               'parse_mode' => 'html'

            ];
         } else {

            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => "Maaf System Tidak Terdapat Voucher",
               'parse_mode' => 'html'

            ];
         }
         Bot::editMessageText($options);
      } elseif ($command == 'ceksaldo') {

         if (has($id) == false) {
            $text = 'Anda tidak terdaftar silahkan daftar terlebih dahulu ke admin atau klik /daftar';
         } else {
            $angka = lihatsaldo($id);
            $text  = "<code>      Informasi Saldo</code>\n";
            $text .= "<code>========================</code>\n";
            $text .= "<code>  ID User : $id</code>\n";
            $text .= "<code>  Name    : @$usernamepelanggan</code>\n";
            $text .= "<code>  Saldo   : " . rupiah($angka) . "</code>\n";
            $text .= "<code>========================</code>\n";
         }

         $options = [
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'reply_markup' => json_encode([
               'inline_keyboard' => [
                  [
                     ['text' => '🔙 Back', 'callback_data' => 'Menu'],
                  ],
               ]
            ]),
            'parse_mode' => 'html'

         ];

         Bot::editMessageText($options);
      } elseif ($command == 'informasi') {
         $id_text      = getid();
         $array_text   = ngambiltext($id_text);
         $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
         $array_de     = json_decode($array_text, true);
         $informasinya = $array_de['informasi'];

         if (empty($informasinya)) {
            $informasinya = "belum ada informasi";
         }

         $text    = $informasinya;

         $options = [
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'reply_markup' => json_encode([
               'inline_keyboard' => [
                  [
                     ['text' => 'Back', 'callback_data' => 'Menu'],
                  ],
               ]
            ]),
            'parse_mode' => 'html'

         ];

         Bot::editMessageText($options);
      } elseif (strpos($command, 'tps') !== false) {
         if (preg_match('/^tps/', $command)) {
            $cekdata       = explode('|', $command);
            $cek           = $cekdata[1];
            $id_text      = getid();
            $array_text   = ngambiltext($id_text);
            $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
            $array_de     = json_decode($array_text, true);
            $infodepo     = $array_de['info_depo'];
            $text .= "Permintaan deposit  sebesar " . rupiah($cek) . " sudah kami terima, \nSilahkan kirimkan foto bukti pembayaran  disertai dengan Caption #konfirmasi deposit $cek\n\n" . $infodepo . "\n\nKonfirmasi selambatnya 2 jam setelah permintaan deposit";
            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'parse_mode' => 'html'

            ];

            Bot::editMessageText($options);

            $textsend = "";
            $textsend .= "<code>User :  </code>@$usernamepelanggan \n";
            $textsend .= "<code>ID   : </code> <code>$id </code>\n";
            $textsend .= "<code>Request pengisian saldo </code>\n";
            $textsend .= "<code>Nominal :" . rupiah($cek) . "</code>\n";
            $textsend .= "<code>Silahkan tindak lanjut \nAtau Hubungi user </code> @$usernamepelanggan \n\n";
            $textsend .= "Dengan Menekan tombol dibawah ini saldo user otomatis terisi  ";

            $kirimpelangan = [
               'chat_id' => $id_own,
               'reply_markup' => json_encode([
                  'inline_keyboard' => [
                     [
                        ['text' => 'QUICK TOP UP', 'callback_data' => '12'],
                     ],
                     [
                        ['text' => '' . rupiah($cek) . '', 'callback_data' => 'tp|' . $cek . '|' . $id . '|' . $usernamepelanggan . ''],
                     ],
                     [
                        ['text' => 'OR COSTUM', 'callback_data' => '12'],
                     ],
                     [
                        ['text' => '10000', 'callback_data' => 'tp|10000|' . $id . '|' . $usernamepelanggan . ''],
                        ['text' => '15000', 'callback_data' => 'tp|15000|' . $id . '|' . $usernamepelanggan . ''],
                        ['text' => '20000', 'callback_data' => 'tp|20000|' . $id . '|' . $usernamepelanggan . ''],
                     ],
                     [

                        ['text' => '25000', 'callback_data' => 'tp|25000|' . $id . '|' . $usernamepelanggan . ''],
                        ['text' => '30000', 'callback_data' => 'tp|30000|' . $id . '|' . $usernamepelanggan . ''],
                        ['text' => '50000', 'callback_data' => 'tp|50000|' . $id . '|' . $usernamepelanggan . ''],
                     ],
                     [

                        ['text' => '100000', 'callback_data' => 'tp|100000|' . $id . '|' . $usernamepelanggan . ''],
                        ['text' => '150000', 'callback_data' => 'tp|150000|' . $id . '|' . $usernamepelanggan . ''],
                        ['text' => '200000', 'callback_data' => 'tp|200000|' . $id . '|' . $usernamepelanggan . ''],
                     ],
                     [

                        ['text' => 'Reject Request', 'callback_data' => 'tp|reject|' . $id . '|reject']
                     ],

                  ]
               ]),
               'parse_mode' => 'html'

            ];

            Bot::sendMessage($textsend, $kirimpelangan);
         }
      } elseif (strpos($command, 'tp') !== false) {

         if (preg_match('/^tp/', $command)) {
            $cekdata     = explode('|', $command);
            $cekkodeunik = $cekdata[0];
            $jumlah      = $cekdata[1];
            $iduser      = $cekdata[2];
            $namauser    = $cekdata[3];
            $text        = "";
            if ($jumlah == 'reject') {

               $text = "Masa tunggu konfirmasi deposit telah habis permintaan deposit telah kadaluarsa.\nSilahkan konfirmasi deposit selambatnya 2 jam setelah Request Deposit.\n\nTerima kasih.";
               //kirim ke user
               $kirimpelangan = [
                  'chat_id' => $iduser,
                  'parse_mode' => 'html'

               ];
               Bot::sendMessage($text, $kirimpelangan);

               $options = [
                  'chat_id' => $chatidtele,
                  'message_id' => (int) $message['message']['message_id'],
                  'text' => 'Reject Deposit berhasil',
                  'parse_mode' => 'html'
               ];
               Bot::editMessageText($options);
            } else {

               if ($id == $id_own) {
                  if (!empty($iduser) && !empty($jumlah)) {
                     if (has($iduser) == false) {
                        $text = 'Data id ' . $iduser . 'tidak terdaftar silahkan periksa kembali';
                     } else {

                        if (preg_match('/^[0-9]+$/', $jumlah)) {
                           if (strlen($jumlah) < 8) {
                              $text = topupresseller($iduser, $jumlah, $id_own);

                              //kirim ke user
                              $kirimpelangan = [
                                 'chat_id' => $iduser,
                                 'reply_markup' => json_encode([
                                    'inline_keyboard' => [
                                       [
                                          ['text' => '�� Beli Voucher', 'callback_data' => 'Menu'],
                                          ['text' => '📛 Promo Hot', 'callback_data' => 'informasi'],
                                       ],
                                    ]
                                 ]),
                                 'parse_mode' => 'html'
                              ];
                              Bot::sendMessage($text, $kirimpelangan);
                              //
                           } else {

                              //==============================>>>UBAH MAXIMAL TOP UP
                              $text = 'Maaf Maksimal Top Up Rp 9.999.999.00';
                           }
                        } else {
                           $text = 'Maaf nominal tidak berupa angka ';
                        }
                     }
                  } else {
                     $text = "Maaf format data salah ";
                  }
               } else {
                  $text = "Maaf..! Aksess Hanya untuk Administator";
               }
               $options = [
                  'chat_id' => $chatidtele,
                  'message_id' => (int) $message['message']['message_id'],
                  'text' => $text,
                  'parse_mode' => 'html'
               ];
               Bot::editMessageText($options);
            }
         }
      } elseif (strpos($command, 'VMarkup') !== false) {
         $cekdata     = explode('|', $command);
         $cekkodeunik = $cekdata[0];
         $princevoc   = $cekdata[1];
         $markup      = $cekdata[2];
         $markupakhir = $cekdata[3];
         $saldoawal   = $cekdata[4];
         $saldo       = $cekdata[5];
         $text        = "";

         if (!empty($princevoc)) {
            $text .= "<code>Saldo Awal    = </code>" . rupiah($saldoawal) . " \n";
            $text .= "<code>Voucher Price = </code>" . rupiah($princevoc) . " \n";
            $text .= "<code>Total Markup  = </code>" . rupiah($markup) . " \n";
            $text .= "#  Voucher-Markup \n";
            $text .= "# " . rupiah($princevoc) . " - " . rupiah($markup) . " = " . rupiah($markupakhir) . " \n";
            $text .= "# Saldoawal-Markup Akhir \n";
            $text .= "# " . rupiah($saldoawal) . " - " . rupiah($markupakhir) . " = " . rupiah($saldo) . " \n";
            $text .= "<b>Sisa saldo </b> : " . rupiah($saldo) . " \n";
         } else {
            $text = "Maaf format data salah ";
         }

         $options = [
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'reply_markup' => json_encode([
               'inline_keyboard' => [
                  [
                     ['text' => '🔙 Back', 'callback_data' => 'Menu'],
                  ],
               ]
            ]),
            'parse_mode' => 'html'

         ];

         Bot::editMessageText($options);
      } elseif (strpos($command, 'notifsaldo') !== false) {

         $id_text      = getid();
         $array_text   = ngambiltext($id_text);
         $array_text   = preg_replace('/ENTER/', '\n', trim($array_text));
         $array_de     = json_decode($array_text, true);
         $saldo_kaki   = $array_de['saldo_footer'];

         if (empty($saldo_kaki)) {
            $saldo_kaki = '-';
         }


         if (has($id) == false) {
            $text = 'Anda tidak terdaftar silahkan daftar terlebih dahulu ke admin atau klik /daftar';
         } else {
            $angka = lihatsaldo($id);
            if ($angka < 5000) {
               $text = "ID anda  : $id \nSisa saldo anda  : " . rupiah($angka) . "\n⚠ Segera isi ulang saldo anda";
            } else {
               $text = "ID anda  : $id \nSisa saldo anda  : " . rupiah($angka);
            }
            $text .= "\n" . $saldo_kaki;
         }
         Bot::answerCallbackQuery($text, $options = ['show_alert' => true]);

         //---- call back untuk /delreport----

         //======verifikasi sebelum cetak vc
      } elseif (strpos($command, 'verifikasi') !== false) {

         $id_text       = getid();
         $data          = json_decode($voucher_1, true);

         $pecahkoman = explode(' ', $command);
         $datavc     = $pecahkoman[0];
         $datakirim  = $pecahkoman[1] . ' ' . $pecahkoman[2];
         $dataidvc   = explode('verifikasi', $datavc)[1];


         foreach ($data as $datas => $getdata) {
            if ($dataidvc == $getdata['id']) {
               $getid2         = $getdata['id'];
               $vouchername    = $getdata['Voucher'];
               $textlist       = $getdata['Text_List'];
            }
         }
         $text          = "Konfirmasi\n";
         $text          .= "Apakah anda akan generate voucher dengan detail :\n";
         $text          .= "<b>$vouchername : $textlist</b>\n";

         $send = [
            [
               ['text' => 'YA', 'callback_data' => 'Vcr' . $dataidvc . ' ' . $datakirim]
            ],
            [
               ['text' => 'BATAL', 'callback_data' => 'cancel'],
            ]
         ];

         $options = [
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'reply_markup' => json_encode(['inline_keyboard' => $send]),
            'parse_mode' => 'html'

         ];

         Bot::editMessageText($options);
         //=================batas verifikasi mitha 3.2
         //=================verifikasi topup
      } elseif (strpos($command, 'rts') !== false) {

         $iduser      = explode('rts', $command)[0];
         $nominal     = explode('rts', $command)[1];
         $datauser    = lihatuser($iduser);



         $text          = "Konfirmasi\n";
         $text          .= "Apakah anda akan TOPUP reseller dengan detail :\n";
         $text          .= "<b>" . $datauser['nama_seller'] . " ($iduser) : " . rupiah($nominal) . '</b>';

         $send = [
            [
               ['text' => 'YA', 'callback_data' => $iduser . 'MITHATPU' . $nominal]
            ],
            [
               ['text' => 'BATAL', 'callback_data' => 'cancel'],
            ]
         ];

         $options = [
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'reply_markup' => json_encode(['inline_keyboard' => $send]),
            'parse_mode' => 'html'

         ];

         Bot::editMessageText($options);
         //=================eksekusi TOP UP mitha 3.2
      } elseif (strpos($command, 'MITHATPU') !== false) {

         $iduser3     = explode('MITHATPU', $command)[0];
         $nominal3    = explode('MITHATPU', $command)[1];

         $text        = topupresseller($iduser3, $nominal3, $id_own);




         $options = [
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'parse_mode' => 'html'

         ];

         $kirimpelangan = [
            'chat_id' => $iduser3,
            'reply_markup' => json_encode([
               'inline_keyboard' => [
                  [
                     ['text' => '🔎 Beli Voucher', 'callback_data' => 'Menu'],
                     ['text' => '📛 Promo Hot', 'callback_data' => 'informasi'],
                  ],
               ]
            ]),
            'parse_mode' => 'html'

         ];
         Bot::sendMessage($text, $kirimpelangan);

         Bot::editMessageText($options);
         //=================batas verifikasi mitha 3.2
         //=================pppoe mitha 3.2
      } else // callback untuk PPPoE
         $hariini = strtotime('now');

      if (strpos($command, 'tombol : ') !== false) {
         bot::sendChatAction('typing');
         $API = new routeros_api();
         $ambilcmd   = explode("tombol : ", $command)[1];
         //data halaman
         $ambilhal   = explode(" || ", $ambilcmd)[0];
         $halnext    = $ambilhal + 1;
         $halback    = $ambilhal - 1;
         //ambil semua index yang ada
         $semuaindex = explode(" || ", $ambilcmd)[1];
         //pecah semua index menjadi array
         $pecahindex = explode(" | ", $semuaindex);
         //ambil nilai index paling belakang
         $indexblkng = end($pecahindex);
         //buang index paling belakang
         array_pop($pecahindex);

         $indextombol = "";
         foreach ($pecahindex as $idx => $idxbr) {
            $indextombol .= $idxbr . " | ";
         }
         $indextombol = substr($indextombol, 0, -3);

         if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            $semuasecret = $API->comm('/ppp/secret/getall');
            $secretarray    = [];
            $i              = 0;
            $arraychunk     = 2;
            $arraydalam     = [];
            $tanda          = 0;
            $jumlahsecret   = count($semuasecret);

            for ($indexsecret = $indexblkng; $indexsecret < $jumlahsecret;) {
               $secret = $semuasecret[$indexsecret];
               $secretkomen = isset($secret['comment']) ? $secret['comment'] : '';
               if (strpos($secretkomen, "PPPoE-MITHA-MIKBOTAM") !== false) {
                  $comment = explode(" | ", $secretkomen);
                  $stkomen = explode("status : ", $comment[0])[1];
                  if ($stkomen == 'daftar') {
                     $status = "🔵 ";
                  } else if ($stkomen == 'aktif') {
                     $status = "🟢 ";
                  } else if ($stkomen == 'expired') {
                     $status = "🔴 ";
                  }
                  $simpantext     = ['text' => $status . $secret['name'], 'callback_data' => 'idsecret : ' . $secret['.id'] . " ||| " . $ambilcmd];
                  $arraydalam[$tanda] = $simpantext;

                  if ($tanda == $arraychunk - 1) {
                     array_push($secretarray, $arraydalam);
                     $tanda = 0;
                     $arraydalam = [];
                  } else {
                     $tanda++;
                  }

                  $i++;
               }

               if ($i == 11) {
                  if ($ambilhal != 1) {
                     $arraydalam[0]['text'] = "<< PREV";
                     $arraydalam[0]['callback_data'] = "tombol : " . $halback . " || " . $indextombol;
                     $arraydalam[1]['text'] = "NEXT >>";
                     $arraydalam[1]['callback_data'] = "tombol : " . $halnext . " || " . $indextombol . " | " . $indexblkng . " | " . $indexsecret;
                  } else {
                     $arraydalam[0]['text'] = "NEXT >>";
                     $arraydalam[0]['callback_data'] = "tombol : " . $halnext . " || " . $indextombol . " | " . $indexblkng . " | " . $indexsecret;
                  }
                  array_push($secretarray, $arraydalam);
                  break;
               } else if ($indexsecret == $jumlahsecret - 1 && !isset($arraydalam[1]) && isset($arraydalam[0]) && $ambilhal != 1) {
                  array_push($secretarray, $arraydalam);
                  $tombolback = [['text' => "<< PREV", "callback_data" => "tombol : " . $halback . " || " . $indextombol]];
                  array_push($secretarray, $tombolback);
               } else if ($indexsecret == $jumlahsecret - 1 && $ambilhal != 1) {
                  $tombolback = [['text' => "<< PREV", "callback_data" => "tombol : " . $halback . " || " . $indextombol]];
                  array_push($secretarray, $tombolback);
               }
               $indexsecret++;
            }
            $send = $secretarray;
            $text = "berikut daftar client PPPoE MITHA : \n";
            $text .= "<code>";
            $text .= "=====================\n";
            $text .= "🔵 = baru terdaftar\n";
            $text .= "🟢 = status aktif\n";
            $text .= "🔴 = status expired\n";
            $text .= "=====================\n";
            $text .= "    halaman : $ambilhal\n";
            $text .= "</code>";

            $options = [
               'reply_markup' => json_encode(['inline_keyboard' => $send]),
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'parse_mode' => 'html'
            ];
         }
         return Bot::editMessageText($options);
      } else if (strpos($command, 'idsecret : ') !== false) {
         bot::sendChatAction('typing');
         $API = new routeros_api();
         $ambilcmd   = explode("idsecret : ", $command)[1];
         $ambilid    = explode(" ||| ", $ambilcmd)[0];
         $ambilback  = explode(" ||| ", $ambilcmd)[1];

         if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            //persiapan data
            $ambilsecret    = $API->comm("/ppp/secret/print", ["?.id" => $ambilid])[0];
            $namasecret     = $ambilsecret['name'];
            $lastlogout     = $ambilsecret['last-logged-out'];
            if ($lastlogout == "jan/01/1970 00:00:00") {
               $lastlogout = 'none';
            }
            $comment        = explode(" | ", $ambilsecret['comment']);
            $stkomen        = explode("status : ", $comment[0])[1];
            if ($stkomen == "aktif" || $stkomen == "daftar") {
               $eksekusi   = "🔴 eksekusi 🔴";
               $dataeks    = "eksekusi";
            } else {
               $eksekusi = "🟢 aktifkan 🟢";
               $dataeks    = "aktifkan";
            }
            $ekstbl         = explode("eksekusi : ", $comment[3])[1];
            $prtuj          = explode("(", $ekstbl);
            $mtdtbl         = $prtuj[0];
            $pttbl          = '';
            if ($mtdtbl == 'pindah-profile') {
               $pttbl = explode(")", $prtuj[1])[0];
            }
            //ambil data schedule untuk masa aktif
            $schexp     = $API->comm("/system/scheduler/print", ['?name' => $namasecret . "-ppp-mitha"])[0];
            $schetgl    = $schexp['start-date'];
            $schwaktu   = substr($schexp['start-time'], 0, -3);
            $schid      = $schexp['.id'];
            $dataexpired = "";
            if (count($comment) > 3) {
               $dataexpired = "$schetgl - $schwaktu | $mtdtbl $pttbl";
            } else {
               $dataexpired = "bukan mitha";
            }

            //text
            $text   =   "<code>\n";
            $text   .=   "Nama       : $namasecret\n";
            $text   .=   "Expired    : $dataexpired\n";
            $text   .=   "LastLogout : $lastlogout\n";
            $text   .=   "Status     : $stkomen\n";
            $text   .=   "</code>\n";

            //tombol

            $send           =  [
               [
                  ['text' => $eksekusi, "callback_data" => "eksekusi : $dataeks |||| $ambilid"],
               ],
               [
                  ['text' => "⬆️ + 1 bulan ⬆️", "callback_data" => "bulan : naiksatu |||| $ambilid"],
               ],
               [
                  ['text' => "⬇️ - 1 bulan ⬇️", "callback_data" => "bulan : turunsatu |||| $ambilid"],
               ],
               [
                  ['text' => "<< BACK", "callback_data" => "tombol : " . $ambilback]
               ],

            ];

            $options = [
               'reply_markup' => json_encode(['inline_keyboard' => $send]),
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'parse_mode' => 'html'
            ];
         }

         return Bot::editMessageText($options);
      } else if (strpos($command, 'eksekusi : ') !== false) {
         bot::sendChatAction('typing');
         $API = new routeros_api();
         $ambilcmd       = explode("eksekusi : ", $command)[1];
         $perintah       = explode(" |||| ", $ambilcmd)[0];
         $ambilid        = explode(" |||| ", $ambilcmd)[1];

         if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            //user secret
            $ambiluser  = $API->comm("/ppp/secret/print", ["?.id" => $ambilid])[0];

            //ambilcomment
            $comment = explode(" | ", $ambiluser['comment']);
            $prlm    = explode("profile : ", $comment[5])[1];
            $ekstbl  = explode("eksekusi : ", $comment[3])[1];
            $prtuj   = explode("(", $ekstbl);
            $mtdtbl  = $prtuj[0];
            $pttbl   = '';
            if ($mtdtbl == 'pindah-profile') {
               $pttbl = explode(")", $prtuj[1])[0];
            }

            //ambil harga dari komen profile
            $komenprofile   = $API->comm("/ppp/profile/print", ["?name" => $prlm])[0]['comment'];
            $pecahprofile   = explode(" | ", $komenprofile);
            $harga          = explode("price : ", $pecahprofile[4])[1];

            //ambil data schedule dan ubah menjadi string
            $schexp     = $API->comm("/system/scheduler/print", ['?name' => $ambiluser['name'] . "-ppp-mitha"])[0];
            $schetgl    = $schexp['start-date'];
            $schwaktu   = substr($schexp['start-time'], 0, -3);
            $schid      = $schexp['.id'];
            $tgl        = date_create_from_format("M/d/Y", $schetgl);
            $tgl2       = date_format($tgl, "m/d/Y");
            $waktunya   = "$tgl2 $schwaktu";
            $nextrun    = strtotime($waktunya);

            if ($perintah == "aktifkan") {
               $komenbaru = str_replace(" status : expired", " status : aktif", $ambiluser['comment']);
               if ($mtdtbl == "disable") {
                  //enable kan secret dan ganti comment
                  $API->write("/ppp/secret/enable", false);
                  $API->write("=.id=" . $ambilid);
                  $API->read();
               } else if ($mtdtbl == "pindah-profile") {
                  $setprofile = $API->comm("/ppp/secret/set", [
                     ".id" => $ambilid,
                     "profile" => $prlm,
                  ]);
               }
               $setkomen = $API->comm("/ppp/secret/set", [
                  ".id" => $ambilid,
                  "comment" => $komenbaru,
               ]);

               //jika waktu skr lebih besar dari waktu next run maka ubah next run schedule
               if ($hariini > $nextrun) {
                  $bulandepan     = strtotime("next Month", $nextrun);
                  $tglblndpn      = date("M/d/Y", $bulandepan);
                  $jamblndpn      = date("H:i:s", $bulandepan);

                  //ubah schedule
                  $gantische      = $API->comm("/system/scheduler/set", [
                     ".id"          => $schid,
                     "start-date"    => $tglblndpn,
                     "start-time"    => $jamblndpn
                  ]);

                  //input data omset ke database
                  $inputdatabase = inputpppoe($harga, $ambiluser['name']);
               }
               $text = "user " . $ambiluser['name'] . " berhasil 🟢 diaktifkan 🟢";
            } else if ($perintah == "eksekusi") {
               if (strpos($ambiluser['comment'], " status : aktif") !== false) {
                  $komenbaru = str_replace(" status : aktif", " status : expired", $ambiluser['comment']);
               } else if (strpos($ambiluser['comment'], " status : daftar") !== false) {
                  $komenbaru = str_replace(" status : daftar", " status : expired", $ambiluser['comment']);
               }
               //kick dari active connection
               $idactive = $API->comm("/ppp/active/print", ["?name" => $ambiluser['name'],])[0]['.id'];
               $kicksecret = $API->comm("/ppp/active/remove", ['.id' => $idactive]);

               if ($mtdtbl == "disable") {
                  //disable kan secret dan ganti comment
                  $API->write("/ppp/secret/disable", false);
                  $API->write("=.id=" . $ambiluser['.id']);
                  $API->read();
               } else if ($mtdtbl == "pindah-profile") {
                  $setprofile = $API->comm("/ppp/secret/set", [
                     ".id" => $ambiluser['.id'],
                     "profile" => $pttbl,
                  ]);
               }
               $setkomen = $API->comm("/ppp/secret/set", [
                  ".id" => $ambiluser['.id'],
                  "comment" => $komenbaru,
               ]);
               $text = "user " . $ambiluser['name'] . " berhasil 🔴 dieksekusi 🔴";
            }
            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'parse_mode' => 'html'
            ];
         }
         return Bot::editMessageText($options);
      } else if (strpos($command, 'bulan : ') !== false) {
         bot::sendChatAction('typing');
         $API = new routeros_api();
         $ambilcmd       = explode("bulan : ", $command)[1];
         $perintah       = explode(" |||| ", $ambilcmd)[0];
         $ambilid        = explode(" |||| ", $ambilcmd)[1];
         if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            //user secret
            $ambiluser  = $API->comm("/ppp/secret/print", ["?.id" => $ambilid])[0];

            //ambilcomment
            $comment = explode(" | ", $ambiluser['comment']);
            $prlm    = explode("profile : ", $comment[5])[1];
            $ekstbl  = explode("eksekusi : ", $comment[3])[1];
            $prtuj   = explode("(", $ekstbl);
            $mtdtbl  = $prtuj[0];
            $pttbl   = '';
            if ($mtdtbl == 'pindah-profile') {
               $pttbl = explode(")", $prtuj[1])[0];
            }

            //ambil harga dari komen profile
            $komenprofile   = $API->comm("/ppp/profile/print", ["?name" => $prlm])[0]['comment'];
            $pecahprofile   = explode(" | ", $komenprofile);
            $harga          = explode("price : ", $pecahprofile[4])[1];

            //ambil data schedule dan ubah menjadi string
            $schexp     = $API->comm("/system/scheduler/print", ['?name' => $ambiluser['name'] . "-ppp-mitha"])[0];
            $schetgl    = $schexp['start-date'];
            $schwaktu   = substr($schexp['start-time'], 0, -3);
            $schid      = $schexp['.id'];
            $tgl        = date_create_from_format("M/d/Y", $schetgl);
            $tgl2       = date_format($tgl, "m/d/Y");
            $waktunya   = "$tgl2 $schwaktu";
            $nextrun    = strtotime($waktunya);

            if ($perintah == "naiksatu") {
               $bulandepan     = strtotime("next Month", $nextrun);
               $tglblndpn      = date("M/d/Y", $bulandepan);
               $jamblndpn      = date("H:i:s", $bulandepan);

               //ubah schedule
               $gantische      = $API->comm("/system/scheduler/set", [
                  ".id"          => $schid,
                  "start-date"    => $tglblndpn,
                  "start-time"    => $jamblndpn
               ]);

               //input data omset ke database
               $inputdatabase = inputpppoe($harga, $ambiluser['name']);

               //pesan telegram
               $text   = "masa aktif user " . $ambiluser['name'] . " berhasil ⬆️ ditambah ⬆️ 1 bulan";
            } else if ($perintah == "turunsatu") {
               $kurangsatubln      = strtotime("last Month", $nextrun);

               if ($hariini < $kurangsatubln) {
                  $blntarget      = strtotime("last Month", $nextrun);
                  $tgltarget      = date("M/d/Y", $blntarget);
                  $jamtarget      = date("H:i:s", $blntarget);

                  //ubah schedule
                  $gantische      = $API->comm("/system/scheduler/set", [
                     ".id"          => $schid,
                     "start-date"    => $tgltarget,
                     "start-time"    => $jamtarget
                  ]);

                  //input data omset ke database
                  $inputdatabase = inputpppoe("-" . $harga, $ambiluser['name']);

                  $text   = "masa aktif user " . $ambiluser['name'] . " berhasil ⬇️ dikurangi ⬇️ 1 bulan";
               } else {
                  $text   = "masa aktif user " . $ambiluser['name'] . " sudah tidak bisa dikurangi lagi";
               }
            }
            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'parse_mode' => 'html'
            ];
         }

         return Bot::editMessageText($options);
         //=============SELESAI CALLBACK PPPoE
         //=============CALLBACK PAYMENT GATEWAY
      } elseif (strpos($command, 'otodepo : ') !== false) {
         //ambil data key
         $domain         = $_SERVER['HTTP_HOST'];
         //$domain         = 'waru.rumahpetir.com'; //untuk tester maka domain diarahkan manual
         $getidmikbotam  = getid();
         $ambildata      = ambilpg($getidmikbotam);
         $datamentah     = json_decode($ambildata, true);
         $apikey         = $datamentah['apikey'];
         $privatekey     = $datamentah['privatekey'];
         $merchantcode   = $datamentah['merchantcode'];
         $simulasi       = $datamentah['simulasi'];
         if ($simulasi == "ya") {
            $simulasi   = "api-sandbox";
         }
         if ($simulasi == "tidak") {
            $simulasi = "api";
         }

         //ambil data callback telegram 
         $pecahsatu      = explode("otodepo : ", $command);
         $pecahfinal     = explode("|", $pecahsatu[1]);
         $nominal        = $pecahfinal[0];
         $metode_bayar   = $pecahfinal[1];
         $idtelenya      = $pecahfinal[2];
         $namatelenya    = $pecahfinal[3];
         $email          = "$namatelenya@$idtelenya.com";
         $nowa           = "$idtelenya";
         // simpan di log
         $idlog          = simpanpglog($idtelenya, $namatelenya, $nominal);

         $order_name     = $nominal . "|" . $idtelenya . "|" . $namatelenya . "|" . $idlog;

         //proses payment dulu
         $data = [
            'method'            => $metode_bayar,
            'merchant_ref'      => $order_name,
            'amount'            => $nominal,
            'customer_name'     => $namatelenya,
            'customer_email'    => $email,
            'customer_phone'    => $nowa,
            'order_items'       => [
               [
                  'name'      => $namatelenya,
                  'price'     => $nominal,
                  'quantity'  => 1,
               ]
            ],
            'callback_url'      => 'https://' . $domain . '/response/callbacknya.php',
            'expired_time'      => (time() + (12 * 60 * 60)), // 12 jam
            'signature'         => hash_hmac('sha256', $merchantcode . $order_name . $nominal, $privatekey)
         ];

         $curl = curl_init();

         curl_setopt_array($curl, array(
            CURLOPT_FRESH_CONNECT     => true,
            CURLOPT_URL               => "https://tripay.co.id/" . $simulasi . "/transaction/create",
            CURLOPT_RETURNTRANSFER    => true,
            CURLOPT_HEADER            => false,
            CURLOPT_HTTPHEADER        => array(
               "Authorization: Bearer " . $apikey
            ),
            CURLOPT_FAILONERROR       => false,
            CURLOPT_POST              => true,
            CURLOPT_POSTFIELDS        => http_build_query($data)
         ));

         $response = curl_exec($curl);
         $err = curl_error($curl);
         curl_close($curl);
         $decodes = json_decode($response, true);
         // sleep(10);
         // ambil data url tripay
         $ambil_url  = $decodes['data']['checkout_url'];

         // bikin text proses nya
         $text       = "silahkan lakukan proses pembayaran melalui tombol link dibawah ini :";

         // bikin inline keyboard
         $send       = [[["text" => "checkout pembayaran", "url" => $ambil_url]]];
         // rangkai
         $options = [
            'reply_markup' => json_encode(['inline_keyboard' => $send]),
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'parse_mode' => 'html'
         ];

         return Bot::editMessageText($options);
         //======END CALLBACK PAYMENT GATEWAY

      } elseif ($command == "cancel") {
         $delete = [
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
         ];

         Bot::deleteMessage($delete);

         //==========RESPON /DAFTAR RESELLER
      } elseif (strpos($command, 'pendaftaran : ') !== false) {
         //ambil data respon dari admin
         $pecahsatu     = explode("pendaftaran : ", $command);
         $pecahfinal    = explode("|", $pecahsatu[1]);
         $responadmin   = $pecahfinal[0];
         $idreseller    = $pecahfinal[1];
         $namareseller  = $pecahfinal[2];
         $text          = '';
         $textadmin     = "";
         $id            = getid();
         $array_text    = ngambiltext($id);
         $array_text    = preg_replace('/ENTER/', '\n', trim($array_text));
         $textnya       = json_decode($arraytext, true);
         $daftarnya     = $textnya['daftar'];

         if ($responadmin == 'terima') {
            $cek = daftar($idreseller, $namareseller);

            if (empty($cek)) {
               $textadmin  = "Mohon Maaf system mengalami gangguan silahkan calon reseller untuk mencoba mendaftar ulang\n";
            } else {
               $text .= "Selamat anda telah menjadi Reseller, dengan detail sbb :\n\n";
               $text .= "<code>   Customer ID $idreseller   </code>\n";
               $text .= "<code>========================</code>\n";
               $text .= "<code>  ID User  :</code> <code>$idreseller</code>\n";
               $text .= "<code>  Username :</code> @$namareseller\n";
               $text .= "<code>  Status   : Terdaftar </code>\n";
               $text .= "<code>========================</code>\n";

               $textadmin .= "user $namareseller ($idreseller) berhasil didaftarkan menjadi reseller";

               //====inject daftar disini
               if (empty($daftarnya)) {

                  $text .= "<code>ketik /help untuk melihat daftar perintah</code>\n";
               } else {

                  $text .= "<code>" . $daftarnya . "</code>";
               }
            }
         } else if ($responadmin == 'tolak') {
            $text    .= "mohon maaf permohonan anda untuk menjadi reseller belum bisa disetujui";

            $textadmin .= "user $namareseller ($idreseller) telah ditolak untuk menjadi reseller";
         }

         //kirim ke user
         $kirimuser  = [
            'chat_id'      => $idreseller,
            'parse_mode'   => 'html',
         ];
         Bot::sendMessage($text, $kirimuser);

         //edit owner
         $kirimowner    = [
            'chat_id'      => $chatidtele,
            'message_id'   => (int) $message['message']['message_id'],
            'text'         => $textadmin,
            'parse_mode'   => 'html',
         ];
         return Bot::editMessageText($kirimowner);
         //===============selesai proses daftar
         //===============pagination user hotspot
      } elseif (strpos($command, 'hotspotuser') !== false) {
         $API = new routeros_api();
         if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            $text    = '';
            $userhotspot   = $API->comm("/ip/hotspot/user/getall");
            $jmlhotspot    = count($userhotspot);
            $useractive    = $API->comm("/ip/hotspot/active/getall");
            $jmlactive     = count($useractive);
            $data    = explode("|||", $command)[1];
            $jmlperhal  = 20;
            if (strpos($command, 'hotspotuserhalaman') !== false) {
               $array_luar    = [];
               $array_dalam   = [];
               $pecaharray    = 4;
               if ($data == 0) {
                  $halskr  = 1;
               } else {
                  $halskr  = ($data  / $jmlperhal) + 1;
               }
               $jmlhal  = ceil($jmlhotspot / $jmlperhal);
               $text    .= "jumlah user hotspot saat ini : $jmlhotspot";
               $text    .= "\n";
               $text    .= "halaman $halskr dari $jmlhal";

               if (($data + $jmlperhal) > $jmlhotspot) {
                  $max_i   = $jmlhotspot;
               } else {
                  $max_i   = $data + $jmlperhal;
               }

               for ($i = $data; $i < $max_i; $i++) {
                  $detailuser    = $userhotspot[$i];
                  $username      = $detailuser['name'];
                  $datauser      = ['text' => $username, 'callback_data' => 'hotspotuser|||' . $i];
                  array_push($array_dalam, $datauser);
               }
               $splitarray    = array_chunk($array_dalam, $pecaharray);
               foreach ($splitarray as $index => $satuan) {
                  $satubaris     = array_filter([$satuan[0], $satuan[1], $satuan[2], $satuan[3]]);
                  array_push($array_luar, $satubaris);
               }
               if ($jmlhotspot > $jmlperhal) {
                  if ($halskr == 1 && $jmlhotspot > $jmlperhal) {
                     $menunext   = [
                        ['text' => 'NEXT >>', 'callback_data' => 'hotspotuserhalaman|||' . ($data + $jmlperhal)]
                     ];
                  } elseif (($halskr * $jmlperhal) > $jmlhotspot) {
                     $menunext   = [
                        ['text' => '<< PREV', 'callback_data' => 'hotspotuserhalaman|||' . ($data - $jmlperhal)]
                     ];
                  } else {
                     $menunext   = [
                        ['text' => '<< PREV', 'callback_data' => 'hotspotuserhalaman|||' . ($data - $jmlperhal)],
                        ['text' => 'NEXT >>', 'callback_data' => 'hotspotuserhalaman|||' . ($data + $jmlperhal)]
                     ];
                  }

                  array_push($array_luar, $menunext);
               }
            } else {
               $detailuser    = $userhotspot[$data];

               $user      = $detailuser['name'];
               $address   = $detailuser['address'];
               $mac       = $detailuser['mac-address'];
               $uptime    = $detailuser['uptime'];
               $bytesi    = formatBytes($detailuser['bytes-in'], 2);
               $byteso    = formatBytes($detailuser['bytes-out'], 2);
               $profile   = $detailuser['profile'];

               $halaman = (ceil($data / $jmlperhal) - 1) * 20;

               $text .= "👤 User hotspot $halaman\n";
               $text .= "┠ User  : $user\n";
               $text .= "┠ IP    : $address\n";
               $text .= "┠ Uptime : $uptime\n";
               $text .= "┠ Byte IN      : $bytesi\n";
               $text .= "┠ Byte OUT   : $byteso\n";
               $text .= "┠ MAC  : $mac\n";
               $text .= "┗ Profile    : $profile\n \n";


               $array_luar = [
                  [
                     ['text' => "<< BACK", "callback_data" => 'hotspotuserhalaman|||' . $halaman],
                     ['text' => "CLOSE", "callback_data" => 'cancel']
                  ]
               ];
            }
            $kirimpesan    = [
               'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
               'chat_id'      => $chatidtele,
               'message_id'   => (int) $message['message']['message_id'],
               'text'         => $text,
               'parse_mode'   => 'html',
            ];
         } else {
            $textpesan = "mikrotik tidak terhubung";
            $kirimpesan    = [
               'chat_id'      => $chatidtele,
               'message_id'   => (int) $message['message']['message_id'],
               'text'         => $textpesan,
               'parse_mode'   => 'html',
            ];
         }
         return Bot::editMessageText($kirimpesan);
         //===============selesai pagination user hotspot
         //===============pagination hotspot aktif
      } elseif (strpos($command, 'hotspotaktif') !== false) {
         $API = new routeros_api();
         if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            $text    = '';
            $useractive    = $API->comm("/ip/hotspot/active/getall");
            $jmlactive     = count($useractive);
            $data    = explode("|||", $command)[1];
            $jmlperhal  = 20;
            if (strpos($command, 'hotspotaktifhalaman') !== false) {
               $array_luar    = [];
               $array_dalam   = [];
               $pecaharray    = 4;
               if ($data == 0) {
                  $halskr  = 1;
               } else {
                  $halskr  = ($data  / $jmlperhal) + 1;
               }
               $jmlhal  = ceil($jmlactive / $jmlperhal);
               $text    .= "jumlah hotspot aktif saat ini : $jmlactive";
               $text    .= "\n";
               $text    .= "halaman $halskr dari $jmlhal";

               if (($data + $jmlperhal) > $jmlactive) {
                  $max_i   = $jmlactive;
               } else {
                  $max_i   = $data + $jmlperhal;
               }

               for ($i = $data; $i < $max_i; $i++) {
                  $detailuser    = $useractive[$i];
                  $username      = $detailuser['user'];
                  $datauser      = ['text' => $username, 'callback_data' => 'hotspotaktif|||' . $i];
                  array_push($array_dalam, $datauser);
               }
               $splitarray    = array_chunk($array_dalam, $pecaharray);
               foreach ($splitarray as $index => $satuan) {
                  $satubaris     = array_filter([$satuan[0], $satuan[1], $satuan[2], $satuan[3]]);
                  array_push($array_luar, $satubaris);
               }
               if ($jmlactive > $jmlperhal) {
                  if ($halskr == 1 && $jmlactive > $jmlperhal) {
                     $menunext   = [
                        ['text' => 'NEXT >>', 'callback_data' => 'hotspotaktifhalaman|||' . ($data + $jmlperhal)]
                     ];
                  } elseif (($halskr * $jmlperhal) > $jmlactive) {
                     $menunext   = [
                        ['text' => '<< PREV', 'callback_data' => 'hotspotaktifhalaman|||' . ($data - $jmlperhal)]
                     ];
                  } else {
                     $menunext   = [
                        ['text' => '<< PREV', 'callback_data' => 'hotspotaktifhalaman|||' . ($data - $jmlperhal)],
                        ['text' => 'NEXT >>', 'callback_data' => 'hotspotaktifhalaman|||' . ($data + $jmlperhal)]
                     ];
                  }

                  array_push($array_luar, $menunext);
               }
            } else {
               $detailuser    = $useractive[$data];

               $user      = $detailuser['user'];
               $address   = $detailuser['address'];
               $mac       = $detailuser['mac-address'];
               $uptime    = $detailuser['uptime'];
               $bytesi    = formatBytes($detailuser['bytes-in'], 2);
               $byteso    = formatBytes($detailuser['bytes-out'], 2);
               $loginby   = $detailuser['login-by'];
               $usesstime = $detailuser['session-time-left'];

               $halaman = (ceil($data / $jmlperhal) - 1) * 20;

               $text .= "👤 User aktif\n";
               $text .= "┠ User  : $user\n";
               $text .= "┠ IP    : $address\n";
               $text .= "┠ MAC  : $mac\n";
               $text .= "┠ Uptime : $uptime\n";
               $text .= "┠ Byte IN      : $bytesi\n";
               $text .= "┠ Byte OUT   : $byteso\n";
               $text .= "┠ Sesion  : $usesstime\n";
               $text .= "┗ Login    : $loginby\n \n";


               $array_luar = [
                  [
                     ['text' => "<< BACK", "callback_data" => 'hotspotaktifhalaman|||' . $halaman],
                     ['text' => "CLOSE", "callback_data" => 'cancel']
                  ]
               ];
            }
            $kirimpesan    = [
               'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
               'chat_id'      => $chatidtele,
               'message_id'   => (int) $message['message']['message_id'],
               'text'         => $text,
               'parse_mode'   => 'html',
            ];
         } else {
            $textpesan = "mikrotik tidak terhubung";
            $kirimpesan    = [
               'chat_id'      => $chatidtele,
               'message_id'   => (int) $message['message']['message_id'],
               'text'         => $textpesan,
               'parse_mode'   => 'html',
            ];
         }
         return Bot::editMessageText($kirimpesan);
         //===============selesai pagination hotspot aktif
      } elseif (strpos($command, 'hapusreport') !== false) {

         $cekdata  = explode('hapusreport', $command);

         if ($cekdata[1] == '1blnlalu') {
            $text = "KONFIRMASI MENGHAPUS DATA 1 BULAN YANG LALU ?";
            $text .= "\ndata yang dihapus adalah semua data voucher yang terpakai, topup, transfer di database, data di mikrotik tidak akan terhapus.";
            $send = [
               [
                  ['text' => 'YA', 'callback_data' => 'hapusreportya1bln'],
                  ['text' => 'TIDAK', 'callback_data' => 'hapusreporttidak1bln'],
               ]
            ];
            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'reply_markup' => json_encode(['inline_keyboard' => $send]),
               'parse_mode' => 'html'
            ];
         } elseif ($cekdata[1] == '3blnlalu') {
            $text = "KONFIRMASI MENGHAPUS DATA SETELAH 3 BULAN YANG LALU ?";
            $text .= "\ndata yang dihapus adalah seluruh data transaksi dari awal mikbotam berjalan hingga 3 bulan yang lalu";
            $send = [
               [
                  ['text' => 'YA', 'callback_data' => 'hapusreportya3bln'],
                  ['text' => 'TIDAK', 'callback_data' => 'hapusreporttidak3bln']
               ]
            ];
            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'reply_markup' => json_encode(['inline_keyboard' => $send]),
               'parse_mode' => 'html'
            ];
         } elseif ($cekdata[1] == 'ya1bln') {

            $text = hapusrekapbulanlalu();
            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'parse_mode' => 'html'
            ];
         } elseif ($cekdata[1] == 'ya3bln') {

            $text = hapusrekaptigabulan();
            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'parse_mode' => 'html'
            ];
         } elseif ($cekdata[1] == 'tidak1bln' || $cekdata[1] == 'tidak3bln') {
            $text = "BATAL MENGHAPUS";
            $options = [
               'chat_id' => $chatidtele,
               'message_id' => (int) $message['message']['message_id'],
               'text' => $text,
               'parse_mode' => 'html'
            ];
         }


         Bot::editMessageText($options);




         //---- call back untuk /rekapall----
      } elseif (strpos($command, 'resellerinfo') !== false) {
         $cekdata  = explode('resellerinfo', $command);

         $rekap = rekapreseller($cekdata[1]);

         $text = "";
         $text .= "REKAP PENJUALAN\n<b>=== " . $cekdata[0] . " ===</b>\n\n";
         $text .= "<code>Saldo saat ini : " . rupiah($rekap['saldo']) . " \n";
         $text .= "</code>\n<b>== HARI INI ==</b>\n<code>";
         $text .= "\n== OMSET Voucher Telegram ==\n";
         $text .= "VC-Telegram : " . $rekap['jmlvc_hariini'] . " vcr\n";
         $text .= "Omset : " . rupiah($rekap['omsetvc_hariini'] + $rekap['markvc_hariini']) . " \n";
         $text .= "Modal : " . rupiah($rekap['omsetvc_hariini']) . " \n";
         $text .= "Keuntungan : " . rupiah($rekap['markvc_hariini']) . " \n";
         $text .= "\n== OMSET Voucher Fisik ==\n";
         $text .= "VC-Fisik dicetak : " . $rekap['jmlgen_hariini'] . " vcr\n";
         $text .= "VC-Fisik terjual : " . $rekap['vcgenlaku_hariini'] . " vcr\n";
         $text .= "Omset : " . rupiah($rekap['omsetgen_hariini'] + $rekap['markgen_hariini']) . " \n";
         $text .= "Modal : " . rupiah($rekap['omsetgen_hariini']) . " \n";
         $text .= "Keuntungan : " . rupiah($rekap['markgen_hariini']) . " \n";

         $text .= "</code>\n<b>== BULAN INI ==</b>\n<code>";
         $text .= "\n== OMSET Voucher Telegram ==\n";
         $text .= "VC-Telegram : " . $rekap['jmlvc_blnini'] . " vcr\n";
         $text .= "Omset : " . rupiah($rekap['omsetvc_blnini'] + $rekap['markvc_blnini']) . " \n";
         $text .= "Modal : " . rupiah($rekap['omsetvc_blnini']) . " \n";
         $text .= "Keuntungan : " . rupiah($rekap['markvc_blnini']) . " \n";
         $text .= "\n== OMSET Voucher Fisik ==\n";
         $text .= "VC-Fisik dicetak : " . $rekap['jmlgen_blnini'] . " vcr\n";
         $text .= "VC-Fisik terjual : " . $rekap['vcgenlaku_blnini'] . " vcr\n";
         $text .= "Omset : " . rupiah($rekap['omsetgen_blnini'] + $rekap['markgen_blnini']) . " \n";
         $text .= "Modal : " . rupiah($rekap['omsetgen_blnini']) . " \n";
         $text .= "Keuntungan : " . rupiah($rekap['markgen_blnini']) . " \n";

         $text .= "</code>\n<b>== BULAN LALU ==</b>\n<code>";
         $text .= "\n== OMSET Voucher Telegram ==\n";
         $text .= "VC-Telegram : " . $rekap['jmlvc_blnlalu'] . " vcr\n";
         $text .= "Omset : " . rupiah($rekap['omsetvc_blnlalu'] + $rekap['markvc_blnlalu']) . " \n";
         $text .= "Modal : " . rupiah($rekap['omsetvc_blnlalu']) . " \n";
         $text .= "Keuntungan : " . rupiah($rekap['markvc_blnlalu']) . " \n";
         $text .= "\n== OMSET Voucher Fisik ==\n";
         $text .= "VC-Fisik dicetak : " . $rekap['jmlgen_blnlalu'] . " vcr\n";
         $text .= "VC-Fisik terjual : " . $rekap['vcgenlaku_blnlalu'] . " vcr\n";
         $text .= "Omset : " . rupiah($rekap['omsetgen_blnlalu'] + $rekap['markgen_blnlalu']) . " \n";
         $text .= "Modal : " . rupiah($rekap['omsetgen_blnlalu']) . " \n";
         $text .= "Keuntungan : " . rupiah($rekap['markgen_blnlalu']) . " \n";

         $text .= "=======</code>\n";

         $options = [
            'chat_id' => $chatidtele,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'parse_mode' => 'html'
         ];

         Bot::sendMessage($text, $options);
      }
   } else {
      $text    = 'Maaf  anda tidak terdaftar silahkan daftar terlebih dahulu ke admin atau klik /daftar';
      $options = [
         'chat_id' => $chatidtele,
         'message_id' => (int) $message['message']['message_id'],
         'text' => $text,
      ];
      Bot::editMessageText($options);
   }
});

$mkbot->on('photo', function () {
   $info           = bot::message();
   $nametelegram   = $info['from']['username'];
   $idtelegram     = $info['from']['id'];
   $caption        = strtolower($info['caption']);
   $explode        = explode(' ', $caption);
   $konfirmasitext = $explode['0'];
   $deposittext    = $explode['1'];
   $jumlahtext     = $explode['2'];

   if (!empty($caption)) {
      include('../config/system.conn.php');
      if (has($idtelegram)) {
         //cek kandungan
         if (preg_match('/^#konfirmasi/', $konfirmasitext)) {
            //cek lagi sesuai format
            if ($konfirmasitext == '#konfirmasi' && $deposittext == 'deposit' && !empty($jumlahtext)) {
               if (preg_match('/^[0-9]+$/', $jumlahtext)) {
                  $fototerbaik = $info['photo'][3]['file_id'];
                  $fotomedium  = $info['photo'][2]['file_id'];
                  $fotorendah  = $info['photo'][1]['file_id'];
                  $fotojelek   = $info['photo'][0]['file_id'];
                  $caption     = "Lapor ! konfirmasi deposit dari @$nametelegram Jumlah " . rupiah($jumlahtext) . " Silahkan di periksa dan ditindak lanjut";
                  if (!empty($fototerbaik)) {
                     Bot::sendPhoto($fototerbaik, $options = ['chat_id' => $id_own, 'caption' => $caption, 'parse_mode' => 'html']);
                     Bot::sendMessage("konfirmasi deposit sudah kami dan akan segera kami prosses mohon tunggu\n\nTerima kasih");
                  } elseif (!empty($fotomedium)) {
                     Bot::sendPhoto($fotomedium, $options = ['chat_id' => $id_own, 'caption' => $caption, 'parse_mode' => 'html']);
                     Bot::sendMessage("konfirmasi deposit sudah kami terima, akan segera kami prosses mohon tunggu\n\nTerima kasih");
                  } elseif (!empty($fotorendah)) {
                     Bot::sendMessage("Maaf foto anda tidak jelas system kami tidak dapat membaca foto anda 😅 \n");
                  } else {
                     Bot::sendMessage("Maaf foto anda tidak jelas system kami tidak dapat membaca foto anda 😅 \n");
                  }
               } else {
                  Bot::sendMessage("Maaf Jumlah deposit hanya berupa angka saja  😅 \n");
               }
            } else {
               Bot::sendMessage("Silahkan konfirmasi deposit disertai dengan keterangan di foto Contoh format keterangan : konfirmasi deposit 20000 ");
            }
         }
      } else {
         Bot::editMessageText('Maaf anda tidak terdaftar silahkan daftar terlebih dahulu ke admin atau klik /daftar');
      }
   }
});

$mkbot->run();

   /*Please contact @Bangachil for bugs
   history
   1 Maret 2019
   -Make ceksaldo command
   -Make cekid
   2 Maret 2019
   -Make callback data
   -Make menu command
   -Make array menu
   -Make callback answer
   3 Maret 2019
   -Make database Saldo
   -bugs fix daftar
   -bugs fix menu
   -bugs fix saldo minus
   -bugs fix topup
   -Make topup send to ID
   -Make button menu
   10 Maret 2019
   -make emoticon button menu
   -make cek id calbback
   -make voucher defalut disable
   -make voucher null
   19 Maret 2019
   -bugs fix menu command
   -bugs fix callback answer
   -bugs fix list Voucher array
   -bugs fix database
   Version update 1.2.3
   20 maret 2019
   -Make User id callback
   -remove emotion calbback
   -remove array_filter
   -move data callback
   -move ceksaldo
   -Make ceksaldo cek id
   Version update 1.2.11

   2 april 2019
   -remove start auto join
   -make hitspot view
   -make remove user hotspot cmd
   -make help cmd
   -Make hass user
   Version update 1.2.13

   3 april 2019
   -edited vcr callback data

   Version update 1.2.14
   8 april 2019
   -Penambahan type char
   -color qrcode
   -bugs fix saldo minus
   Version update 1.3.00

   -10 april 2019
   -Perispan nonsaldo
   -edit text
   -Version update 1.4.00
   11 april 2019

   -Version update 1.5.00

   Thanks to topupGroup an member , SengkuniCode, and to all user support mini project
   Thanks to SengkuniCode for web ui,

    */
