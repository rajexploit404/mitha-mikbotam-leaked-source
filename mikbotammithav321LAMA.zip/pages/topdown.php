<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2019
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//
error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {
    include '../config/system.conn.php';
    $data = lihatdata();
}

?>
<script>
    var _0x1d23 = ["val", "#IDUser", "#Saldo", "length", "Input ID User", "<img style='width:30%;' class='img-fluid center'; src='../img/loading.svg'/><br><center>Please choose one of the the ID User.</center>", "alert", "Input Saldo", "<img style='width:30%;' class='img-fluid center'; src='../img/loading.svg'/><br><center>Please choose one of the Saldo.</center>", "cursor", "wait", "css", "body", '<div align="center"><img src="../img/loading.svg" /></div>', "html", "#view-respont", "../Prosses/saldo.php", "IDUser=", "&Saldo=", "&up=down", "default", "ajax", "Mikbotam MITHA", "success", "dismissed", "log", "notify"];

    function topupsaldo() {
        var _0xc528x2 = $(_0x1d23[1])[_0x1d23[0]]();
        var _0xc528x3 = $(_0x1d23[2])[_0x1d23[0]]();
        if (_0xc528x2[_0x1d23[3]] == 0) {
            alertify[_0x1d23[6]](_0x1d23[4], _0x1d23[5])
        } else {
            if (_0xc528x3[_0x1d23[3]] == 0) {
                alertify[_0x1d23[6]](_0x1d23[7], _0x1d23[8])
            } else {
                $(_0x1d23[12])[_0x1d23[11]](_0x1d23[9], _0x1d23[10]);
                $(_0x1d23[15])[_0x1d23[14]](_0x1d23[13]);
                $[_0x1d23[21]]({
                    url: _0x1d23[16],
                    data: _0x1d23[17] + _0xc528x2 + _0x1d23[18] + _0xc528x3 + _0x1d23[19],
                    cache: false,
                    success: function(_0xc528x4) {
                        $(_0x1d23[15])[_0x1d23[14]](_0xc528x4);
                        $(_0x1d23[12])[_0x1d23[11]](_0x1d23[9], _0x1d23[20])
                    }
                });
                alertify[_0x1d23[26]](_0x1d23[22], _0x1d23[23], 5, function() {
                    console[_0x1d23[25]](_0x1d23[24])
                })
            }
        }
    }
</script>

<div class="card-body pd-sm-10">
    <div class="row row-sm mg-t--1">
        <div class="col-sm-6 mg-t-10">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white"><i class="fa  fa-money "></i> Top Down Saldo </div>
                <div class="card-body pd-sm-15">
                    <form method="post" action="">
                        <!-- row -->

                        <!-- row -->
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label">ID User </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <select class="form-control select2id" id="IDUser" name="idnya" data-placeholder="Select ID">
                                    <option value="">Select ID</option>
                                    <?php
                                    foreach ($data as $index => $baris) : ?>
                                        <option value="<?= $baris['id_user']; ?>"><?php echo $baris['id_user'] . '    (' . $baris['nama_seller'] . ')'; ?></option>
                                    <?php endforeach; ?>

                                </select>
                            </div>
                        </div>
                        <!-- row -->

                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label">Saldo </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <div class="input-group">
                                    <span class="input-group-addon bg-transparent">
                                        <label class="wd-8 lh-8">
                                            Rp.
                                        </label>
                                    </span>
                                    <input id="Saldo" type="text" class="form-control" name="Saldo" onkeypress="return isNumber(event)">
                                </div>
                            </div>
                        </div>
                        <div class="row row-xs mg-t-8">
                            <div class="col-sm-15 mg-l-auto">
                                <div class="form-layout-footer">
                                    <button class="btn btn-success lh-0 tx-xthin mg-r-0 mg-t-8" onclick="topupsaldo();return false;"><i class="fa fa-thumbs-up mg-r-2"></i> Save</button>
                                    <button class="btn btn-success lh-0 tx-xthin mg-r-2 mg-t-8"><i class="fa  fa-trash"> </i> Delete</button>
                                </div>
                                <!-- form-layout-footer -->
                            </div>
                            <!-- col-8 -->
                        </div>
                    </form>
                </div>
                <div id="view-respont"></div>
                <!-- card-body -->
            </div>
            <!-- card -->
        </div>
        <div class="col-xl-6 mg-t-10">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white">
                    <i class="fa fa-pencil"></i> Format
                </div>
                <div class="card-body pd-sm-15">
                    <table>
                        <tbody>
                            <tr>
                                <td colspan="2">
                                    <p style="padding:0px 2px;">
                                        Top <code>Down </code>.<br> Fungsi :<code> Mengurangi saldo counter </code><br>Case : <code>Jika anda salah mengisikan saldo counter</code>.
                                    </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <!-- card-body -->
                    <!-- card -->
                </div>
            </div>
        </div>
    </div>

</div>
<!-- body -->