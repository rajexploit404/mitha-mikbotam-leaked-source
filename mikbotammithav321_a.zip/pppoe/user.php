<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2018
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {
    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Api/routeros_api.class.php';
    date_default_timezone_set('Asia/Jakarta');
    $API = new routeros_api();
    $fp = @fsockopen($mikrotik_ip, $mikrotik_port, $errCode, $errStr, 1);
    if ($fp) {
        if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
            if (isset($_POST['save_user'])) {
                $username           = $_POST['username'];
                $password           = $_POST['password'];
                $service            = $_POST['service'];
                $profilementah      = $_POST['profile'];
                $profileid          = explode("|+|", $profilementah)[0];
                $profile            = explode("|+|", $profilementah)[1];
                $remoteaddress      = $_POST['remoteaddress'];
                $localaddress       = $_POST['localaddress'];
                $tgljatuhtempo      = $_POST['tglexp'];
                $jamexp             = $_POST['jamexp'];
                $mntexp             = $_POST['mntexp'];
                $eksekusi           = $_POST['eksekusi'];
                $profileexpired     = '';
                if ($eksekusi == 'pindah-profile') {
                    $profileexpired = "(" . $_POST['profileexpired'] . ")";
                }

                if ($tgljatuhtempo == "profile" || $jamexp == "profile" || $mntexp == "profile" || $eksekusi == "profile") {
                    $dataprofile    = $API->comm("/ppp/profile/print", ["?.id" => $profileid])[0]['comment'];
                    //komenprofil : | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(tenggat) | idprofile : *4 | PPPoE-MITHA-MIKBOTAM | 
                    $pecahkomen     = explode(" | ", $dataprofile);
                    $ambiltglexp    = explode("tgl-expired : ", $pecahkomen[0])[1];
                    $ambiljamexp    = explode("jam-expired : ", $pecahkomen[1])[1];
                    $jam            = explode(":", $ambiljamexp)[0];
                    $menit          = explode(":", $ambiljamexp)[1];
                    $ambilidprof    = explode("idprofile : ", $pecahkomen[3])[1];
                    $metode         = explode("eksekusi : ", $pecahkomen[2])[1];
                    $profiltujuan   = explode("(", $metode);
                    $metodefix      = $profiltujuan[0];
                    if ($metodefix == 'pindah-profile') {
                        $proftujuanfix  = explode(")", $profiltujuan[1])[0];
                    }
                    if ($tgljatuhtempo == "profile") {
                        $tgljatuhtempo = $ambiltglexp;
                    }
                    if ($jamexp == "profile") {
                        $jamexp = $jam;
                    }
                    if ($mntexp == "profile") {
                        $mntexp = $menit;
                    }
                    if ($eksekusi == "profile") {
                        $eksekusi = $metodefix;
                        if ($metodefix == 'pindah-profile') {
                            $profileexpired = "($proftujuanfix)";
                        }
                    }
                }

                if (empty($remoteaddress) && empty($localaddress)) {
                    $add_user_ppp     = $API->comm("/ppp/secret/add", [
                        "name" => $username,
                        "password" => $password,
                        "service" => $service,
                        "profile" => $profile,
                    ]);
                } else if (empty($localaddress)) {
                    $add_user_ppp     = $API->comm("/ppp/secret/add", [
                        "name" => $username,
                        "password" => $password,
                        "service" => $service,
                        "profile" => $profile,
                        "remote-address" => $remoteaddress,
                    ]);
                } else if (empty($remoteaddress)) {
                    $add_user_ppp     = $API->comm("/ppp/secret/add", [
                        "name" => $username,
                        "password" => $password,
                        "service" => $service,
                        "profile" => $profile,
                        "local-address" => $localaddress,
                    ]);
                } else {
                    $add_user_ppp     = $API->comm("/ppp/secret/add", [
                        "name" => $username,
                        "password" => $password,
                        "service" => $service,
                        "profile" => $profile,
                        "remote-address" => $remoteaddress,
                        "local-address" => $localaddress,
                    ]);
                }
                $checkdata = json_encode($add_user_ppp);
                if (strpos(strtolower($checkdata), '!trap')) {
                    echo '<script language="javascript">';
                    echo 'document.addEventListener("DOMContentLoaded", function() {';
                    echo 'alertify.alert("WARNING", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center>User PPP Already Exist </center>");';
                    echo '});';
                    echo '</script>';
                } else {
                    $datasecret = $API->comm("/ppp/secret/print", ["?name" => $username])[0]['.id'];
                    //komensecret : | status : daftar | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(tenggat) | idsecret : *4 | profile : profilemitha | PPPoE-MITHA-MIKBOTAM | 
                    $meracikkomen = "| status : daftar | tgl-expired : $tgljatuhtempo | jam-expired : $jamexp:$mntexp | eksekusi : $eksekusi$profileexpired | idsecret : $datasecret | profile : $profile | PPPoE-MITHA-MIKBOTAM | ";
                    $editkomensecret = $API->comm("/ppp/secret/set", [
                        ".id" => $datasecret,
                        "comment" => $meracikkomen,
                    ]);


                    echo '<script language="javascript">';
                    echo 'document.addEventListener("DOMContentLoaded", function() {';
                    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success Add User PPP  </center>");';
                    echo '});';
                    echo '</script>';
                }
            }

            if (isset($_POST['edit_user'])) {
                $username         = $_POST['username'];
                $password         = $_POST['password'];
                $service          = $_POST['service'];
                $profilementah    = $_POST['profile'];
                $profileid        = explode("|+|", $profilementah)[0];
                $profile          = explode("|+|", $profilementah)[1];
                $remoteaddress    = $_POST['remoteaddress'];
                $localaddress     = $_POST['localaddress'];
                $tgljatuhtempo    = $_POST['tglexp'];
                $jamexp           = $_POST['jamexp'];
                $mntexp           = $_POST['mntexp'];
                $eksekusi         = $_POST['eksekusi'];
                $uid              = $_POST['uid'];
                $profileexpired   = '';
                if ($eksekusi == 'pindah-profile') {
                    $profileexpired = "(" . $_POST['profileexpired'] . ")";
                }

                if ($tgljatuhtempo == "profile" || $jamexp == "profile" || $mntexp == "profile" || $eksekusi == "profile") {
                    $dataprofile    = $API->comm("/ppp/profile/print", ["?.id" => $profileid])[0]['comment'];
                    //komenprofil : | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(tenggat) | idprofile : *4 | PPPoE-MITHA-MIKBOTAM | 
                    $pecahkomen     = explode(" | ", $dataprofile);
                    $ambiltglexp    = explode("tgl-expired : ", $pecahkomen[0])[1];
                    $ambiljamexp    = explode("jam-expired : ", $pecahkomen[1])[1];
                    $jam            = explode(":", $ambiljamexp)[0];
                    $menit          = explode(":", $ambiljamexp)[1];
                    $ambilidprof    = explode("idprofile : ", $pecahkomen[3])[1];
                    $metode         = explode("eksekusi : ", $pecahkomen[2])[1];
                    $profiltujuan   = explode("(", $metode);
                    $metodefix      = $profiltujuan[0];
                    if ($metodefix == 'pindah-profile') {
                        $proftujuanfix  = explode(")", $profiltujuan[1])[0];
                    }
                    if ($tgljatuhtempo == "profile") {
                        $tgljatuhtempo = $ambiltglexp;
                    }
                    if ($jamexp == "profile") {
                        $jamexp = $jam;
                    }
                    if ($mntexp == "profile") {
                        $mntexp = $menit;
                    }
                    if ($eksekusi == "profile") {
                        $eksekusi = $metodefix;
                        if ($metodefix == 'pindah-profile') {
                            $profileexpired = "($proftujuanfix)";
                        }
                    }
                }

                //komensecret : | status : daftar | tgl-expired : 10 | jam-expired : 23:00 | eksekusi : pindah-profile(tenggat) | idsecret : *4 | profile : profilemitha | PPPoE-MITHA-MIKBOTAM | 
                $meracikkomen = "| status : daftar | tgl-expired : $tgljatuhtempo | jam-expired : $jamexp:$mntexp | eksekusi : $eksekusi$profileexpired | idsecret : $uid | profile : $profile | PPPoE-MITHA-MIKBOTAM | ";

                if (empty($remoteaddress) && empty($localaddress)) {
                    $edit_user_ppp     = $API->comm("/ppp/secret/set", [
                        ".id" => $uid,
                        "name" => $username,
                        "password" => $password,
                        "service" => $service,
                        "profile" => $profile,
                        "comment" => $meracikkomen,
                    ]);

                    $API->comm("/ppp/secret/unset", [
                        ".id" => $uid,
                        "value-name" => 'remote-address',
                    ]);

                    $API->comm("/ppp/secret/unset", [
                        ".id" => $uid,
                        "value-name" => 'local-address',
                    ]);
                } else if (empty($localaddress)) {
                    $edit_user_ppp     = $API->comm("/ppp/secret/set", [
                        ".id" => $uid,
                        "name" => $username,
                        "password" => $password,
                        "service" => $service,
                        "profile" => $profile,
                        "remote-address" => $remoteaddress,
                        "comment" => $meracikkomen,
                    ]);

                    $API->comm("/ppp/secret/unset", [
                        ".id" => $uid,
                        "value-name" => 'local-address',
                    ]);
                } else if (empty($remoteaddress)) {
                    $edit_user_ppp     = $API->comm("/ppp/secret/set", [
                        ".id" => $uid,
                        "name" => $username,
                        "password" => $password,
                        "service" => $service,
                        "profile" => $profile,
                        "local-address" => $localaddress,
                        "comment" => $meracikkomen,
                    ]);

                    $API->comm("/ppp/secret/unset", [
                        ".id" => $uid,
                        "value-name" => 'remote-address',
                    ]);
                } else {
                    $edit_user_ppp     = $API->comm("/ppp/secret/set", [
                        ".id" => $uid,
                        "name" => $username,
                        "password" => $password,
                        "service" => $service,
                        "profile" => $profile,
                        "remote-address" => $remoteaddress,
                        "local-address" => $localaddress,
                        "comment" => $meracikkomen,
                    ]);
                }

                //ganti jadwal schedule menyesuaikan dengan editan

                $idschedule         = $API->comm("/system/scheduler/print", ["?name" => $username . "-ppp-mitha"])[0];
                $startdatelama      = explode("/", $idschedule['start-date']);
                $startdate          = $startdatelama[0] . "/" . $tgljatuhtempo . "/" . $startdatelama[2];
                $starttime          = "$jamexp:$mntexp:00";
                $setschedule        = $API->comm("/system/scheduler/set", [
                    ".id"           => $idschedule[".id"],
                    "start-date"    => $startdate,
                    "start-time"    => $starttime,
                ]);


                $checkdata = json_encode($edit_user_ppp);
                if (strpos(strtolower($checkdata), '!trap')) {
                    echo '<script language="javascript">';
                    echo 'document.addEventListener("DOMContentLoaded", function() {';
                    echo 'alertify.alert("WARNING", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center>Gagal menyimpan, cek karakter/huruf </center>");';
                    echo '});';
                    echo '</script>';
                } else {

                    echo '<script language="javascript">';
                    echo 'document.addEventListener("DOMContentLoaded", function() {';
                    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success Edit User PPP </center>");';
                    echo '});';
                    echo '</script>';
                }
            }

            $seeprofile = $API->comm('/ppp/profile/print');
            $seeuser   = $API->comm('/ppp/secret/print');
            //print_r($seeuser);

?>


            <script>
                var _0x82f1 = ["show.bs.modal", "id", "data", "relatedTarget", "cursor", "wait", "css", "body", "../pppoe/user_edit.php", "id=", "html", "#view-respont", "default", "ajax", "on", "#useredit"];

                function edituser() {
                    $(_0x82f1[15])[_0x82f1[14]](_0x82f1[0], function(_0xfe4ax2) {
                        var _0xfe4ax3 = $(_0xfe4ax2[_0x82f1[3]])[_0x82f1[2]](_0x82f1[1]);
                        $(_0x82f1[7])[_0x82f1[6]](_0x82f1[4], _0x82f1[5]);
                        $[_0x82f1[13]]({
                            url: _0x82f1[8],
                            data: _0x82f1[9] + _0xfe4ax3,
                            cache: false,
                            success: function(_0xfe4ax4) {
                                $(_0x82f1[11])[_0x82f1[10]](_0xfe4ax4);
                                $(_0x82f1[7])[_0x82f1[6]](_0x82f1[4], _0x82f1[12])
                            }
                        })
                    })
                }
            </script>

            <script type="text/javascript">
                var profile = '<?php foreach ($seeprofile as $index => $baris) : echo '<option value="' . $baris['name'] . '">' . $baris['name'] . '</option>';
                                endforeach; ?>';

                function pilihprofile(name) {

                    if (name == 'pindah-profile') document.getElementById('pindahprofile').innerHTML = '<div class="row mg-t-8"><label class="col-sm-4 form-control-label align-self-center">Profile expired : </label><div class="col-sm-8 mg-t-10 mg-sm-t-0"> <select class="form-control select2id" style="width: 100%;" name="profileexpired" required><option value="">- choose -</option>' + profile + '</select></div></div>';
                    else document.getElementById('pindahprofile').innerHTML = '';
                }
            </script>

            <div class="sl-pagebody">
                <div class="card bd-primary mg-t-3">
                    <div class="card-header bg-primary tx-white"><i class="fa fa-user"></i> PPPoE Manager </div>
                    <div class="card-body pd-sm-15">

                        <div class="table-wrapper">
                            <table id="ppplist" class="table display nowrap " width="100%">
                                <thead>
                                    <tr>
                                        <th>Action</th>
                                        <th>Name</th>
                                        <th>Password</th>
                                        <th>expired</th>
                                        <th>Service</th>
                                        <th>Profile</th>
                                        <th>R. Address</th>
                                        <th>L. Address</th>
                                        <th>Last Logout</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    foreach ($seeuser as $index => $baris) :
                                        $comment = explode(" | ", $baris['comment']);
                                        $stkomen = explode("status : ", $comment[0])[1];
                                        $tglexp  = explode("tgl-expired : ", $comment[1])[1];
                                        $jamtbl  = explode("jam-expired : ", $comment[2])[1];
                                        $ekstbl  = explode("eksekusi : ", $comment[3])[1];
                                        $prlm    = explode("profile : ", $comment[5])[1];
                                        $prtuj   = explode("(", $ekstbl);
                                        $mtdtbl  = $prtuj[0];
                                        $pttbl   = '';
                                        if ($mtdtbl == 'pindah-profile') {
                                            $pttbl = explode(")", $prtuj[1])[0];
                                        }

                                        //ambil data schedule untuk masa aktif
                                        $schexp     = $API->comm("/system/scheduler/print", ['?name' => $baris['name'] . "-ppp-mitha"])[0];
                                        $schetgl    = $schexp['start-date'];
                                        $schwaktu   = substr($schexp['start-time'], 0, -3);
                                        $schid      = $schexp['.id'];

                                        if (count($comment) > 3) {
                                            $dataexpired = "$schetgl - $schwaktu | $mtdtbl $pttbl";
                                        } else {
                                            $dataexpired = "bukan mitha";
                                        }
                                    ?>

                                        <tr>
                                            <td>
                                                <?php if (strpos($comment[6], "PPPoE-MITHA-MIKBOTAM") !== false) { ?>
                                                    <form action="../eksekusi.php" method="POST">
                                                        <input type="hidden" name="uid" value="<?= $baris['.id']; ?>">
                                                        <input type="hidden" name="secretname" value="<?= $baris['name']; ?>">
                                                        <input type="hidden" name="tipeeksekusi" value="<?= $mtdtbl; ?>">
                                                        <input type="hidden" name="profiletujuan" value="<?= $pttbl; ?>">
                                                        <input type="hidden" name="profileasal" value="<?= $prlm; ?>">
                                                        <input type="hidden" name="komenasal" value="<?= $baris['comment']; ?>">
                                                        <button class="btn btn-<?php echo ($stkomen == "aktif" || $stkomen == "daftar") ? "danger" : "primary"; ?>" type="submit" name="action" value="<?php echo ($stkomen == "aktif" || $stkomen == "daftar") ? "eksekusi" : "aktifkan"; ?>"><?php echo ($stkomen == "aktif" || $stkomen == "daftar") ? "eksekusi" : "aktifkan"; ?></button>
                                                        <button class="btn btn-warning" type="submit" name="schidminus" value='<?= $schid; ?>'>- 1 bln</button>
                                                        <button class="btn btn-info" type="submit" name="schidplus" value='<?= $schid; ?>'>+ 1 bln</button>
                                                    </form>
                                                <?php } else {
                                                    echo "bukan mitha";
                                                } ?>
                                            </td>
                                            <td><a style="color: <?php if ($baris['disabled'] == 'true') {
                                                                        echo 'red';
                                                                    } else {
                                                                        echo 'blue';
                                                                    } ?>;" href='#useredit' class="txt-black" data-toggle='modal' onclick='edituser();' data-id="<?= $baris['.id']; ?>"><i class='fa fa-pencil-square-o'></i>&nbsp; <?php echo $baris['name']; ?></a></td>
                                            <td><?php echo $baris['password']; ?></td>
                                            <td>
                                                <div class="form-inline"><?php echo $dataexpired; ?></div>
                                            </td>
                                            <td><?php echo $baris['service']; ?></td>
                                            <td><?php echo $baris['profile']; ?></td>
                                            <td><?php echo $baris['remote-address']; ?></td>
                                            <td><?php echo $baris['local-address']; ?></td>
                                            <td><?php if ($baris['last-logged-out'] == "jan/01/1970 00:00:00") {
                                                    echo "none";
                                                } else {
                                                    echo $baris['last-logged-out'];
                                                } ?></td>

                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>


            <div id="myModal" class="modal fade" role="dialog">
                <div class="modal-dialog wd-100p mn-wd-50p" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-25 bg-primary">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-white tx-bold">Add User PPPoE </h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body pd-15">
                            <div class="card bd bd-primary  ">
                                <div class="card-body pd-sm-15">

                                    <form action="" method="post">
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Name : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <input type="text" name="username" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Password : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <input type="text" name="password" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Service : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control select2id" style="width: 100%;" name="service" required>
                                                    <option value="any">any</option>
                                                    <option value="pppoe">pppoe</option>
                                                    <option value="pptp">pptp</option>
                                                    <option value="sstp">sstp</option>
                                                    <option value="l2tp">l2tp</option>
                                                    <option value="ovpn">ovpn</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Profile : </label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control select2id" style="width: 100%;" name="profile" required>
                                                    <option value=''>- choose -</option>
                                                    <?php foreach ($seeprofile as $index => $baris) :
                                                        echo "<option value='" . $baris['.id'] . "|+|" . $baris['name'] . "'>" . $baris['name'] . "</option>";
                                                    endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Remote Address :</label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <div class="input-group">
                                                    <input type="text" name="remoteaddress" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Local Address :</label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <div class="input-group">
                                                    <input type="text" name="localaddress" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Tanggal Jatuh Tempo :</label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control select2id" style="width: 30%;" name="tglexp" id="tglexp">
                                                    <option value="profile">ikut data profile</option>
                                                    <?php for ($i = 01; $i < 29; $i++) {
                                                        $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                                        echo "<option value='$ii'>$ii</option>";
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Waktu Jatuh Tempo (JAM : MENIT) :</label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control select2id" style="width: 30%;" name="jamexp" id="jamexp">
                                                    <option value="profile">ikut data profile</option>
                                                    <?php for ($i = 01; $i < 24; $i++) {
                                                        $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                                        echo "<option value='$ii'>$ii</option>";
                                                    } ?>
                                                </select> &nbsp;:&nbsp;
                                                <select class="form-control select2id" style="width: 30%;" name="mntexp" id="mntexp">
                                                    <option value="profile">ikut data profile</option>
                                                    <?php for ($i = 00; $i < 60; $i++) {
                                                        $ii = str_pad($i, 2, '0', STR_PAD_LEFT);
                                                        echo "<option value='$ii'>$ii</option>";
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mg-t-8">
                                            <label class="col-sm-4 form-control-label align-self-center">Eksekusi :</label>
                                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                                <select class="form-control select2id" style="width: 100%;" name="eksekusi" id="eksekusi" onchange="pilihprofile(this.options[this.selectedIndex].value)">
                                                    <option value="profile">ikut data profile</option>
                                                    <option value="disable">disable</option>
                                                    <option value="pindah-profile">pindah profile</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div id="pindahprofile"></div>

                                        <div class="row row-xs mg-t-10">
                                            <div class="col-sm-15 mg-l-auto">
                                                <div class="form-layout-footer">
                                                    <button type="submit" class="btn bg-primary tx-white" name="save_user">Save changes</button>
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    <button type="button" class="btn btn-danger">Reset</button>
                                                </div>
                                                <!-- form-layout-footer -->
                                            </div>
                                            <!-- col-8 -->
                                        </div>

                                    </form>
                                </div>

                            </div>


                        </div>
                    </div>

                </div>
            </div>



            <div id="useredit" class="modal fade" role="dialog">
                <div class="modal-dialog wd-100p mn-wd-50p" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-25 bg-primary">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-white tx-bold">Edit User PPP </h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body pd-15">
                            <div id="view-respont">

                                <h2>Loading...</h2>
                            </div>

                        </div>
                    </div>

                </div>
            </div>


<?php
        } else {
            include "disconnected.php";
        }

        fclose($fp);
    } else {
        include "disconnected.php";
    }
}
?>