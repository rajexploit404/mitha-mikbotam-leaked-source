<?php
//=====================================================START====================//

/*
 *  RUMAH PETIR v2.7
 *
 */

//=====================================================START SCRIPT====================//
error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {
    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Saldo/rpt/functions.php';


    $id = $_SESSION['Mikbotamid'];

    //===simpen datanya

    if (isset($_POST['savepg'])) {
        $textbaru = [
            "apikey"        => $_POST['apikey'],
            "privatekey"    => $_POST['privatekey'],
            "merchantcode"  => $_POST['merchantcode'],
            "simulasi"      => $_POST['simulasi'],
            "metode"        => $_POST['metode'],
        ];

        //===validasi image
        if (empty($_POST['apikey']) || empty($_POST['privatekey']) || empty($_POST['merchantcode']) || empty($_POST['metode'])) {

            $info = "<div class='alert alert-danger' role='alert'>
                        Data belum terisi dengan benar, metode pembayaran minimal terpilih satu metode.
                        </div>";
        } else {
            $enc_text = json_encode($textbaru);
            $simpantext = inputpg($enc_text, $id);
            $info = "<div class='alert alert-primary' role='alert'>
                    Data berhasil disimpan. silahkan refresh jika data belum berubah.
                    </div>";
        }
    }

    //===ambil datanya
    $arraypg = ambilpg($id);
    $textnya = json_decode($arraypg, true);

?>
    <div class="sl-pagebody">
        <h1 class="tx-center">Payment Gateway Settings</h1>
        <?php echo $info; ?>
        <div class="row row-sm mg-t-1">
            <div class="col-xl-8 mg-t-10">
                <div class="card bd-primary">
                    <div class="card-header bg-primary tx-white">
                        <i class="fa  fa-paper-plane"></i> Data Settings
                    </div>
                    <div class="card-body pd-sm-15">
                        <form method="POST" action="" enctype="multipart/form-data">

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="1"> API KEY </label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['apikey'] ?>" id="1" name="apikey" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" required> </input>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="2">PRIVATE KEY</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['privatekey'] ?>" id="2" name="privatekey" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" required> </input>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="3">MERCHANT CODE</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['merchantcode'] ?>" id="3" name="merchantcode" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" required> </input>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-lg-4 form-control-label lead " for="4">METODE PEMBAYARAN </label>
                                <div class="col-lg-8 align-self-center">
                                    <h5>
                                        <input type="checkbox" name="metode[]" value="BNI-BNIVA" id="bni" <?php if (in_array("BNI-BNIVA", $textnya['metode'])) {
                                                                                                                echo "checked";
                                                                                                            } ?>><label class="form-check-label" for="bni">BNI</label></br>
                                        <input type="checkbox" name="metode[]" value="BRI-BRIVA" id="bri" <?php if (in_array("BRI-BRIVA", $textnya['metode'])) {
                                                                                                                echo "checked";
                                                                                                            } ?>><label class="form-check-label" for="bri">BRI</label></br>
                                        <input type="checkbox" name="metode[]" value="MANDIRI-MANDIRIVA" id="mandiri" <?php if (in_array("MANDIRI-MANDIRIVA", $textnya['metode'])) {
                                                                                                                            echo "checked";
                                                                                                                        } ?>><label class="form-check-label" for="mandiri">MANDIRI</label></br>
                                        <input type="checkbox" name="metode[]" value="ALFAMART-ALFAMART" id="alfamart" <?php if (in_array("ALFAMART-ALFAMART", $textnya['metode'])) {
                                                                                                                            echo "checked";
                                                                                                                        } ?>><label class="form-check-label" for="alfamart">ALFAMART</label></br>
                                        <input type="checkbox" name="metode[]" value="INDOMARET-INDOMARET" id="indomaret" <?php if (in_array("INDOMARET-INDOMARET", $textnya['metode'])) {
                                                                                                                                echo "checked";
                                                                                                                            } ?>><label class="form-check-label" for="indomaret">INDOMARET</label></br>
                                        <input type="checkbox" name="metode[]" value="ALFAMIDI-ALFAMIDI" id="alfamidi" <?php if (in_array("ALFAMIDI-ALFAMIDI", $textnya['metode'])) {
                                                                                                                            echo "checked";
                                                                                                                        } ?>><label class="form-check-label" for="alfamidi">ALFAMIDI</label></br>
                                        <input type="checkbox" name="metode[]" value="QRIS-QRISD" id="qris" <?php if (in_array("QRIS-QRISD", $textnya['metode'])) {
                                                                                                                echo "checked";
                                                                                                            } ?>><label class="form-check-label" for="qris">QRIS (OVO-DANA-GOPAY-SHOPEEPAY)</label></br>
                                    </h5>
                                    <br>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-lg-4 form-control-label lead " for="4">SIMULASI </label>
                                <div class="col-lg-8 align-self-center">
                                    <h6>
                                        <input type="radio" name="simulasi" id="simulasiya" value="ya" <?php if ($textnya['simulasi'] == 'ya') {
                                                                                                            echo "checked";
                                                                                                        } ?>>
                                        <label class="form-check-label" for="simulasiya">YA</label>
                                        </br>
                                        </br>
                                        <input type="radio" name="simulasi" id="simulasitidak" value="tidak" <?php if ($textnya['simulasi'] == 'tidak') {
                                                                                                                    echo "checked";
                                                                                                                } ?>>
                                        <label class="form-check-label" for="simulasitidak">TIDAK</label>
                                    </h6>
                                </div>
                            </div>
                            <br>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead "></label>
                                <div class="col-lg">
                                    <button type="submit" class="btn bg-primary tx-white" name="savepg">Save changes</button>
                                    <button type="reset" class="btn btn-danger">Reset</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

            </div>


            <div class="col-xl-4 mg-t-10">
                <div class="card bd-primary">
                    <div class="card-header bg-primary tx-white"> Petunjuk</div>
                    <div class="card-body pd-sm-15">
                        <table>
                            <tbody>
                                <tr>
                                    <td>
                                        <p>
                                            silahkan mendaftar di <a href="https://tripay.co.id/?ref=TP2108">tripay</a>
                                            <br>
                                            dan mendaftar merchan di dalamnya, lalu data di merchan tersebut diinput ke halaman ini.
                                        </p>



                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>


    <?php $textnya = [];
} ?>