<?php session_start();
error_reporting(0);
if (!isset($_SESSION["Mikbotamuser"])) {
   header("Location:../admin/login.php");
} else { ?>


   <div class="alert alert-danger" role="alert">
      <h4 class="alert-heading">MIKROTIK DISCONNECTED !!</h4>
      <p>server gagal terhubung ke mikrotik, silahkan refresh, jika masih error silahkan klik tombol settings dibawah untuk menuju bagian setting</p>
      <a href="./?Mikbotam=Settings"><button type='button' class='btn btn-info'>SETTINGS</button></a>
   </div>

<?php } ?>