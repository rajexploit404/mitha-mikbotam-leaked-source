<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2019
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//
session_start();
error_reporting(0);
if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:../admin/login.php");
} else {
    include '../config/system.conn.php';
    global $mikbotamdata;
    $username_res   = $_POST['res_nama'];
    $telegram_res   = $_POST['res_idtele'];
    $telp_res       = $_POST['res_telp'];
    $saldo_res      = $_POST['res_saldo'];
    $diskon_res     = $_POST['res_diskon'];
    $grup_res       = $_POST['res_grupvc'];
    $informasi      = "";
    if (isset($username_res) && isset($telegram_res)) {
        if (!empty($username_res) || !empty($telegram_res)) {
            $cek1 = $mikbotamdata->get('re_settings', 'nama_seller', ['nama_seller' => $username_res]);
            $cek2 = $mikbotamdata->get('re_settings', 'id_user', ['id_user' => $telegram_res]);

            if (empty($cek1) || empty($cek2)) {
                $mikbotamdata->insert('re_settings', [
                    "id_user" => $telegram_res,
                    "nama_seller" => $username_res,
                    "saldo" => $saldo_res,
                    "nomer_tlp" => $telp_res,
                    "othertree" => $grup_res,
                    "other" => $diskon_res,
                    'Waktu' => date('H:i:s'),
                    'Tanggal' => date('Y-m-d'),
                ]);
                $informasi = 'RESELLER BERHASIL DITAMBAHKAN';
            } else {
                $informasi = 'MAAF USERNAME DAN ATAU ID TELEGRAM SUDAH TERPAKAI';
            }
        } else {
            $informasi = 'USERNAME ATAU ID TELEGRAM TIDAK BOLEH KOSONG';
        }
    }
}

?>
<?php echo $informasi; ?>
<div class="card-body pd-sm-10">
    <div class="row row-sm mg-t--1">
        <div class="col-sm-6 mg-t-10">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white"><i class="fa fa-user-plus "></i> Add Reseller </div>
                <div class="card-body pd-sm-15">

                    <form method="post" action="">
                        <!-- row -->
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label">Username </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <input name="res_nama" type="text" class="form-control" placeholder="Username" required>
                            </div>
                        </div>
                        <!-- row -->
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label">ID Telegram User </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <input name="res_idtele" type="number" class="form-control" placeholder="ID User" required>
                            </div>
                        </div>
                        <!-- row -->
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label">No Tlp/Whatsapp </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <input name="res_telp" type="number" class="form-control" placeholder="No Tlp/Whatsapp" required>
                            </div>
                        </div>
                        <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label">Saldo </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <div class="input-group">
                                    <span class="input-group-addon bg-transparent">
                                        <label class="wd-8 lh-8">
                                            Rp.
                                        </label>
                                    </span>
                                    <input name="res_saldo" type="number" class="form-control" name="Saldo" value="0" required>
                                </div>
                            </div>
                        </div>
                        <div class="row mg-t-10">
                            <label class="col-sm-4 form-control-label">Diskon (%) : </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <input type="number" class="form-control" name="res_diskon" min="0" max="100" value="0" data-toggle="tooltip" data-placement="top" required>

                            </div>
                        </div>

                        <div class="row mg-t-10">
                            <label class="col-sm-4 form-control-label">Grup Voucher : </label>
                            <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                <select class="form-control" name="res_grupvc" id="grupvc">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="default" selected>default</option>
                                    <option value="all">all</option>

                                </select>


                            </div>
                        </div>

                        <div class="row row-xs mg-t-8">
                            <div class="col-sm-15 mg-l-auto">
                                <div class="form-layout-footer">
                                    <button class="btn btn-success lh-0 tx-xthin mg-r-0 mg-t-8" type="submit"><i class="fa fa-thumbs-up mg-r-2"></i> Save</button>
                                    <button class="btn btn-success lh-0 tx-xthin mg-r-2 mg-t-8"><i class="fa fa-trash mg-r-2"></i> Delete</button>
                                </div>
                                <!-- form-layout-footer -->
                            </div>
                            <!-- col-8 -->
                        </div>
                        </from>
                </div>
                <div id="view-respont"></div>
                <!-- card-body -->
            </div>
            <!-- card -->
        </div>
        <!-- body -->
    </div>
</div>
<!-- body -->