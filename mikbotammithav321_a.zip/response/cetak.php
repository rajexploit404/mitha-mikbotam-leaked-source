<?php
include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Saldo/rpt/functions.php';
include '../Api/routeros_api.class.php';
$API = new routeros_api();
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);

/*
variable yang dikirim via GET
- username
- password
- jenis voucher
- reseller
- qrcode yes / no
- validity
- harga
- timelimit voucher
*/

//ambil data
$username   = $_GET['username'];
$password   = $_GET['password'];
$profile    = $_GET['profile'];
$reseller   = $_GET['reseller'];
$qr         = $_GET['qrcode'];
$harga      = $_GET['harga'];
$timelimit  = $_GET['timelimit'];
$datalimit  = $_GET['datalimit'];
$hotspotname = $Name_router;

//===ambil data gambar

if (file_exists('../img/logo.png')) {
    $logo = '../img/logo.png';
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Voucher-<?= $dnsname . "-" . $username . "-" . rupiah($harga); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="pragma" content="no-cache" />
    <script src="../js/qrious.min.js"></script>
    <style>
        body {
            color: #000000;
            background-color: #FFFFFF;
            font-size: 14px;
            font-family: 'Helvetica', arial, sans-serif;
            margin: 0px;
            -webkit-print-color-adjust: exact;
        }

        table.voucher {
            display: inline-block;
            border: 2px solid black;
            margin: 2px;
        }

        @page {
            size: auto;
            margin-left: 7mm;
            margin-right: 3mm;
            margin-top: 9mm;
            margin-bottom: 3mm;
        }

        @media print {
            table {
                page-break-after: auto
            }

            tr {
                page-break-inside: avoid;
                page-break-after: auto
            }

            td {
                page-break-inside: avoid;
                page-break-after: auto
            }

            thead {
                display: table-header-group
            }

            tfoot {
                display: table-footer-group
            }
        }

        #num {
            float: right;
            display: inline-block;
        }

        .qrc {
            width: 30px;
            height: 30px;
            margin-top: 1px;
        }
    </style>
</head>

<body onload="window.print()">

    <?php
    //ambil data durasi dari profile
    if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
        $seeprofile = $API->comm('/ip/hotspot/user/profile/print', ["?name" => "$profile"])[0]['on-login'];
        if (preg_match("/rmcde/i", $seeprofile)) {

            $ambildata = explode("ut (\"", $seeprofile);

            if (preg_match("/idtelegram/", $seeprofile)) {

                $ambildata2 = explode("\");:local idtelegram (\"", $ambildata[1]);

                $validity = $ambildata2[0];
            } else if (preg_match("/namaadmin/", $seeprofile)) {

                $ambildata2 = explode("\");:local namaadmin (\"", $ambildata[1]);

                $validity = $ambildata2[0];
            } else {
                $validity = "NONE";
            }
        } else {

            $validity = "NONE";
        }
    }

    if ($datalimit == 0) {
        $datalimit = "";
    }
    $price = "(" . $harga . ")";
    $urilogin = "http://$dnsname/login?username=$username&password=$password";
    $qrcode = "
<canvas class='qrcode' id='qr'></canvas>
<script>
(function() {
var qr = new QRious({
  element: document.getElementById('qr'),
  value: '" . $urilogin . "',
  size:'256'
});

})();
</script>
";
    //jika username = password maka otomatis 1 kode
    if ($username == $password) {
        $usermode = 'vc';
    } else {
        $usermode = "up";
    }


    //pilih template

    include('../pages/templates/template-thermal.php');
    ?>

</body>

</html>