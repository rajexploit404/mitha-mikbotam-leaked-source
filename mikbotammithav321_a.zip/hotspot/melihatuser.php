<?php
include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Api/routeros_api.class.php';
$API = new routeros_api();
//error_reporting(0);
if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
    // $seeprofile = $API->comm('/ip/hotspot/user/profile/print');
    // $seeactive  = $API->comm('/ip/hotspot/active/print');
    // $seeuser   = $API->comm('/ip/hotspot/user/print');

    // var_dump($seeprofile);
    // echo "<hr>";
    // var_dump($seeactive);
    // echo "<hr>";
    // var_dump($seeuser);
    // echo "<hr>";

    // $runscript = $API->comm("/system/script/run", ["?name" => "runninglog"]);

    $API->write("/system/script/getall", false);
    $API->write('=.proplist=.id', false);
    $API->write("?name=runninglog");
    $run = $API->read();


    $API->write("/system/script/run", false);
    $API->write('=.id=' . $run[0]['.id']);
    $READ = $API->read();
    $API->disconnect();

    var_dump($READ);
    if ($READ) {
        echo "ya";
    } else {
        echo "tdk";
    }
}
