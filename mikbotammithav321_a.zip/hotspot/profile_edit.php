<?php
//=====================================================START====================//

/*
 *  Base Code   : BangAchil
 *  Email       : kesumaerlangga@gmail.com
 *  Telegram    : @bangachil
 *
 *  Name        : Mikrotik bot telegram - php
 *  Function    : Mikortik api
 *  Manufacture : November 2018
 *  Last Edited : 26 Desember 2018
 *
 *  Please do not change this code
 *  All damage caused by editing we will not be responsible please think carefully,
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);


include '../config/system.conn.php';
include '../config/system.byte.php';
include '../Api/routeros_api.class.php';
$API = new routeros_api();

if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port));

$id          = $_GET['id'];
$getuserdata = $API->comm("/ip/hotspot/user/profile/print", [
    "?.id" => $id,
]);
$getallqueue = $API->comm("/queue/simple/print", [
    "?dynamic" => "false",
]);
$datanya    = $getuserdata[0];
$nmprofile  = $datanya['name'];
$parentq    = $datanya['parent-queue'];
$ratelim    = $datanya['rate-limit'];
$shareu     = $datanya['shared-users'];
$tranpro    = $datanya['transparent-proxy'];
$onlogin    = $datanya['on-login'];
$idprofile  = $datanya['.id'];


//===ambil data telegram dan remove voucher
$onlogin2   = explode(":local rmcde (\"", $onlogin);
$onlogin3   = explode("\");:local ut (\"", $onlogin2[1]);
$onlogin4   = $onlogin3[0];
$onlogin5   = explode("|", $onlogin4);

//===ambil data telegram
$teledata   = substr($onlogin4, 0, 1);

//===ambil data remove voucher
$remvoc     = substr($onlogin4, 1, 1);

//===ambil data lock mac
$locmac     = substr($onlogin4, 2, 1);

//===ambil data reseller telegram
$teleres    = substr($onlogin4, 3, 1);

//===ambil info enable disable fup
$statusfup  = substr($onlogin4, 4, 1);
if (empty($statusfup)) {
    $statusfup = "0";
}

//==ambil data FUP
$trgtfup    = $onlogin5[1];
$trgtfupnm  = $onlogin5[2];
$rxfup      = $onlogin5[3];
$rxname     = $onlogin5[4];
$txfup      = $onlogin5[5];
$txname     = $onlogin5[6];
$itval      = $onlogin5[7];
$jmres      = $onlogin5[8];



//===ambil data durasi
$durasi1    = explode("ut (\"", $onlogin);
if (preg_match("/idtelegram/", $durasi1[1])) {
    $durasi2 = explode("\");:local idtelegram (\"", $durasi1[1]);
} else if (preg_match("/namaadmin/", $durasi1[1])) {
    $durasi2 =  explode("\");:local namaadmin (\"", $durasi1[1]);
};

$durasi3    = $durasi2[0];
//===ambil hari
$hari1  = explode("d ", $durasi3);
$hari2  = $hari1[0];
if (empty($hari2)) {
    $hari2 = "00";
}

//===ambil jam
$pecahwaktu = explode(":", $hari1[1]);
$jam        = $pecahwaktu[0];
$menit      = $pecahwaktu[1];
$detik      = $pecahwaktu[2];

if (empty($jam)) {
    $jam = "00";
}
if (empty($menit)) {
    $menit = "00";
}
if (empty($detik)) {
    $detik = "00";
}






?>

<div class="card bd bd-primary  ">
    <div class="card-body pd-sm-15">

        <form action="" method="post">
            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Profile Name : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <label class="form-control"><?= $nmprofile; ?></label>

                </div>
            </div>


            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Parent Queue : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control select2id" name="parent_editprofile" data-toggle="tooltip" data-placement="top" title="Jika kosong pilih none">
                        <option>none</option>
                        <?php foreach ($getallqueue as $index => $barisan) : ?>

                            <option value="<?= $barisan['name'] ?>" <?php if ($barisan['name'] == $parentq) {
                                                                        echo 'selected';
                                                                    } ?>>


                                <?= $barisan['name'] ?></option>

                        <?php endforeach;
                        ?>
                    </select>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Rate Limit [rx/tx] : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="text" class="form-control" name="rate-limit_editprofile" value="<?= $ratelim; ?>" data-toggle="tooltip" data-placement="top" title="example 1M/512k, salah penulisan maka data tidak terinput" placeholder="1M/512k">
                </div>
            </div>



            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Shared Users : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input id="colorful2" class="form-control" name="shared-users_editprofile" type="number" min="1" max="100" value=<?= $shareu; ?> onkeypress="return isNumber(event)" />
                </div>
            </div>



            <div class="row mg-t-10">
                <label class="col-sm-4 form-control-label">DURATION </label>

            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">day/s : </label>
                <div class="col-sm-2 mg-t-0 mg-sm-t-0">
                    <input type="number" class="form-control" name="valid_time1_editprofile" value=<?php

                                                                                                    if (preg_match("/rmcde/i", $onlogin)) {

                                                                                                        echo $hari2;
                                                                                                    } else {

                                                                                                        echo "00";
                                                                                                    }

                                                                                                    ?> data-toggle="tooltip" data-placement="top" title="numerik only" placeholder="00" required>
                </div>
                <div class="col-sm-0 mg-t-0 mg-sm-t-10">
                    day/s
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Hours : Mnt : Scnd</label>
                <div class="col-sm-2 mg-t-10 mg-sm-t-0">
                    <input type="number" class="form-control" name="valid_time2_editprofile" value=<?php if (preg_match("/rmcde/i", $onlogin)) {
                                                                                                        echo $jam;
                                                                                                    } else {
                                                                                                        echo "00";
                                                                                                    } ?> data-toggle="tooltip" data-placement="top" title="numerik only" placeholder="00" required>
                </div>
                <div class="col-sm-0 mg-t-0 mg-sm-t-10">
                    :
                </div>
                <div class="col-sm-2 mg-t-10 mg-sm-t-0">
                    <input type="number" class="form-control" name="valid_time3_editprofile" value=<?php if (preg_match("/rmcde/i", $onlogin)) {
                                                                                                        echo $menit;
                                                                                                    } else {
                                                                                                        echo "00";
                                                                                                    } ?> data-toggle="tooltip" data-placement="top" title="numerik only" placeholder="00" required>
                </div>
                <div class="col-sm-0 mg-t-0 mg-sm-t-10">
                    :
                </div>
                <div class="col-sm-2 mg-t-10 mg-sm-t-0">
                    <input type="number" class="form-control" name="valid_time4_editprofile" value=<?php if (preg_match("/rmcde/i", $onlogin)) {
                                                                                                        echo $detik;
                                                                                                    } else {
                                                                                                        echo "00";
                                                                                                    } ?> data-toggle="tooltip" data-placement="top" title="numerik only" placeholder="00" required>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Lock User : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <select class="form-control select2id" name="lock_mac_editprofile" data-placeholder="Select Type" data-toggle="tooltip" data-placement="top" title="Lock username dengan Mac">
                        <option value="disable" <?php if (preg_match("/rmcde/i", $onlogin) && $locmac == "0") {
                                                    echo 'selected';
                                                } ?>>Disable</option>
                        <option value="enable" <?php if (preg_match("/rmcde/i", $onlogin) && $locmac == "1") {
                                                    echo 'selected';
                                                } ?>>Enable</option>
                    </select>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label" for="checkbox2">Auto Delete Voucher : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <label class="ckbox">
                        <input type="checkbox" name="checkbox2_editprofile" value="true" id="checkbox2" <?php if (preg_match("/rmcde/i", $onlogin) && $remvoc == "1") {
                                                                                                            echo 'checked';
                                                                                                        } ?>><span>Yes</span> </label>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label" for="checkbox3">Owner Telegram Notification :</label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <label class="ckbox">
                        <input type="checkbox" name="checkbox3_editprofile" value="true" id="checkbox3" <?php if (preg_match("/rmcde/i", $onlogin) && $teledata == "1") {
                                                                                                            echo 'checked';
                                                                                                        } ?>><span>Yes</span> </label>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label" for="checkbox4">Reseller Telegram Notification :</label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <label class="ckbox">
                        <input type="checkbox" name="checkbox4_editprofile" value="true" id="checkbox4" <?php if (preg_match("/rmcde/i", $onlogin) && $teleres == "1") {
                                                                                                            echo 'checked';
                                                                                                        } ?>><span>Yes</span> </label>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label" for="checkbox">Transparent Proxy :</label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <label class="ckbox">
                        <input type="checkbox" name="checkbox_editprofile" value="true" id="checkbox" <?php

                                                                                                        if ($tranpro == 'true') {
                                                                                                            echo 'checked';
                                                                                                        }

                                                                                                        ?>>


                        <span>Transparent</span> </label>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label" for="enablefup">ENABLE FUP :</label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <label class="ckbox">
                        <input type="checkbox" name="enablefup_editprofile" value="true" id="enablefup_editprofile" <?php if ($statusfup == "1") {
                                                                                                                        echo "checked";
                                                                                                                    } ?>><span>YES</span> </label>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Target FUP : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="number" value="<?php echo $trgtfup ?>" name="fup_editprofile" size="10" id="targetfup_editprofile" <?php if ($statusfup == "0") {
                                                                                                                                        echo "disabled";
                                                                                                                                    } ?> required>
                    <select name="fupname_editprofile" id="fupid_editprofile" <?php if ($statusfup == "0") {
                                                                                    echo "disabled";
                                                                                } ?>>
                        <option value="" <?php if ($trgtfupnm == "") {
                                                echo "selected";
                                            } ?>>Byte</option>
                        <option value="K" <?php if ($trgtfupnm == "K") {
                                                echo "selected";
                                            } ?>>kByte</option>
                        <option value="M" <?php if ($trgtfupnm == "M") {
                                                echo "selected";
                                            } ?>>MByte</option>
                        <option value="G" <?php if ($trgtfupnm == "G") {
                                                echo "selected";
                                            } ?>>GByte</option>
                    </select>
                </div>
            </div>
            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Rate Limit Sesudah FUP (Rx/Tx) (Upload/Download) : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="number" value="<?php echo $rxfup ?>" name="raterx_editprofile" size="10" id="raterx_editprofile" <?php if ($statusfup == "0") {
                                                                                                                                        echo "disabled";
                                                                                                                                    } ?> required>
                    <select name="raterxname_editprofile" id="raterxid_editprofile" <?php if ($statusfup == "0") {
                                                                                        echo "disabled";
                                                                                    } ?>>
                        <option value="" <?php if ($rxname == "") {
                                                echo "selected";
                                            } ?>>bps</option>
                        <option value="K" <?php if ($rxname == "K") {
                                                echo "selected";
                                            } ?>>Kbps</option>
                        <option value="M" <?php if ($rxname == "M") {
                                                echo "selected";
                                            } ?>>Mbps</option>
                        <option value="G" <?php if ($rxname == "G") {
                                                echo "selected";
                                            } ?>>Gbps</option>
                    </select> /
                    <input type="number" value="<?php echo $txfup ?>" name="ratetx_editprofile" size="10" id="ratetx_editprofile" <?php if ($statusfup == "0") {
                                                                                                                                        echo "disabled";
                                                                                                                                    } ?> required>
                    <select name="ratetxname_editprofile" id="ratetxid_editprofile" <?php if ($statusfup == "0") {
                                                                                        echo "disabled";
                                                                                    } ?>>
                        <option value="" <?php if ($txname == "") {
                                                echo "selected";
                                            } ?>>bps</option>
                        <option value="K" <?php if ($txname == "K") {
                                                echo "selected";
                                            } ?>>Kbps</option>
                        <option value="M" <?php if ($txname == "M") {
                                                echo "selected";
                                            } ?>>Mbps</option>
                        <option value="G" <?php if ($txname == "G") {
                                                echo "selected";
                                            } ?>>Gbps</option>
                    </select>
                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Reset Tiap : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="number" value="<?php echo $itval ?>" name="durasireset_editprofile" size="10" id="durasireset_editprofile" <?php if ($statusfup == "0") {
                                                                                                                                                echo "disabled";
                                                                                                                                            } ?> required> Jam

                </div>
            </div>

            <div class="row mg-t-8">
                <label class="col-sm-4 form-control-label">Jam Reset : </label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input type="number" value="<?php echo $jmres ?>" min="00" max="23" name="jamreset_editprofile" size="5" id="jamreset_editprofile" <?php if ($statusfup == "0") {
                                                                                                                                                            echo "disabled";
                                                                                                                                                        } ?> required>

                </div>
            </div>


            <div class="row row-xs mg-t-10">
                <div class="col-sm-15 mg-l-auto">
                    <div class="form-layout-footer">
                        <input type="hidden" name="uid_editprofile" value="<?= $idprofile; ?>">
                        <button type="submit" class="btn bg-primary tx-white" name="saveprofileedit">Save</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger" name="deleteprofile">Delete</button>
                    </div>

                </div>

            </div>

        </form>
    </div>
</div>

<script>
    document.getElementById("enablefup_editprofile").onchange = function() {
        document.getElementById("targetfup_editprofile").disabled = !this.checked;
        document.getElementById("fupid_editprofile").disabled = !this.checked;
        document.getElementById("raterx_editprofile").disabled = !this.checked;
        document.getElementById("raterxid_editprofile").disabled = !this.checked;
        document.getElementById("ratetx_editprofile").disabled = !this.checked;
        document.getElementById("ratetxid_editprofile").disabled = !this.checked;
        document.getElementById("durasireset_editprofile").disabled = !this.checked;
        document.getElementById("jamreset_editprofile").disabled = !this.checked;

    }
</script>