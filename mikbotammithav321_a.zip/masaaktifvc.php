<head>
    <style>
        .label-info {
            color: #fff;
            background-color: #20805e;
            border: 1px solid #076745;
            background-image: -o-linear-gradient(bottom, #399977 0%, #20805e 100%);
            background-image: -moz-linear-gradient(bottom, #399977 0%, #20805e 100%);
            background-image: -webkit-linear-gradient(bottom, #399977 0%, #20805e 100%);
            background-image: -ms-linear-gradient(bottom, #399977 0%, #20805e 100%);
            background-image: linear-gradient(to bottom, #399977 0%, #20805e 100%);
            -webkit-box-shadow: inset 0 1px 0 #52b290;
            -moz-box-shadow: inset 0 1px 0 #52b290;
            box-shadow: inset 0 1px 0 #52b290;
        }

        .label-danger {
            color: #fff;
            background-color: #e5343d;
            border: 2px solid #e5343d;
        }

        .label {
            display: inline;
            padding: 0.2em 0.6em 0.3em;
            font-size: 74%;
            font-weight: 700;
            line-height: 1;
            color: #fff;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25em;
        }
    </style>
</head>
<?php
include 'config/system.conn.php';
include 'config/system.byte.php';
include 'Api/routeros_api.class.php';
$API = new routeros_api();

//ambil data get
$namanya = $_GET["user"];
$kodenya = $_GET["code"];

if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
    $jadwal = $API->comm('/ip/hotspot/user/print', ['?name' => $namanya]);
}

if ($namanya !== null && $kodenya !== null) {
    $hasilakhir = $jadwal[0]['comment'];
    if (strpos($hasilakhir, "MIKBOTAM") !== false && $kodenya == "expired") {
        $pecah = explode("| |", $hasilakhir);
        $pecah = explode("end", $pecah[0]);
        $endnya = $pecah[1];
        $pecah = explode("start", $pecah[0]);
        $startnya = $pecah[1];
        echo "<span class='label label-info'>Start : " . $startnya . " </span><br><br><span class='label label-danger '>Expired : " . $endnya . "</span>";
    } elseif ($kodenya == "upgrade") {

?>


        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>PERPANJANG MASA AKTIF</title>
        </head>

        <body>
           COMING SOON
        </body>

        </html>




<?php
        
    } else {
        $hasilakhir = "Unlimited";
        echo "<span class='label label-info'>UNLIMITED</span><br><br><span class='label label-danger '>UNLIMITED</span>";
    }
} else {
    echo "no data";
}
