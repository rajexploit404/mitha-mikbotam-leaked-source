<?php
include 'config/system.conn.php';
include 'config/system.byte.php';
include 'Api/routeros_api.class.php';
$API = new routeros_api();
if (isset($_POST["cari"]) && $API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {
    $jadwal = $API->comm('/system/scheduler/getall');
    $namanya = $_POST["keyword"];
    $cari = array_search ($namanya, array_column($jadwal, 'name'));
    $array_jadwal = $jadwal[$cari];
    
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>CEK USER HOTSPOT</title>
<meta http-equiv="pragma" content="no-cache" />
<meta http-equiv="expires" content="-1" />	
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0" />
<link rel="stylesheet" href="login.css" media="screen">
</head>

<script type="text/javascript">
// 1 detik = 1000
window.setTimeout("waktu()",1000);  
function waktu() {   
var tanggal = new Date();  
setTimeout("waktu()",1000);  
document.getElementById("jam").innerHTML = tanggal.getHours()+":"+tanggal.getMinutes()+":"+tanggal.getSeconds();
}
</script>

<script language="JavaScript">
    var tanggallengkap = new String();
    var namahari = ("Minggu Senin Selasa Rabu Kamis Jumat Sabtu");
    namahari = namahari.split(" ");
    var namabulan = ("Januari Februari Maret April Mei Juni Juli Agustus September Oktober November Desember");
    namabulan = namabulan.split(" ");
    var tgl = new Date();
    var hari = tgl.getDay();
    var tanggal = tgl.getDate();
    var bulan = tgl.getMonth();
    var tahun = tgl.getFullYear();
    tanggallengkap = namahari[hari] + ", " +tanggal + " " + namabulan[bulan] + " " + tahun;
    </script>


<body class='login'>
    


<form class="vertical-form" name="login" action="" method="post" background="#A03472">
<div style="margin:0;padding:50;display:inline"></div>

<center>

    <div id="head">
    </div>
    
    
<div id="box">
    
<legend>
<script language='JavaScript'>document.write(tanggallengkap);</script>
<div id='jam' ></div>
<p>CEK MASA AKTIF USER HOTSPOT</p>
</legend>

<div><input id="user" type="text" name="keyword" size="25" autofocus placeholder="masukkan kode voucher" autocomplete="off"></div>
<br>
<div><button class="tombol bhs"type="submit" name="cari">Cek Status</button></div>
<br>
<br>
<legend>
<?php
$hasilakhir = $array_jadwal['comment'] ;
if (strpos ($hasilakhir, "berakhir") !==false) {
echo "masa aktif voucher " .$namanya." ".$hasilakhir; 
} else if ($namanya == null){
 echo "silahkan tulis kode voucher di kolom atas";
} else {
    echo "maaf kode ".$namanya." tidak ditemukan";
}
?>
</legend>
</div>

<div>
</div>
</center>




<div class='footer'>

</div>
</form>


</body>
</html>
