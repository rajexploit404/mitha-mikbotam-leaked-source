<?php 
include 'config/system.conn.php';
include 'config/system.byte.php';
include 'Saldo/rpt/functions.php';

//=========data dikirim dari mikrotik
$usertelegram   = $_POST['idtelegram'];
$datamentah     = $_POST['info'];
$datastatus     = $_POST['status'];

//=========cari id telegram berdasarkan nama reseller
$idtelegramreseller = cariidtelegram($usertelegram);

//=========info yang dikirim dipecah
$pecahinfo      = explode("|",$datamentah);


$vcnya          = $pecahinfo[0];
$jenisvcnya     = $pecahinfo[1];
$macadd         = $pecahinfo[2];
$namareseller   = $pecahinfo[3];
$jamskr         = $pecahinfo[4];
$tglstart       = $pecahinfo[5];
$timeq          = $pecahinfo[6];
$tglexpired     = $pecahinfo[7];
$rmcde          = $pecahinfo[8];

//=======ambil data rmcde

$bcadmin    = $rmcde[0];
$remac      = $rmcde[1];
$lockmac    = $rmcde[2];
$bcres      = $rmcde[3];
$idowner    = $id_own;

//=======bikin array owner dan reseller

if ($bcadmin == 0) {$idowner = "0";}
if ($bcres == 0) {$idtelegramreseller = "0";}
if ($idowner == $idtelegramreseller) { $idtelegramreseller = "0";}

$arraybc    = [$idowner,$idtelegramreseller];



//====jika statusnya start, yang dikirim info start, jika statusnya expired maka yang dikirim yang expired
if ($datastatus == "start") {

  //=========simpan di dbase ============

  $startend = $jamskr."|".$tglstart."|".$timeq."|".$tglexpired."";

catatvoucheraktif($vcnya,$startend);
$informasinya = 
"<code>=========================
      Voucher AKTIF
-------------------------
          Detail

  Kode vc  : $vcnya
  Jenis vc : $jenisvcnya
  MAC-user : $macadd
  Reseller : $namareseller

-------------------------
    Login pertama kali

  Pukul    : $jamskr
  Tgl      : $tglstart

-------------------------
         Expired
  Pukul    : $timeq
  Tgl      : $tglexpired

=========================</code>";
} else if ($datastatus == "expired") {

$informasinya = 
"<code>=========================
     VOUCHER EXPIRED
-------------------------
Kode vc  : $vcnya
Jenis vc : $jenisvcnya
Reseller : $namareseller
=========================</code>";

}


//==========kirim perintah bot telegram ke reseller yang dituju
if (!empty($usertelegram) && !empty($datamentah) && !empty($datastatus)) {

  foreach ($arraybc as $bcnya) {

                            $website = "https://api.telegram.org/bot" . $token;
                          $params  = [
                              'chat_id' => $bcnya,
                              'text' => $informasinya,
                              'parse_mode' => 'html',
                          ];
                          $ch = curl_init($website . '/sendMessage');
                          curl_setopt($ch, CURLOPT_HEADER, false);
                          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                          curl_setopt($ch, CURLOPT_POST, 1);
                          curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
                          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                          $result = curl_exec($ch);
                          curl_close($ch);
                      }

                    }

?>