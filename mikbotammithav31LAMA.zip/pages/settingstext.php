<?php
//=====================================================START====================//

/*
 *  RUMAH PETIR v2.7
 *
 */

//=====================================================START SCRIPT====================//
error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:admin/login.php");
} else {
    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Saldo/rpt/functions.php';
}

$id = $_SESSION['Mikbotamid'];

//===ambil datanya
$arraytext = ngambiltext($id);
$textnya = json_decode($arraytext, true);




//===simpen datanya

if (isset($_POST['savetext'])) {

    $textbaru = [

        "daftar"        => $_POST['daftar_txt'],
        "menu_header"   => $_POST['menu_header'],
        "informasi"     => $_POST['informasi'],
        "saldo_footer"  => $_POST['saldo_footer'],
        "vc_footer"     => $_POST['voucher_footer'],
        "vc_logo"       => $_POST['voucher_logo'],
        "vc_url"        => $_POST['voucher_url']
        

    ];

    $enc_text = json_encode($textbaru);
    $simpantext = masukintext($enc_text, $id);

    echo '<script language="javascript">';
    echo 'document.addEventListener("DOMContentLoaded", function() {';
    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success  Update Text </center>");';
    echo '});';
    echo '</script>';
    echo "<script>setTimeout(\"location.href = '?Mikbotam=Settingstext';\");</script>";

}


?>
    <div class="sl-pagebody">
    	<h1 class="tx-center">Bot Response</h1>
    	                        <div class="row row-sm mg-t--1">
                            <div class="col-xl-6 mg-t-10">
      <div class="card bd-primary">
                    <div class="card-header bg-primary tx-white">
                        <i class="fa  fa-paper-plane"></i> Text Settings </div>
                    <div class="card-body pd-sm-15">
                        <form method="post" action="">
                           
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="1"> /daftar </label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['daftar']?>" id="1" name="daftar_txt" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" > </input>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="2">/menu - header</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['menu_header']?>" id="2" name="menu_header" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" > </input> 
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="3">INFORMASI</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['informasi']?>" id="3" name="informasi" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" > </input> 
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="4">saldo - footer </label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['saldo_footer']?>" id="4" name="saldo_footer" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" > </input> 
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="5">voucher - footer</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['vc_footer']?>" id="5" name="voucher_footer" maxlength="200" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" > </input> 
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="5">Logo Voucher : </label>
                                <div class="col-lg">
                                <input type="radio" name="voucher_logo" value="1" <?php if ($textnya['vc_logo'] == '1') {echo "checked";}  ?>> Default <br></label>
                                <input type="radio" name="voucher_logo" value="2" <?php if ($textnya['vc_logo'] == '2') {echo "checked";}  ?>> None <br></label>
                                <input type="radio" name="voucher_logo" value="3" <?php if ($textnya['vc_logo'] == '3') {echo "checked";}  ?>> Logo sendiri <br></label>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead " for="6">Url Logo Sendiri</label>
                                <div class="col-lg">
                                    <input value="<?= $textnya['vc_url']?>" id="6" name="voucher_url" maxlength="500" class="form-control" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 40px;" > </input> 
                                </div>
                            </div>
                            

                            <div class="row mg-t-8">
                            <label class="col-sm-4 form-control-label lead "></label>
                            <div class="col-lg">
                            <button type="submit" class="btn bg-primary tx-white" name="savetext" >Save changes</button>
                            <button type="reset" class="btn btn-danger">Reset</button>
                            </div>
                            </div>
                        </form>
              
                    </div>
                  </div>
                  
                </div>
                

                <div class="col-sm-4 mg-t-10">
			 <div class="card bd-primary">
                    <div class="card-header bg-primary tx-white"> Petunjuk</div>
                    <div class="card-body pd-sm-15">
                    	                        <table>
                            <tbody>
                                <tr>
                                    <td >
                                        <p >
                                             <code>/daftar</code><br>
                                            ini akan muncul ketika client/reseller mengetik perintah /daftar untuk pertama kalinya (sebelum terdaftar)<br><br>
                                            <code>/menu - header</code><br>
                                            ini akan muncul di bagian paling atas ketika client/reseller mengetik perintah /menu<br><br>
                                            <code>INFORMASI</code><br>
                                            ini akan muncul ketika client/reseller mengklik tombol informasi dalam bot<br><br>
                                            <code>saldo - footer</code><br>
                                            ini akan muncul pada bagian bawah ketika client/reseller mengecek saldo<br><br>
                                            <code>voucher - footer</code><br>
                                            ini akan muncul pada bagian bawah voucher yang di generate<br><br>
                                            <code>PINDAH BARIS</code><br>
                                            gunakan perintah "ENTER" untuk pindah baris, harus huruf besar dan tanpa tanda petik<br><br>
                                            <code>URL Logo</code><br>
                                            pastikan bahwa URL berakhiran .png / .jpg, contoh : http://www.rumahpetir.com/ga.png <br><br>
                                        </p>
                                        
                                					

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    		</div>
		</div>
		</div>

        </div>

                

                