<?php
$bottype = $_GET['bottype'];

if (isset($_POST['save'])) {
    if ($bottype == "default" || $bottype == "ORIdefault") {
        $file = 'template.php';
    } elseif ($bottype == "tiny-default" || $bottype == "ORItiny-default") {
        $file = 'template-small.php';
    }

    $openthis = fopen($file, 'w') or die('Cannot open file:  ' . $file);

    $data = ($_POST['editor']);

    fwrite($openthis, $data);
}

if ($bottype == "default" || $bottype == "rdefault") {
    $telplatet = "template";
    $popup = "javascript:window.open('vpreview.php?usermode=up&qr=no&','_blank','width=310,height=310')";
    $popupQR = "javascript:window.open('vpreview.php?usermode=up&qr=yes&','_blank','width=310,height=310')";
} elseif ($bottype == "thermal" || $bottype == "rthermal") {
    $telplatet = "template-thermal";
    $popup = "javascript:window.open('vpreview.php?usermode=up&user=m&qr=no&','_blank','width=310,height=310')";
    $popupQR = "javascript:window.open('vpreview.php?usermode=up&user=m&qr=yes&','_blank','width=310,height=310')";
} elseif ($bottype == "tiny-default" || $bottype == "rsmall") {
    $telplatet = "template-small";
    $popup = "javascript:window.open('vpreview.php?usermode=up&small=yes&qr=no&','_blank','width=310,height=310')";
    $popupQR = "javascript:window.open('vpreview.php?usermode=up&small=yes&qr=yes&','_blank','width=310,height=310')";
}

?>

<!-- Load Lib ace editor -->
<script src="../lib/ace/ace/ace.js"></script>
<script src="../lib/ace/ace/theme-twilight.js"></script>
<script src="../lib/ace/ace/mode-php.js"></script>
<script src="../lib/ace/jquery-ace.min.js"></script>


<div class="sl-pagebody pd-sm-5">
    <div class="row row-sm">
        <div class="col-sm-8">
            <div class="card bd-primary mg-t-3">
                <div class="card-header bg-primary tx-white"><i class="icol-ui-tab-content"></i> Edit Template Voucher</div>
                <div class="card-body pd-sm-5 ">
                    <form autocomplete="off" method="post" action="">

                        <div class="pd-10">

                            <button type="submit" title="Save <?= $bottype ?>.php" class="btn bg-primary tx-white" name="save"><i class="fa fa-save"></i> Save</button>

                            <select class="form-control select2id" onchange="window.location.href=this.value " style="width: 194px;" data-placeholder="Select Type">

                                <option><?= ucfirst($bottype); ?></option>
                                <option value="./index.php?Mikbotam=settingstemplate&bottype=default">Default</option>
                                <option value="./index.php?Mikbotam=settingstemplate&bottype=tiny-default">Tiny-Default</option>
                                <option value="./index.php?Mikbotam=settingstemplate&bottype=ORIdefault">(ORI)Default</option>
                                <option value="./index.php?Mikbotam=settingstemplate&bottype=ORItiny-default">(ORI)Tiny-Default</option>


                            </select>

                            <a class="btn bg-green" href="<?= $popup ?>" title="View voucher with Logo"><i class="fa fa-image"></i> </a>
                            <a class="btn bg-green" href="<?= $popupQR ?>" title="View voucher with  QR"><i class="fa fa-qrcode"></i> </a>

                        </div>

                        <textarea id="mikbotamedit" class="from-control db" rows="30" style="width: 100%" name="editor">

                        <?php
                        if ($bottype == "default") {
                            echo file_get_contents('template.php');
                        } elseif ($bottype == "tiny-default") {
                            echo file_get_contents('template-small.php');
                        } elseif ($bottype == "ORIdefault") {
                            echo file_get_contents('default.php');
                        } elseif ($bottype == "ORItiny-default") {
                            echo file_get_contents('default-small.php');
                        }
                        ?>

					
					
	        </textarea>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-4 mg-t-2">
            <div class="card bd-primary">
                <div class="card-header bg-primary tx-white"><i class="fa   fa-info-circle"></i> ReadMe</div>
                <div class="card-body pd-sm-15">
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <p>
                                        <code>PETUNJUK</code><br><br>
                                        Jika ingin kembali menggunakan default silahkan pilih yang ORI, lalu klik SAVE
                                        <br><br>
                                        <code>Kredit TEMPLATE</code> : agan LAKSAMADI GUKO pengembang MIKHMON
                                        <br><br>
                                        Agan bisa gunakan template bawaan mikhmon atau yang dimodding untuk mikhmon
                                        <br><br>
                                    </p>



                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    var _0x627b = ["tomorrow", "php", "ace", "#mikbotamedit"];
    $(_0x627b[3])[_0x627b[2]]({
        theme: _0x627b[0],
        lang: _0x627b[1]
    })
</script>