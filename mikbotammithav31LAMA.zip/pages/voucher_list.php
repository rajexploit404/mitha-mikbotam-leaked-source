<?php
//=====================================================START====================//

/*
 *  RUMAH PETIR v2.7
 *
 */

//=====================================================START SCRIPT====================//

error_reporting(0);

if (!isset($_SESSION["Mikbotamuser"])) {
    header("Location:admin/login.php");
} else {
    include '../config/system.conn.php';
    include '../config/system.byte.php';
    include '../Api/routeros_api.class.php';
    $API = new routeros_api();

    if ($API->connect($mikrotik_ip, $mikrotik_username, $mikrotik_password, $mikrotik_port)) {

        $seeprofile = $API->comm('/ip/hotspot/user/profile/print');
        $serverhot = $API->comm('/ip/hotspot/print');
    }
}
$id = $_SESSION['Mikbotamid'];
$ARRAYvoc = getvoc($id);

$datajson = json_decode($ARRAYvoc, true);




//===input vouchernya

if (isset($_POST['savevoucher']) && !empty($_POST['vc_nama'])) {

    if ($_POST['vc_markup'] > $_POST['vc_harga']) {

        echo '<script language="javascript">';
        echo 'document.addEventListener("DOMContentLoaded", function() {';
        echo 'alertify.alert("ERROR", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> ERROR  Mark Up tidak boleh lebih besar dari harga </center>");';
        echo '});';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '?Mikbotam=SettingsVoc';\", 2000);</script>";
    } else {
        if (empty($datajson)) {
            $idnya = "0";
        } else {
            $idnya = end($datajson)['id'] + 1;
        }
        $grupvc = $_POST['vc_grupvc'];
        $jmlgvc = count($grupvc);
        $grupvcjadisatu = "|";
        foreach ($grupvc as $gvc) {
            $grupvcjadisatu .= $gvc . "|";
        }
        $vouchernya =

            [
                "id"                => "$idnya",
                "Voucher"           => $_POST['vc_nama'],
                "Text_List"         => $_POST['vc_desc'],
                "price"             => $_POST['vc_harga'],
                "markup"            => $_POST['vc_markup'],
                "server"            => $_POST['vc_server'],
                "profile"           => $_POST['vc_profile'],
                "Limit"             => $_POST['vc_lmuptime'],
                "limit_download"    => $_POST['vc_lmqdl'],
                "limit_upload"      => $_POST['vc_lmqup'],
                "limit_total"       => $_POST['vc_lmqtotal'],
                "typechar"          => $_POST['vc_typechar'],
                "type"              => $_POST['vc_typelogin'],
                "prefix"            => $_POST['vc_prefix'],
                "length"            => $_POST['vc_lenchar'],
                "Color"             => $_POST['vc_color'],
                "grupvc"            => $grupvcjadisatu,
            ];
        $vcrfinal = [$vouchernya];

        if (empty($datajson)) {

            $merger = $vcrfinal;

            $encodedulu = json_encode($merger);
            $updatevcr = upvoc($encodedulu, $id);
        } else {
            $merger = array_merge($datajson, $vcrfinal);

            $encodedulu = json_encode($merger);
            $updatevcr = upvoc($encodedulu, $id);
        }

        //=====webhook ulang
        $domainnya = $_SERVER['HTTP_HOST'];
        $urlwebhook = "https://" . $domainnya . "/Saldo/Core.php";
        $setwebhk = setwebhook($urlwebhook, $token);

        echo '<script language="javascript">';
        echo 'document.addEventListener("DOMContentLoaded", function() {';
        echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success  Add Voucher Hotspot </center>");';
        echo '});';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '?Mikbotam=SettingsVoc';\");</script>";
    }
}


if (isset($_POST['deletevoucher'])) {

    $iddelete = $_POST['evc_arraynum'];

    unset($datajson[$iddelete]);
    $arraybaru = json_encode(array_values(array_filter($datajson)));
    $updatearray = upvoc($arraybaru, $id);

    //=====webhook ulang
    $domainnya = $_SERVER['HTTP_HOST'];
    $urlwebhook = "https://" . $domainnya . "/Saldo/Core.php";
    $setwebhk = setwebhook($urlwebhook, $token);

    echo '<script language="javascript">';
    echo 'document.addEventListener("DOMContentLoaded", function() {';
    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success  Delete Voucher Hotspot </center>");';
    echo '});';
    echo '</script>';
    echo "<script>setTimeout(\"location.href = '?Mikbotam=SettingsVoc';\");</script>";
}

// edit voucher

if (isset($_POST['savevoucheredit']) && !empty($_POST['evc_nama'])) {


    $id_edit = $_POST['evc_arraynum'];
    $grupvc = $_POST['evc_grupvc'];
    $jmlgvc = count($grupvc);
    $grupvcjadisatu = "|";
    foreach ($grupvc as $gvc) {
        $grupvcjadisatu .= $gvc . "|";
    }

    $voucheredit = [

        "id"                => $_POST['evc_id'],
        "Voucher"           => $_POST['evc_nama'],
        "Text_List"         => $_POST['evc_desc'],
        "price"             => $_POST['evc_harga'],
        "markup"            => $_POST['evc_markup'],
        "server"            => $_POST['evc_server'],
        "profile"           => $_POST['evc_profile'],
        "Limit"             => $_POST['evc_lmuptime'],
        "limit_download"    => $_POST['evc_lmqdl'],
        "limit_upload"      => $_POST['evc_lmqup'],
        "limit_total"       => $_POST['evc_lmqtotal'],
        "typechar"          => $_POST['evc_typechar'],
        "type"              => $_POST['evc_typelogin'],
        "prefix"            => $_POST['evc_prefix'],
        "length"            => $_POST['evc_lenchar'],
        "Color"             => $_POST['evc_color'],
        "grupvc"            => $grupvcjadisatu,


    ];

    $datajson[$id_edit] = $voucheredit;
    $arrayedit = json_encode(array_filter($datajson));
    $updatearrayedit = upvoc($arrayedit, $id);

    //=====webhook ulang
    $domainnya = $_SERVER['HTTP_HOST'];
    $urlwebhook = "https://" . $domainnya . "/Saldo/Core.php";
    $setwebhk = setwebhook($urlwebhook, $token);

    echo '<script language="javascript">';
    echo 'document.addEventListener("DOMContentLoaded", function() {';
    echo 'alertify.alert("Success", "<img style=\'width:30%\' class=\'responsive-image center\' src=\'../img/loading.svg\' alt=\'error\'><br><center> Success  Edit Voucher Hotspot </center>");';
    echo '});';
    echo '</script>';
    echo "<script>setTimeout(\"location.href = '?Mikbotam=SettingsVoc';\");</script>";
}

?>



<script src="../js/MikbotamNumberCheck.js"></script>
<script>
    function editvcr() {
        $("#voucheredit")["on"]("show.bs.modal", function(_0xfe4ax2) {
            var _0xfe4ax3 = $(_0xfe4ax2["relatedTarget"])["data"]("id");
            $("body")["css"]("cursor", "wait");
            $["ajax"]({
                url: "../pages/voucher_edit.php",
                data: "id=" + _0xfe4ax3,
                cache: false,
                success: function(_0xfe4ax4) {
                    $("#view-respont")["html"](_0xfe4ax4);
                    $("body")["css"]("cursor", "default")
                }
            })
        })
    }
</script>




<div class="sl-pagebody">
    <div class="card bd-primary mg-t-3">
        <div class="card-header bg-primary tx-white"><i class="fa fa-user"></i> Voucher List</div>
        <div class="card-body pd-sm-15">

            <div class="table-wrapper">
                <table id="voucherlist" class="table display nowrap " width="100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Group</th>
                            <th>Nama Voucher</th>
                            <th>Deskripsi</th>
                            <th>Harga</th>
                            <th>Mark Up</th>
                            <th>Server</th>
                            <th>Profile</th>
                            <th>Lmt<br>Uptime</th>
                            <th>Lmt<br>Quota<br>Dl</th>
                            <th>Lmt<br>Quota<br>Ul</th>
                            <th>Lmt<br>Quota<br>Total</th>
                            <th>Type<br>Char</th>
                            <th>Type<br>Login</th>
                            <th>prefix</th>
                            <th>Pjng<br>Char</th>
                            <th>Vcr<br>Clr</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($datajson as $index => $baris) :
                        ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td><?php if (empty($baris['grupvc']) || $baris['grup_vc'] == "all") {
                                        echo "all";
                                    } else {
                                        echo $baris['grupvc'];
                                    } ?></td>
                                <td><a href='#voucheredit' class="txt-black" data-toggle='modal' onclick='editvcr();' data-id="<?= $index . "&idtelegram=" . $id; ?>"><i class='fa fa-pencil-square-o'></i><?php echo $baris['Voucher']; ?></a></td>
                                <td><?php echo $baris['Text_List']; ?></td>
                                <td><?php echo rupiah($baris['price']); ?></td>
                                <td><?php echo rupiah($baris['markup']); ?></td>
                                <td><?php echo $baris['server']; ?></td>
                                <td><?php echo $baris['profile']; ?></td>
                                <td><?php echo $baris['Limit']; ?></td>
                                <td><?php echo $baris['limit_download'] . " Mb"; ?></td>
                                <td><?php echo $baris['limit_upload'] . " Mb"; ?></td>
                                <td><?php echo $baris['limit_total'] . " Mb"; ?></td>
                                <td><?php $typechar = $baris['typechar'];

                                    switch ($typechar) {

                                        case 1:
                                            echo "1234";
                                            break;
                                        case 2:
                                            echo "ABCDE";
                                            break;
                                        case 3:
                                            echo "abcd";
                                            break;
                                        case 4:
                                            echo "ABCDabcd";
                                            break;
                                        case 5:
                                            echo "AbcdABCD1234";
                                            break;
                                        case 6:
                                            echo "abcd1234";
                                            break;
                                        case 7:
                                            echo "ABCD1234";
                                            break;
                                        default:
                                            echo "1234";
                                            break;
                                    } ?></td>
                                <td><?php if ($baris['type'] == 'userpass') {
                                        echo 'Usr = Pass';
                                    } else {
                                        echo 'Usr & Pass';
                                    } ?></td>
                                <td><?php echo $baris['prefix']; ?></td>
                                <td><?php echo $baris['length']; ?></td>
                                <td bgcolor='#<?php echo $baris['Color']; ?>'></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<!-- CODE VARIABLE POP UP NYA -->



<!-- FORM POP UP NYA -->

<div id="voucheradd" class="modal fade" role="dialog">

    <div class="modal-dialog wd-100p mn-wd-50p" role="document">
        <div class="modal-content tx-size-sm">
            <div class="modal-header pd-x-25 bg-primary">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-white tx-bold">Add New Voucher </h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body pd-15">
                <div class="card bd bd-primary  ">
                    <div class="card-body pd-sm-15">

                        <form action="" method="post">

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Nama Voucher : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_nama" class="form-control" required>
                                </div>
                            </div>


                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Deskripsi : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_desc" class="form-control" required>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Harga Voucher (Rp) : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_harga" class="form-control" title="tulis angka saja jangan pakai titik/koma" required>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Mark Up Voucher (Rp) : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_markup" class="form-control" title="tulis angka saja jangan pakai titik/koma" required>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Server : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <select class="form-control" name="vc_server" data-placeholder="Select Server  ">
                                        <option value="all">all</option>
                                        <?php foreach ($serverhot as $index => $jambu) : ?>
                                            <option value="<?= $jambu['name'];
                                                            ?>"><?php echo $jambu['name'];
                                                                ?></option>
                                        <?php endforeach;
                                        ?>

                                    </select>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Profile : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <select class="form-control" name="vc_profile" data-placeholder="Select Server  ">

                                        <?php foreach ($seeprofile as $index => $kambing) : ?>
                                            <option value="<?= $kambing['name'];
                                                            ?>"><?php echo $kambing['name'];
                                                                ?></option>
                                        <?php endforeach;
                                        ?>

                                    </select>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Limit Uptime : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_lmuptime" class="form-control" title="sample : 30d" value="0" required>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Limit Quota Download (Mb) : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_lmqdl" class="form-control" value="0" required>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Limit Quota Upload (Mb) : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_lmqup" class="form-control" value="0" required>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Limit Quota Total (Mb) : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_lmqtotal" class="form-control" value="0" required>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Type Characters : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <select class="form-control" name="vc_typechar" data-placeholder="Select Server  ">

                                        <option value="1">1234</option>
                                        <option value="2">ABCDE</option>
                                        <option value="3">abcd</option>
                                        <option value="4">ABCDabcd</option>
                                        <option value="5">AbcdABCD1234</option>
                                        <option value="6">abcd1234</option>
                                        <option value="7">ABCD1234</option>
                                        <option value="checkCode">ABCDabcd1234</option>

                                    </select>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Type Login : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <select class="form-control" name="vc_typelogin" data-placeholder="Select Server  ">

                                        <option value="up">Username & Password</option>
                                        <option value="userpass">Username = Password</option>

                                    </select>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Prefix : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="text" name="vc_prefix" class="form-control" title="untuk memberi ciri tertentu di awal voucher, kosongi jika tidak perlu" maxlength="3">
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Length Character : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input id="colorful1" class="form-control  boxsadaw" name="vc_lenchar" type="number" min="3" max="10" value="5" onkeypress="return isNumber(event)" />
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Group Voucher : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="checkbox" id="grupvc1" name="vc_grupvc[]" value="1"> <label for="grupvc1"> 1 </label>
                                    <input type="checkbox" id="grupvc2" name="vc_grupvc[]" value="2"> <label for="grupvc2"> 2 </label>
                                    <input type="checkbox" id="grupvc3" name="vc_grupvc[]" value="3"> <label for="grupvc3"> 3 </label>
                                    <input type="checkbox" id="grupvc4" name="vc_grupvc[]" value="4"> <label for="grupvc4"> 4 </label>
                                    <input type="checkbox" id="grupvc5" name="vc_grupvc[]" value="5"> <label for="grupvc5"> 5 </label>
                                </div>
                            </div>

                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label">Voucher Color : </label>
                                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                                    <input type="hidden" id="nilaiwarna" value="#729fe8" name="vc_color">
                                    <button class="jscolor {zIndex:1080, valueElement: 'nilaiwarna'} ">Pick a Color</button>
                                </div>
                            </div>


                            <div class="row row-xs mg-t-10">
                                <div class="col-sm-15 mg-l-auto">
                                    <div class="form-layout-footer">
                                        <button type="submit" class="btn bg-primary tx-white" name="savevoucher">Save changes</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="reset" class="btn btn-danger">Reset</button>
                                    </div>
                                    <!-- form-layout-footer -->
                                </div>
                                <!-- col-8 -->
                            </div>

                        </form>
                    </div>

                </div>


            </div>
        </div>

    </div>
</div>

</div>
<div id="voucheredit" class="modal fade" role="dialog">
    <div class="modal-dialog wd-100p mn-wd-50p" role="document">
        <div class="modal-content tx-size-sm">
            <div class="modal-header pd-x-25 bg-primary">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-white tx-bold">Edit Voucher </h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body pd-15">
                <div id="view-respont">

                    <h2>Loading...</h2>
                </div>

            </div>
        </div>

    </div>
</div>





<script src="../js/MikbotamColorSelector.js"></script>
<script src="../lib/bootstrap/bootstrap.js"></script>

<script>
    $(document).ready(function() {


        // Initialize tooltip
        $('[data-toggle="tooltip"]').tooltip();

        // Initialize popover
        $('[data-popover-color="default"]').popover();

        $(document).on('click', function(e) {
            $('[data-toggle="popover"],[data-original-title]').each(function() {
                //the 'is' for buttons that trigger popups
                //the 'has' for icons within a button that triggers a popup
                if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
                    (($(this).popover('hide').data('bs.popover') || {}).inState || {}).click = false // fix for BS 3.3.6
                }

            });
        });

    });
    $('#colorful1,#colorful2,#colorful3,#colorful4,#colorful5,#colorful6').bootstrapNumber({
        upClass: 'success',
        downClass: 'danger'
    });
</script>