<?php
date_default_timezone_set('Asia/Jakarta');
//include '../config/system.config.php';
//=====top up sesuai tanggal====
function ngitungtopup($tglnya)
{

	global $mikbotamdata;
	$reportekstimasi = $mikbotamdata->sum('re_operating', [
		'top_up',
	], [
		'AND' => [
			'keterangan' => 'topup',
			'Tanggal' => $tglnya,
		]

	]);

	return $reportekstimasi;
}

//======mutasi voucher sesuai tanggal====
function mutasivchrharian($tglnya)
{

	global $mikbotamdata;
	$reportekstimasi = $mikbotamdata->sum('st_reportdata', [
		'pendapatan',
	], [

		'Tanggal' => $tglnya,
	]);

	return $reportekstimasi;
}

//======voucher yang terjual sesuai tanggal=====

function jumlahvchrharian($tglnya)
{

	global $mikbotamdata;

	$gethistory = $mikbotamdata->select(
		're_operating',
		[
			"keterangan",
			"Waktu",
			"Tanggal"

		],
		[
			'AND' => [
				'keterangan' => 'Success',
				'Tanggal' => $tglnya,
			]

		]
	);
	$ech = count($gethistory);
	return $ech;
}



//============input text settings============

function masukintext($matengnya, $id)
{

	global $mikbotamdata;

	$inputtext = $mikbotamdata->update(
		'st_mikbotam',
		[

			"setingstext" => $matengnya,
			"Tanggal_diubah" => date('Y-m-d'),

		],
		[
			"_id" => $id,
		]
	);

	return $inputtext;
}

//============ambil text settings============

function ngambiltext($id)
{

	global $mikbotamdata;

	$gettext = $mikbotamdata->get(
		'st_mikbotam',
		[
			"setingstext"
		],
		[
			"_id" => $id,
		]
	);
	$hasilnya = $gettext['setingstext'];
	return $hasilnya;
}

//=====top up sesuai range tanggal====
function ngitungtopuprange($tglnya1, $tglnya2)
{

	global $mikbotamdata;
	$reportrangetopup = $mikbotamdata->sum('re_operating', [
		'top_up',
	], [
		'AND' => [
			'keterangan' => 'topup',
			'Tanggal[<>]' => [$tglnya1, $tglnya2],
		]

	]);

	return $reportrangetopup;
}

//======mutasi voucher sesuai range tanggal====
function mutasivchrrange($tglnya1, $tglnya2)
{

	global $mikbotamdata;
	$reportekstimasirange = $mikbotamdata->sum('st_reportdata', [
		'pendapatan',
	], [

		'Tanggal[<>]' => [$tglnya1, $tglnya2],
	]);

	return $reportekstimasirange;
}

//======voucher yang terjual sesuai range tanggal=====

function jumlahvchrrange($tglnya1, $tglnya2)
{

	global $mikbotamdata;

	$gethistory2 = $mikbotamdata->select(
		're_operating',
		[
			"keterangan",
			"Waktu",
			"Tanggal"

		],
		[
			'AND' => [
				'keterangan' => 'Success',
				'Tanggal[<>]' => [$tglnya1, $tglnya2],
			]

		]
	);
	$ech2 = count($gethistory2);
	return $ech2;
}

//===============pendapatan range tertentu===========

function jmlpendapatanrange($id, $tglawal, $tglakhir)
{

	global $mikbotamdata;

	$ambilpendapatan = $mikbotamdata->select('st_reportdata', ['harga'], ['AND' => ['id_user' => $id, 'Tanggal[<>]' => [$tglawal, $tglakhir]]]);
	$pdpt = 0;
	foreach ($ambilpendapatan as $index => $baris) :

		$pdpt = $pdpt + $baris['harga'];
	endforeach;

	return $pdpt;
}

//===============jml vc range tertentu===========

function jmlvcrange($id, $tglawal, $tglakhir)
{

	global $mikbotamdata;

	$ambilvc = $mikbotamdata->select('re_operating', ['username_voucher'], ['AND' => ['id_user' => $id, 'Tanggal[<>]' => [$tglawal, $tglakhir]]]);

	$jmlvc = count($ambilvc);

	return $jmlvc;
}


//============tampilkan ID telegram berdasarkan username============
function cariidtelegram($usernametele)
{

	global $mikbotamdata;

	$ambilidnya = $mikbotamdata->select('re_settings', ['id_user'], ['AND' => ['nama_seller' => $usernametele,]]);

	return $ambilidnya[0]['id_user'];
}

//===========catat data voucher yang sudah diaktifkan=============
function catatvoucheraktif($namavc, $datavc)
{

	global $mikbotamdata;

	$ambilnomorurut = $mikbotamdata->select('re_operating', ['No', 'id_user', 'nama_seller', 'beli_voucher', 'keterangan'], ['AND' => ['username_voucher' => $namavc,]]);

	$ambilpalingbaru = end($ambilnomorurut);
	$no = $ambilpalingbaru['No'];


	$inputvc = $mikbotamdata->update(
		're_operating',
		[

			"penjualan" => $datavc,
			"Type_" => date('Y-m-d'),
			'Waktu' => date('H:i:s'),
			'Tanggal' => date('Y-m-d'),

		],
		[

			"No" => $no,
		]
	);

	if ($ambilpalingbaru['keterangan'] == 'generate') {
		$report = $mikbotamdata->insert('st_reportdata', [
			'id_user' => $ambilpalingbaru['id_user'],
			'nama_user' => $ambilpalingbaru['nama_seller'],
			'harga' => $ambilpalingbaru['beli_voucher'],
			'status' => $ambilpalingbaru['keterangan'],
			'transaksi' => $ambilpalingbaru['keterangan'],
			'pendapatan' => $ambilpalingbaru['beli_voucher'],
			'Waktu' => date('H:i:s'),
			'Tanggal' => date('Y-m-d'),

		]);

		$othertho = $mikbotamdata->select('re_settings', ['othertho'], ['id_user' => $ambilpalingbaru['id_user']]);
		$othertho = $othertho[0]['othertho'];

		if (empty($othertho)) {
			$othertho = 0;
		}

		$updateomsetfisik = $mikbotamdata->update('re_settings', ['othertho' => $othertho + $ambilpalingbaru['beli_voucher']], ['id_user' => $ambilpalingbaru['id_user'],]);
	}



	return $inputvc;
}


//=============input voucher generate ke database tanpa mengurangi saldo telegram

function generatevc($id, $usernamepelanggan, $princevoc, $markup, $username, $password, $uptime, $keterangan)
{
	global $mikbotamdata;
	$data = $mikbotamdata->get('re_settings', [
		'jumlah_debit_terjual',
		'id_user'
	], [
		'id_user' => $id

	]);
	$inkam = $data["jumlah_debit_terjual"];

	if (empty($inkam)) {
		$inkam = 0;
	}

	if (isset($data)) {
		$last_id = $mikbotamdata->insert('re_operating', [
			'id_user' => $id,
			'nama_seller' => $usernamepelanggan,
			'beli_voucher' => $princevoc,
			'markup_voucher' => $markup,
			'username_voucher' => $username,
			'password_voucher' => $password,
			'exp_voucher' => $uptime,
			'keterangan' => $keterangan,
			'Waktu' => date('H:i:s'),
			'Tanggal' => date('Y-m-d'),

		]);
	}

	$jumlahvc = $mikbotamdata->select('re_operating', ['username_voucher', 'keterangan'], ['AND' => ['id_user' => $id, 'keterangan' => "generate"]]);

	$jmlnya = count($jumlahvc);

	$update = $mikbotamdata->update('re_settings', [
		'jumlah_debit_terjual' => $inkam + $princevoc,
		'Waktu' => date('H:i:s'),
		'Tanggal' => date('Y-m-d'),
		'voucherlast' => $jmlnya,
	], [
		'id_user' => $id,
	]);



	return $update;
}
