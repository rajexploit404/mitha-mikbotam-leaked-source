<?php
date_default_timezone_set('Asia/Jakarta');
include './api/config.php';
require_once './api/PHPTelebot.php';
$bot    = new PHPTelebot($token, $usernamebot);

#command *
include './api/botcommands/except.php';
#command /routers
include './api/botcommands/routers.php';
#command /profiles - alur pilih router dulu
include './api/botcommands/profiles.php';
#command /hotspotusers - alur pilih router dulu
include './api/botcommands/hotspot_users.php';
#command /hotspotactives - alur pilih router dulu
include './api/botcommands/hotspot_actives.php';
#command /singlevoucher - alur pilih router dulu
include './api/botcommands/single_voucher.php';
#command /multivouchers - alur pilih router dulu
include './api/botcommands/multi_vouchers.php';
#command /report - alur pilih router dulu
include './api/botcommands/report.php';

$bot->on('callback', function ($command) {
    include('./include/config.php');
    $message        = Bot::message();
    $name           = $message['from']['first_name'];
    $name2          = $message['from']['last_name'];
    $idtelegram     = $message['from']['id'];
    $usertele       = $message['from']['username'];
    $chatidtele     = $message["message"]['chat']['id'];
    bot::sendChatAction('typing');
    $text   = '';

    if ($command == "cancel") {
        include './api/botcommands/cancel.php';
    } elseif (strpos($command, '|router|') !== false) {
        include './api/botcommands/callback_router.php';
    } elseif (strpos($command, '|routelist|') !== false) {
        include './api/botcommands/callback_route_list.php';
    } elseif (strpos($command, '|profile|') !== false) {
        include './api/botcommands/callback_profile.php';
    } elseif (strpos($command, '|profilepage|') !== false) {
        include './api/botcommands/callback_profile_page.php';
    } elseif (strpos($command, '|profilename|') !== false) {
        include './api/botcommands/callback_profile_name.php';
    } elseif (strpos($command, '|hotspotusers|') !== false) {
        include './api/botcommands/callback_hotspot_users.php';
    } elseif (strpos($command, '|hotspotuserspages|') !== false) {
        include './api/botcommands/callback_hotspot_users_pages.php';
    } elseif (strpos($command, '|hotspotusername|') !== false) {
        include './api/botcommands/callback_hotspot_user_name.php';
    } elseif (strpos($command, '|hotspotactives|') !== false) {
        include './api/botcommands/callback_hotspot_actives.php';
    } elseif (strpos($command, '|hotspotactivespages|') !== false) {
        include './api/botcommands/callback_hotspot_actives_pages.php';
    } elseif (strpos($command, '|hotspotactivename|') !== false) {
        include './api/botcommands/callback_hotspot_active_name.php';
    } elseif (strpos($command, '|report|') !== false) {
        include './api/botcommands/callback_report.php';
    } elseif (strpos($command, '|reportpages|') !== false) {
        include './api/botcommands/callback_report_pages.php';
    } elseif (strpos($command, '|reportdetail|') !== false) {
        include './api/botcommands/callback_report_detail.php';
    } elseif (strpos($command, '|singlevoucher|') !== false) {
        include './api/botcommands/callback_single_voucher.php';
    } elseif (strpos($command, '|singlevoucherpages|') !== false) {
        include './api/botcommands/callback_single_voucher_page.php';
    } elseif (strpos($command, '|singlevoucherprocess|') !== false) {
        include './api/botcommands/callback_single_voucher_process.php';
    } elseif (strpos($command, '|multivouchers|') !== false) {
        include './api/botcommands/callback_multi_vouchers.php';
    } elseif (strpos($command, '|multivoucherspage|') !== false) {
        include './api/botcommands/callback_multi_vouchers_page.php';
    } elseif (strpos($command, '|multivouchersprocess1|') !== false) {
        include './api/botcommands/callback_multi_vouchers_process1.php';
    } elseif (strpos($command, '|multivouchersprocess2|') !== false) {
        include './api/botcommands/callback_multi_vouchers_process2.php';
    }
});

$bot->run();

/*
alur profile dari :
- except -> callback_profile(pilih router) -> callback_profile_pages -> callback_profile_name
- /profile -> profile(pilih router) -> callback_profile_pages -> callback_profile_name

alur hotspot user dari :
- except -> callback_hotspot_users (pilih router) -> callback_hotspot_users_pages -> callback_hotspot_user_name
- /hotspotusers -> hotspot_users(pilih router) -> callback_hotspot_users_pages -> callback_hotspot_user_name
* status enabled disabled
* server
* name
* pass
* profile
* mac add
* uptime
* bytes in / out
* time limit
* data limit
* comment
* price
* selling price
* validity

alur hotspot active dari :
- except -> callback_hotspot_actives (pilih router) -> callback_hotspot_actives_pages -> callback_hotspot_active_name
- /hotspotactives -> hotspot_actives(pilih router) -> callback_hotspot_actives_pages -> callback_hotspot_active_name

alur bikin voucher :
- except -> callback_voucher (single/multi) (pilih router) -> callback_voucher_pages (single/multi) -> callback_voucher_quantity
- /hotspotactives -> voucher (single/multi) (pilih router) ->  callback_voucher_pages (single/multi) -> callback_voucher_quantity

setelah pilih quantity (backend proses) :
- generate dengan data, lalu tampilkan dalam bentuk url ke mikhmon, dengan proteksi variable GET enkripsi data detail


*/