<?php
$token         = "-";
$usernamebot   = "-";
$owner         = "-";
?>