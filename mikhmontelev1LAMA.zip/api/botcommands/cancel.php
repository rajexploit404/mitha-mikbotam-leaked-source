<?php
$delete = [
    'chat_id' => $chatidtele,
    'message_id' => (int) $message['message']['message_id'],
];

return Bot::deleteMessage($delete);
