<?php
$bot->cmd("*", function () {
    $message    = Bot::message();
    $name       = $message['from']['first_name'];
    $name2      = $message['from']['last_name'];
    $idtelegram = $message['from']['id'];
    $chatid     = $message['chat']['id'];
    $usertele   = $message['from']['username'];
    bot::sendChatAction('typing');
    $text = '';

    #ambil data router mikhmonnya
    include './api/config.php';
    if ($idtelegram == $owner) {
        #pesan 
        $text .= "halo, maaf perintah kamu tidak saya mengerti,\nberikut daftar perintah yang saya pahami :\n\n";
        $text .= "/routers - 📱 untuk melihat jumlah dan daftar router di mikhmon ini\n";
        $text .= "/singlevoucher - 🖨 untuk membuat 1 voucher hotspot\n\n";
        $text .= "/multivouchers - 📑 untuk membuat banyak voucher hotspot\n\n";
        $text .= "/hotspotusers - 💫 untuk melihat jumlah dan daftar user hotspot di salah satu mikrotik\n\n";
        $text .= "/hotspotactives - 🌟 untuk melihat jumlah dan daftar user aktif hotspot di salah satu mikrotik\n\n";
        $text .= "/profiles - 🎛 untuk melihat jumlah dan daftar profile di salah satu mikrotik\n\n";
        $text .= "/report - 💵 untuk melihat laporan penjualan di salah satu mikrotik\n\n";

        #send
        $send = [
            [
                #pilih router dulu
                ['text' => "🖨 Single Voucher", 'callback_data' => "|singlevoucher|"],
                #pilih router dulu
                ['text' => "📑 Multi Vouchers", 'callback_data' => "|multivouchers|"],
            ],
            [
                #pilih router dulu
                ['text' => "💫 Hotspot Active", 'callback_data' => "|hotspotactives|"],
                #pilih router dulu
                ['text' => "🌟 Hotspot User", 'callback_data' => "|hotspotusers|"],
            ],
            [
                #pilih router dulu
                ['text' => "🎛 Profile Hotspot", 'callback_data' => "|profile|"],
            ],
            [
                #pilih router dulu
                ['text' => "💵 Laporan Penjualan", 'callback_data' => "|report|"],
            ],

        ];

        $closebutton    = [
            ['text' => '❌❌ CLOSE ❌❌', 'callback_data' => 'cancel'],
        ];

        array_push($send, $closebutton);

        #options
        $options    = [
            'reply_markup' => json_encode(['inline_keyboard' => $send]),
            'parse_mode'    => 'html',
        ];

        return Bot::sendMessage($text, $options);
    }
});
