<?php
$namarouter     = explode("|multivouchersprocess2|", $command)[1]; //nama session router
$idunit         = explode("|multivouchersprocess2|", $command)[0]; //jumlah vouchers
$jenisvc        = explode("|multivouchersprocess2|", $command)[2]; //jenis voucher
include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));
$dataunit       = $API->comm("/system/script/print", ["?comment" => "mikhmon-mitha"])[0];
$datajson       = json_decode($dataunit['source'], true);
$datavc         = $datajson['jenis voucher'][$jenisvc];

//pending proses
$text .= "cetak voucher $jenisvc dengan jumlah $idunit di session $namarouter sedang diproses.\n";
$text .= "silahkan tunggu sebentar";

$options    = [
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];


Bot::editMessageText($options);

//generate proses


$getclock = $API->comm("/system/clock/print");
$clock = $getclock[0];
$timezone = $getclock[0]['time-zone-name'];
date_default_timezone_set($timezone);

#--------------------------------------

$qty = ($idunit);
if ($qty > 500) {
    $qty = 500;
}
$server = ($datavc['server']);
$user = ($datavc['usermode']);
$userl = ($datavc['length']);
$prefix = ($datavc['prefix']);
$char = ($datavc['char']);
$profile = ($datavc['profile']);
$timelimit = ($datavc['timelimit']);
$datalimit = ($datavc['datalimit']);
$adcomment = ($datavc['comment']);
$mbgb = ($datavc['mbgb']);
if ($timelimit == "") {
    $timelimit = "0";
} else {
    $timelimit = $timelimit;
}
if ($datalimit == "") {
    $datalimit = "0";
} else {
    $datalimit = $datalimit * $mbgb;
}
if ($adcomment == "") {
    $adcomment = "";
} else {
    $adcomment = $adcomment;
}
$getprofile = $API->comm("/ip/hotspot/user/profile/print", array("?name" => "$profile"));
$ponlogin = $getprofile[0]['on-login'];
$getvalid = explode(",", $ponlogin)[3];
$getprice = explode(",", $ponlogin)[2];
$getsprice = explode(",", $ponlogin)[4];
$getlock = explode(",", $ponlogin)[6];
$_SESSION['ubp'] = $profile;
$commt = $user . "-" . rand(100, 999) . "-" . date("m.d.y") . "-" . $adcomment;
$gentemp = $commt . "|~" . $profile . "~" . $getvalid . "~" . $getprice . "!" . $getsprice . "~" . $timelimit . "~" . $datalimit . "~" . $getlock;
$gen = '<?php $genu="' . encrypt($gentemp) . '";?>';
$temp = './voucher/temp.php';
$handle = fopen($temp, 'w') or die('Cannot open file:  ' . $temp);
$data = $gen;
fwrite($handle, $data);

$a = array("1" => "", "", 1, 2, 2, 3, 3, 4);

if ($user == "up") {
    for ($i = 1; $i <= $qty; $i++) {
        if ($char == "lower") {
            $u[$i] = randLC($userl);
        } elseif ($char == "upper") {
            $u[$i] = randUC($userl);
        } elseif ($char == "upplow") {
            $u[$i] = randULC($userl);
        } elseif ($char == "mix") {
            $u[$i] = randNLC($userl);
        } elseif ($char == "mix1") {
            $u[$i] = randNUC($userl);
        } elseif ($char == "mix2") {
            $u[$i] = randNULC($userl);
        }
        if ($userl == 3) {
            $p[$i] = randN(3);
        } elseif ($userl == 4) {
            $p[$i] = randN(4);
        } elseif ($userl == 5) {
            $p[$i] = randN(5);
        } elseif ($userl == 6) {
            $p[$i] = randN(6);
        } elseif ($userl == 7) {
            $p[$i] = randN(7);
        } elseif ($userl == 8) {
            $p[$i] = randN(8);
        }

        $u[$i] = "$prefix$u[$i]";
    }

    for ($i = 1; $i <= $qty; $i++) {
        $API->comm("/ip/hotspot/user/add", array(
            "server" => "$server",
            "name" => "$u[$i]",
            "password" => "$p[$i]",
            "profile" => "$profile",
            "limit-uptime" => "$timelimit",
            "limit-bytes-total" => "$datalimit",
            "comment" => "$commt",
        ));
    }
    $text   = "cetak voucher $jenisvc dengan jumlah $idunit di session $namarouter SUKSES\n";
    $text   .= "silahkan klik tombol di bawah ini untuk melihat voucher \n";
}

if ($user == "vc") {
    $shuf = ($userl - $a[$userl]);
    for ($i = 1; $i <= $qty; $i++) {
        if ($char == "lower") {
            $u[$i] = randLC($shuf);
        } elseif ($char == "upper") {
            $u[$i] = randUC($shuf);
        } elseif ($char == "upplow") {
            $u[$i] = randULC($shuf);
        }
        if ($userl == 3) {
            $p[$i] = randN(1);
        } elseif ($userl == 4 || $userl == 5) {
            $p[$i] = randN(2);
        } elseif ($userl == 6 || $userl == 7) {
            $p[$i] = randN(3);
        } elseif ($userl == 8) {
            $p[$i] = randN(4);
        }

        $u[$i] = "$prefix$u[$i]$p[$i]";

        if ($char == "num") {
            if ($userl == 3) {
                $p[$i] = randN(3);
            } elseif ($userl == 4) {
                $p[$i] = randN(4);
            } elseif ($userl == 5) {
                $p[$i] = randN(5);
            } elseif ($userl == 6) {
                $p[$i] = randN(6);
            } elseif ($userl == 7) {
                $p[$i] = randN(7);
            } elseif ($userl == 8) {
                $p[$i] = randN(8);
            }

            $u[$i] = "$prefix$p[$i]";
        }
        if ($char == "mix") {
            $p[$i] = randNLC($userl);


            $u[$i] = "$prefix$p[$i]";
        }
        if ($char == "mix1") {
            $p[$i] = randNUC($userl);


            $u[$i] = "$prefix$p[$i]";
        }
        if ($char == "mix2") {
            $p[$i] = randNULC($userl);


            $u[$i] = "$prefix$p[$i]";
        }
    }
    for ($i = 1; $i <= $qty; $i++) {
        $API->comm("/ip/hotspot/user/add", array(
            "server" => "$server",
            "name" => "$u[$i]",
            "password" => "$u[$i]",
            "profile" => "$profile",
            "limit-uptime" => "$timelimit",
            "limit-bytes-total" => "$datalimit",
            "comment" => "$commt",
        ));
    }

    $text   = "cetak voucher $jenisvc dengan jumlah $idunit di session $namarouter SUKSES\n";
    $text   .= "silahkan klik tombol di bawah ini untuk melihat voucher \n";
}


$urllink = "https://" . $_SERVER['HTTP_HOST'] . "/?hotspot=users&comment=" . $commt . "&session=" . $namarouter . "";

$tombolnya = [
    [
        ['text' => 'lihat voucher di mikhmon', 'url' => $urllink],
    ]
];

#--------------------------------------



$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $tombolnya]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];


Bot::editMessageText($options);
