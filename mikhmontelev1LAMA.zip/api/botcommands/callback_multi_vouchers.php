<?php
$namarouter     = explode("|multivouchers|", $command)[1];
#ambil data router mikhmonnya
include('./include/config.php');
$simpan = [];

foreach (file('./include/config.php') as $line) {
    $value = explode("'", $line)[1];
    if ($value == "" || $value == "mikhmon") {
    } else {
        array_push($simpan, [$value]);
    }
}

$datarouter = array_values($simpan);
$jmlrouter  = count($datarouter);
$pecahdua   = array_chunk($datarouter, 2);
$send       = [];


if (empty($jmlrouter)) {
    $text .= "Tidak ada Router di MIKHMON ini";
} else {
    $text .= "📑 MULTI VOUCHER 📑\n";
    $text .= "untuk membuat banyak voucher (lebih dari 1), silahkan pilih salah satu router dibawah ini : ";
}

foreach ($pecahdua as $i => $router) {
    $namarouter1 = $router[0][0];
    $namarouter2 = $router[1][0];

    $datakiri   = ['text' => "" . $namarouter1, 'callback_data' => '0|multivoucherspage|' . $namarouter1];
    $datakanan  = ['text' => "" . $namarouter2, 'callback_data' => '0|multivoucherspage|' . $namarouter2];

    $barisdata = array_filter([$datakiri, $datakanan]);
    array_push($send, $barisdata);
    unset($datakiri);
    unset($datakanan);
    unset($statusclient1);
    unset($statusclient2);
}

$closebutton    = [
    ['text' => '❌❌ CLOSE ❌❌', 'callback_data' => 'cancel'],
];

array_push($send, $closebutton);

$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $send]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];

return Bot::editMessageText($options);
