<?php
$namarouter     = explode("|multivouchersprocess1|", $command)[1];
$idunit         = explode("|multivouchersprocess1|", $command)[0];
include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));
$dataunit       = $API->comm("/system/script/print", ["?comment" => "mikhmon-mitha"])[0];
$datajson       = json_decode($dataunit['source'], true);
$opsijmlvc      = $datajson['quantity'];
$datavc         = $datajson['jenis voucher'][$idunit];

$jmlunit        = count($opsijmlvc);
$array_luar     = [];
$array_dalam    = [];

if ($jmlunit == 0) {
    $text = "tidak ada daftar jumlah voucher di mikrotik ini, silahkan setting dahulu di mikhmon";
    $options    = [
        'chat_id'      => $chatidtele,
        'message_id'   => (int) $message['message']['message_id'],
        'text'         => $text,
        'parse_mode'   => 'html',
    ];


    return Bot::editMessageText($options);
}

$text       .= "Silahkan Pilih Jumlah Voucher yang akan digenerate : ";
$text       .= "\n";
$text       .= "---------";


for ($i = 0; $i < $jmlunit; $i++) {
    $unitname       = $opsijmlvc[$i];
    $inputdata      = ['text' => $unitname . ' vouchers', 'callback_data' => $unitname . '|multivouchersprocess2|' . $namarouter . '|multivouchersprocess2|' . $idunit];
    array_push($array_dalam, $inputdata);
}

$splitarray    = array_chunk($array_dalam, $pecaharray);
foreach ($splitarray as $index => $satuan) {
    $satubaris     = array_filter([$satuan[0], $satuan[1], $satuan[2], $satuan[3]]);
    array_push($array_luar, $satubaris);
}

$closebutton    = [
    ['text' => '❌❌ CLOSE ❌❌', 'callback_data' => 'cancel'],
];

array_push($array_luar, $closebutton);

$options    = [
    'reply_markup' => json_encode(['inline_keyboard' => $array_luar]),
    'chat_id'      => $chatidtele,
    'message_id'   => (int) $message['message']['message_id'],
    'text'         => $text,
    'parse_mode'   => 'html',
];


return Bot::editMessageText($options);
