<?php

$bot->cmd("/profiles", function () {
    $message    = Bot::message();
    $name       = $message['from']['first_name'];
    $name2      = $message['from']['last_name'];
    $idtelegram = $message['from']['id'];
    $chatid     = $message['chat']['id'];
    $usertele   = $message['from']['username'];
    bot::sendChatAction('typing');
    $text   = '';


    #ambil data router mikhmonnya
    include('./include/config.php');
    include './api/config.php';
    $simpan = [];
    if ($idtelegram == $owner) {

        foreach (file('./include/config.php') as $line) {
            $value = explode("'", $line)[1];
            if ($value == "" || $value == "mikhmon") {
            } else {
                array_push($simpan, [$value]);
            }
        }

        $datarouter = array_values($simpan);
        $jmlrouter  = count($datarouter);
        $pecahdua   = array_chunk($datarouter, 2);
        $send       = [];


        if (empty($jmlrouter)) {
            $text .= "Tidak ada Router di MIKHMON ini";
        } else {
            $text .= "🎛 PROFILE HOTSPOT 🎛\n";
            $text .= "untuk melihat profile, silahkan pilih salah satu router dibawah ini : ";
        }

        foreach ($pecahdua as $i => $router) {
            $namarouter1 = $router[0][0];
            $namarouter2 = $router[1][0];

            $datakiri   = ['text' => "" . $namarouter1, 'callback_data' => '0|profilepage|' . $namarouter1];
            $datakanan  = ['text' => "" . $namarouter2, 'callback_data' => '0|profilepage|' . $namarouter2];

            $barisdata = array_filter([$datakiri, $datakanan]);
            array_push($send, $barisdata);
            unset($datakiri);
            unset($datakanan);
            unset($statusclient1);
            unset($statusclient2);
        }

        $closebutton    = [
            ['text' => '❌❌ CLOSE ❌❌', 'callback_data' => 'cancel'],
        ];

        array_push($send, $closebutton);

        $options    = [
            'reply_markup' => json_encode(['inline_keyboard' => $send]),
            'parse_mode'    => 'html',
        ];

        return Bot::sendMessage($text, $options);
    }
});
