<?php
$namarouter     = explode("|router|", $command)[1];
$text           .= "hotspot name : " . explode('%', $data[$namarouter][4])[1] . "\n";
$text           .= "session name : " . $namarouter;

include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
include('./api/readcfg.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($iphost, $userhost, decrypt($passwdhost));

$getidentity    = $API->comm("/system/identity/print");
$identity       = $getidentity[0]['name'];
$mikresource    = $API->comm("/system/resource/print");
$mikrb          = $API->comm("/system/routerboard/print");
$jmluserhspt    = $API->comm("/ip/hotspot/user/print", ['count-only' => 'yes']);
$jmluseractv    = $API->comm("/ip/hotspot/active/print", ['count-only' => 'yes']);

$text   .= "\n";
$text   .= "<code>\n";
$text   .= "===========\n";
$text   .= "identity  : $identity\n";
$text   .= "uptime    : " . $mikresource[0]['uptime'] . "\n";
$text   .= "boardname : " . $mikresource[0]['board-name'] . "\n";
$text   .= "model     : " . $mikrb[0]['model'] . "\n";
$text   .= "version   : " . $mikresource[0]['version'] . "\n";
$text   .= "memory    : " . round((($mikresource[0]['total-memory'] - $mikresource[0]['free-memory']) / 1000000), 2) . " Mb / " . round(($mikresource[0]['total-memory'] / 1000000), 2) . " Mb\n";
$text   .= "hdd-space : " . round((($mikresource[0]['total-hdd-space'] - $mikresource[0]['free-hdd-space']) / 1000000), 2) . " Mb / " . round(($mikresource[0]['total-hdd-space'] / 1000000), 2) . " Mb\n";
$text   .= "cpu load  : " . $mikresource[0]['cpu-load'] . " %\n";
$text   .= "===========\n";
$text   .= "hotspot user : " . $jmluserhspt . " users\n";
$text   .= "active user  : " . $jmluseractv . " users\n";
$text   .= "===========\n";
$text   .= "</code>";


#tombol back
$send = [
    [
        ['text' => "🖨 Single Voucher", 'callback_data' => "abc"],
        ['text' => "📑 Multi Vouchers", 'callback_data' => "abc"],
    ],
    [
        ['text' => "💫 Hotspot Active", 'callback_data' => "0|hotspotactivespages|" . $namarouter],
        ['text' => "🌟 Hotspot User", 'callback_data' => "0|hotspotuserspages|" . $namarouter],
    ],
    [
        ['text' => "🎛 Profile Hotspot", 'callback_data' => "0|profilepage|" . $namarouter],
    ],
    [
        ['text' => "💵 Laporan Penjualan", 'callback_data' => "0|reportpages|" . $namarouter],
    ],
    [
        ['text' => "🔙 back", 'callback_data' => '|routelist|'],
        ['text' => "CLOSE", "callback_data" => 'cancel'],
    ]
];


$options = [
    'reply_markup'  => json_encode(['inline_keyboard' => $send]),
    'chat_id'       => $chatidtele,
    'message_id'    => (int) $message['message']['message_id'],
    'text'          => $text,
    'parse_mode'    => 'html'
];

return Bot::editMessageText($options);
