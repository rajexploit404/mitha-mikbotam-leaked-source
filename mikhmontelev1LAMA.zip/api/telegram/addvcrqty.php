<?php
error_reporting(0);
if (!isset($_SESSION["mikhmon"])) {
    header("Location:../admin.php?id=login");
} else {
    $dataunit       = $API->comm("/system/script/print", ["?comment" => "mikhmon-mitha"])[0];
    $datajson       = json_decode($dataunit['source'], true);
    $datavc         = $datajson['jenis voucher'];
    $dataqty        = $datajson['quantity'];
    $srvlist        = $API->comm("/ip/hotspot/print");
    $getprofile     = $API->comm("/ip/hotspot/user/profile/print");

    if (isset($_POST['submit'])) {
        $vcrqty     = $_POST['vcrqty'];

        array_push($datajson['quantity'], $vcrqty);

        $simpan = json_encode($datajson);

        $API->comm("/system/script/set", [
            '.id'       => $dataunit['.id'],
            'source'    => $simpan,
        ]);
        header('Location: ./?telegram=menu&session=' . $session);
    }
}
?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">ADD VOUCHER QTY</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-header">
                                <h3><?= $info; ?></h3>
                            </div>
                            <div class="card-body">
                                <form autocomplete="off" method="post" action="">
                                    <table class="table">
                                        <tr>
                                            <td class="align-middle">Voucher Quantity</td>
                                            <td><input class="form-control " type="number" min='2' max='500' autocomplete="off" name="vcrqty" value="" required></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <div>
                                                    <button type="submit" name="submit" class="btn bg-primary" title="Add Voucher Type"> <i class="fa fa-save"></i> Add</button>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>