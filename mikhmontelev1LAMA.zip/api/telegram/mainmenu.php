<?php
// hide all error
error_reporting(0);
if (!isset($_SESSION["mikhmon"])) {
    header("Location:../admin.php?id=login");
} else {
    $dataunit       = $API->comm("/system/script/print", ["?comment" => "mikhmon-mitha"])[0];
    if ($dataunit == null) {
        $API->comm("/system/script/add", [
            'name'      => 'data mikhmon bot telegram',
            'comment'   => 'mikhmon-mitha',
            'owner'     => 'mitha',
            'source'    => '{"jenis voucher":[],"quantity":[]}',
        ]);
        $dataunit       = $API->comm("/system/script/print", ["?comment" => "mikhmon-mitha"])[0];
    }
    $datajson       = json_decode($dataunit['source'], true);
    $datavc         = $datajson['jenis voucher'];
    $dataqty        = $datajson['quantity'];
}
?>


<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fa fa-files-o"></i> SETTINGS VOUCHER</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-9">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fa fa-file"></i> JENIS VOUCHER<br>(di menu telegram bot)</h3>
                            </div>
                            <div class="card-body">
                                <a class='btn bg-info' href="./?telegram=addvcrtype&session=<?= $session; ?>"> <i class='fa fa-plus'></i> Add Voucher Type</a>
                                <div class="overflow mr-t-10 box-bordered" style="max-height: 75vh">
                                    <table id="dataTable" class="table table-bordered table-hover text-nowrap">
                                        <thead>
                                            <tr>
                                                <th class="align-middle text-center">Voucher Type</th>
                                                <th class="align-middle text-center">Server</th>
                                                <th class="align-middle text-center">User Mode</th>
                                                <th class="align-middle text-center">Name<br>Length</th>
                                                <th class="align-middle text-center">Prefix</th>
                                                <th class="align-middle text-center">Character</th>
                                                <th class="align-middle text-center">Profile</th>
                                                <th class="align-middle text-center">Time<br>Limit</th>
                                                <th class="align-middle text-center">Data<br>Limit</th>
                                                <th class="align-middle text-center">Comment</th>
                                                <th class="align-middle text-center">Description</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            foreach ($datavc as $i => $d) {

                                                if (empty($d['server'])) {
                                                    $server_vc  = 'all';
                                                } else {
                                                    $server_vc  = $d['server'];
                                                }

                                                if ($d['usermode'] == 'up') {
                                                    $usermode_vc    = 'username & password';
                                                    switch ($d['char']) {
                                                        case 'lower':
                                                            $char_vc    = 'abcd';
                                                            break;
                                                        case 'upper':
                                                            $char_vc    = 'ABCD';
                                                            break;
                                                        case 'upplow':
                                                            $char_vc    = 'aBcD';
                                                            break;
                                                        case 'mix':
                                                            $char_vc    = '5ab2c34d';
                                                            break;
                                                        case 'mix1':
                                                            $char_vc    = '5AB2C34D';
                                                            break;
                                                        case 'mix2':
                                                            $char_vc    = '5aB2c34D';
                                                            break;
                                                        default:
                                                            $char_vc    = 'abcd';
                                                    }
                                                } else if ($d['usermode'] == 'vc') {
                                                    $usermode_vc    = 'username = password';
                                                    switch ($d['char']) {
                                                        case 'lower':
                                                            $char_vc    = 'abcd2345';
                                                            break;
                                                        case 'upper':
                                                            $char_vc    = 'ABCD2345';
                                                            break;
                                                        case 'upplow':
                                                            $char_vc    = 'aBcD2345';
                                                            break;
                                                        case 'mix':
                                                            $char_vc    = '5ab2c34d';
                                                            break;
                                                        case 'mix1':
                                                            $char_vc    = '5AB2C34D';
                                                            break;
                                                        case 'mix2':
                                                            $char_vc    = '5aB2c34D';
                                                            break;
                                                        case 'num':
                                                            $char_vc    = '1234';
                                                            break;
                                                        default:
                                                            $char_vc    = 'abcd';
                                                    }
                                                }

                                                if ($d['mbgb'] == 1073741824) {
                                                    $datalimit_vc = $d['datalimit'] . 'Gb';
                                                } else if ($d['mbgb'] == 1048576) {
                                                    $datalimit_vc = $d['datalimit'] . 'Mb';
                                                }

                                                if ($d['datalimit'] == null) {
                                                    $datalimit_vc = '-';
                                                }


                                            ?>
                                                <tr>
                                                    <td class="align-middle text-center"><a href="./?voucher-type=<?= $i; ?>&session=<?= $session; ?>"><i class='fa fa-edit'></i> <?= $i ?></a></td>
                                                    <td class="align-middle text-center"><?= $server_vc ?></td>
                                                    <td class="align-middle text-center"><?= $usermode_vc ?></td>
                                                    <td class="align-middle text-center"><?= $d['length'] ?></td>
                                                    <td class="align-middle text-center"><?= $d['prefix'] ?></td>
                                                    <td class="align-middle text-center"><?= $_random . ' ' . $char_vc ?></td>
                                                    <td class="align-middle text-center"><?= $d['profile'] ?></td>
                                                    <td class="align-middle text-center"><?= $d['timelimit'] ?></td>
                                                    <td class="align-middle text-center"><?= $datalimit_vc ?></td>
                                                    <td class="align-middle text-center"><?= $d['comment'] ?></td>
                                                    <td class="align-middle text-center"><?= $d['desc'] ?></td>
                                                </tr>
                                            <?php
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <form autocomplete="off" method="post" action="">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fa fa-list-ol"></i> JUMLAH VOUCHER<br>(di menu telegram bot)</h3>
                                </div>
                                <div class="card-body">
                                    <a class='btn bg-success' href="./?telegram=addvcrqty&session=<?= $session; ?>"> <i class='fa fa-plus'></i> Add Voucher QTY</a>
                                    <div class="overflow mr-t-10 box-bordered" style="max-height: 75vh">
                                        <table id="dataTable" class="table table-bordered table-hover text-nowrap">
                                            <thead>
                                                <tr>
                                                    <th class="align-middle text-center">No</th>
                                                    <th class="align-middle text-center">jumlah voucher</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                foreach ($dataqty as $i => $d) {
                                                ?>
                                                    <tr>
                                                        <td class="align-middle text-center"><?= $i + 1; ?></td>
                                                        <td class="align-middle text-center"><a href="./?vcr-qty=<?= $i; ?>&session=<?= $session; ?>"><i class='fa fa-edit'></i> <?= $d; ?> Vouchers</a></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>